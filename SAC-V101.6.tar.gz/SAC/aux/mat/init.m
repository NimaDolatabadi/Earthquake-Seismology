window 1 x 0.1 0.99 y 0.1 0.99 aspect 1.9
lh columns 2 files none; qdp 10000 ; xdiv power off ; xlabel 'Time (sec)' ; title size medium
oapf name ; capf ; \rm APF
setmacro /usr/local/jas/macros ; transcript history file ./.sachist
