echo on
fg seismo
write raw.sac
int
write int_sac.sac
quit
