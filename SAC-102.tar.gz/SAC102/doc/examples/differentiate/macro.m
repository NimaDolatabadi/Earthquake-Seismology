echo on
fg seismo
write raw.sac
dif
write dif_sac.sac
quit
