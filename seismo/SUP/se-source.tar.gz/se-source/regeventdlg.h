#ifndef REGEVENTDLG_H
#define REGEVENTDLG_H

#include <QDialog>
#include "types.h"
#include "sebase.h"

struct wavfileinfo
{
   QString Name;
   QString DestPath;
};

typedef QList<struct wavfileinfo> QListWavFile;

struct RegEventData
{
   // In data.
   event_node_ *Node;
   QString DbName;
   QString SEISAN_TOP;
   // Out data.
   char DistInd;
   char EventInd;
   char ModelInd;
   QString AltDestDir;
   QString VolcSubClass;
   QString VolcSubClassVal;
   QListWavFile WaveFiles;
};


namespace Ui { class RegEventDlg; }

class RegEventDlg : public QDialog
{
   Q_OBJECT

public:
   explicit RegEventDlg(RegEventData *DialogData, QWidget *parent = 0);
   ~RegEventDlg();

private slots:
   void accept(void);
   bool eventFilter(QObject*, QEvent*);

private:
   Ui::RegEventDlg *ui;
   RegEventData *DlgData;
   void PopulateFileTable();
};

#endif // REGEVENTDLG_H
