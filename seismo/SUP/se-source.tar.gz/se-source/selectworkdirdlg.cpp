#include <QDir>
#include <QMessageBox>
#include <QFileDialog>
#include "selectworkdirdlg.h"
#include "ui_selectworkdirdlg.h"


// ****************************
// Constructor function.
// ****************************
SelectWorkDirDlg::SelectWorkDirDlg(se_config *Config, QWidget *parent) : QDialog(parent), ui(new Ui::SelectWorkDirDlg)
{
   // Save a pointer to configuration structure,
   // and the contents of the config structure.
   pConfig = Config; DlgConfig = *Config;

   // Set up the user interface.
   ui->setupUi(this);

   // Initialize all widgets in the dialog box.
   if (DlgConfig.WorkDirType == 0) ui->UseSeisanWD->setChecked(true);
   if (DlgConfig.WorkDirType == 1) ui->UseLaunchWD->setChecked(true);
   if (DlgConfig.WorkDirType == 2) {
       ui->UseAltWD->setChecked(true);
       ui->WorkDir->setText(DlgConfig.UserWorkDir);
   }
   if (DlgConfig.WorkDirType != 2) {
      ui->WorkDir->setDisabled(true);
      ui->BrowseWorkDirButton->setDisabled(true);
   }
   ui->WorkDir->setText(DlgConfig.UserWorkDir);
}




// ****************************
// Destructor function.
// ****************************
SelectWorkDirDlg::~SelectWorkDirDlg()
{
   delete ui;
}




// *****************************************************************
// User has pressed the 'Use SEISAN working directory' radio button.
// *****************************************************************
void SelectWorkDirDlg::UseSeisanWD()
{
   // Disable the alternative workdir widgets.
   ui->WorkDir->setDisabled(true);
   ui->BrowseWorkDirButton->setDisabled(true);
}




// *****************************************************************
// User has pressed the 'Use SE launch directory' radio button.
// *****************************************************************
void SelectWorkDirDlg::UseLaunchWD()
{
   // Disable the alternative workdir widgets.
   ui->WorkDir->setDisabled(true);
   ui->BrowseWorkDirButton->setDisabled(true);
}




// *******************************************************************
// User has pressed the 'Use alternative work directory' radio button.
// *******************************************************************
void SelectWorkDirDlg::UseAltWD()
{
   // Enable the the alternative workdir widgets.
   ui->WorkDir->setEnabled(true);
   ui->BrowseWorkDirButton->setEnabled(true);
}




// *************************************
// User has pressed the 'Browse' button.
// *************************************
void SelectWorkDirDlg::BrowseWorkDir()
{
   // Bring up folder selection dialog box. Return if user cancels the operation.
   QString Message = "Please select a work folder";
   QString WorkDir = QFileDialog::getExistingDirectory(this, Message, QDir::currentPath(), QFileDialog::ShowDirsOnly);

   // Return if user did not select a folder.
   if (WorkDir.isNull()) return;

   // Use native separators in the path.
   WorkDir = QDir::toNativeSeparators(WorkDir);

   // Update the work directory.
   ui->WorkDir->setText(WorkDir);
}




// *********************************
// User has pressed the 'OK' button.
// *********************************
void SelectWorkDirDlg::accept(void)
{
   // Get type of working directory.
   if (ui->UseSeisanWD->isChecked()) DlgConfig.WorkDirType = 0;
   if (ui->UseLaunchWD->isChecked()) DlgConfig.WorkDirType = 1;
   if (ui->UseAltWD->isChecked()) DlgConfig.WorkDirType = 2;
   // Get and check the alternative work dir.
   if (DlgConfig.WorkDirType == 2) {
      // Check that the work dir exists.
      if (QDir(ui->WorkDir->text()).exists()) {
         // Get the absolute path including drive name.
         QString CurDir = QDir::currentPath();
         QDir::setCurrent(ui->WorkDir->text());
         QString NewDir = QDir::currentPath();
         QDir::setCurrent(CurDir);
         // Save the directory.
         DlgConfig.UserWorkDir = QDir::toNativeSeparators(NewDir);
      } else {
         // Invalid directory entered.
         QString Message = "Non-exisitng or invalid working folder entered.";
         QMessageBox::critical(NULL, "Seisan Explorer", Message);
         ui->WorkDir->selectAll(); ui->WorkDir->setFocus();
         return;
      }
   }

   // Return configuration back to parent class.
   *pConfig = DlgConfig;

   // Close the dialog and return 'Accepted' signal.
   QDialog::accept();
}
