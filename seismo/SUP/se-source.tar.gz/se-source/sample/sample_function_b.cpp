/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "sample_function_b.h"
#include "ui_sample_function_b.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>

#include <iostream>
#include "qcustomplot.h"

sample_function_b::sample_function_b(db *database, QWidget *parent) : QDialog(parent),
                                     ui(new Ui::sample_function_b)
{
    ui->setupUi(this);

    //printf( "\nstart Sample function B\n");

    ui->doubleSpinBox_Mmax->setValue(7.0);
    ui->doubleSpinBox_Mmax->setSingleStep(0.5);

    // initial plot
    sample_function_b_plot();

    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_PDF, SIGNAL( clicked() ), this, SLOT( outputPDF() ) );
    connect( ui->pushButton_PNG, SIGNAL( clicked() ), this, SLOT( outputPNG() ) );

    // plot when "Replot" is clicked
    connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( sample_function_b_plot() ) );

    // Hi there,
    // if you want your function added to SE, please send us the source code
    // Good luck

}

sample_function_b::~sample_function_b() {
    delete ui;
}

void sample_function_b::outputPDF() {
    ui->customPlot->savePdf("pv.pdf",0,700,700);
}

void sample_function_b::outputPNG() {
    ui->customPlot->savePng("pv.png",700,700,1,-1);
}

void sample_function_b::sample_function_b_plot() {

    ui->customPlot->clearPlottables();

    // add random graph
    double DC = ui->doubleSpinBox_Mmax->value();
    printf("DC=%f\n",DC);
    QVector<double> yValue(90);
    QVector<double> xValue(90);
    for (int i=0; i<90; i++){
        xValue[i]=(double)i+5.0;
        yValue[i]=DC+rand()/(double)RAND_MAX-0.5;
    }
    QPen pen;
    pen.setColor(QColor(0,0,255));
    ui->customPlot->addGraph();
    ui->customPlot->graph()->setPen(pen);
    ui->customPlot->graph()->setData(xValue, yValue);
    ui->customPlot->graph()->setName("Random graph");
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);

    // creat histogram
    QVector<double> NumberOfSeismologist(5);
    QVector<double> Age(5);
    QCPBars *seismologist = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addPlottable(seismologist);
    seismologist->setName("Distribution");
    seismologist->setWidth(50);
    pen.setColor(QColor(0,0,0));
    seismologist->setPen(pen);
    seismologist->setBrush(QColor(244,0,0));
    NumberOfSeismologist << 4 << 2;
    Age << 25 << 75;
    // add histogram to plot
    seismologist->setData(Age, NumberOfSeismologist);

    // labels:
    //ui->customPlot->setTitle("SEISAN: Sample function B");
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Sample function B"));
    ui->customPlot->xAxis->setLabel("Age [Years]");
    ui->customPlot->yAxis->setLabel("Number of seismologist");

    ui->customPlot->legend->setVisible(true);

    ui->customPlot->xAxis->setRange(-5, 105);
    ui->customPlot->yAxis->setRange(0, 10);

    ui->customPlot->replot();
    //std::cout << "done" << std::endl;
}





