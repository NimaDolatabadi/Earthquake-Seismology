#ifndef SAMPLE_FUNCTION_B_DLG
#define SAMPLE_FUNCTION_B_DLG

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class sample_function_b;
}

class sample_function_b : public QDialog
{
    Q_OBJECT

public:
    explicit sample_function_b(db *database, QWidget *parent = 0);
    ~sample_function_b();

private slots:
    void sample_function_b_plot();
    void outputPDF();
    void outputPNG();

private:
    Ui::sample_function_b *ui;
    db *DataBase;
};

#endif
