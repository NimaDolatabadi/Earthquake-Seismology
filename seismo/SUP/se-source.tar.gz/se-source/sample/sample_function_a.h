#ifndef SAMPLE_FUNCTION_A_DLG
#define SAMPLE_FUNCTION_A_DLG

#include <QDialog>
#include "database.h"

namespace Ui {
    class sample_function_a;
}

class sample_function_a : public QDialog
{
    Q_OBJECT

public:
    explicit sample_function_a(db *database, QWidget *parent = 0);
    ~sample_function_a();

private:
    Ui::sample_function_a *ui;
    db *DataBase;
};

#endif
