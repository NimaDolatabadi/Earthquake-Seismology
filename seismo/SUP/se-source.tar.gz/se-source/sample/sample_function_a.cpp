/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "sample_function_a.h"
#include "ui_sample_function_a.h"
#include "mainwindow.h"

#include <QString>

sample_function_a::sample_function_a(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::sample_function_a) {
    ui->setupUi(this);

    //printf( "\nstart Sample function A\n");

    QStringList TableHeader;
    TableHeader << "Parameter" << "Value";
    ui->tableWidget->setColumnCount(2);
    ui->tableWidget->setHorizontalHeaderLabels(TableHeader);
    ui->tableWidget->setColumnWidth(0,140);
    ui->tableWidget->setColumnWidth(1,60);
    ui->tableWidget->setRowCount(4);

    DataBase=database;

    int NumEvents = DataBase->GetNumberOfEvents();
    event_node_ *Node;

    ui->tableWidget->setItem(0,0,new QTableWidgetItem(QString("Number of events")));
    ui->tableWidget->setItem(0,1,new QTableWidgetItem(QString("%1").arg(NumEvents)));

    float magnitude=-999.9, MaxMag=-999.9;

    Node = DataBase->GetEventByIndex(0);
    if (Node->hypocenters.nmag>0)
        magnitude = Node->hypocenters.mag_all[0].mag;

    ui->tableWidget->setItem(1,0,new QTableWidgetItem(QString("Magnitude of event #1")));
    ui->tableWidget->setItem(1,1,new QTableWidgetItem(QString("%1").arg(magnitude)));


    for (int i=0; i<NumEvents; ++i){
            Node = DataBase->GetEventByIndex(i);
            if (Node->hypocenters.nmag>0)
                magnitude = Node->hypocenters.mag_all[0].mag;
            if (MaxMag < magnitude)
                MaxMag = magnitude;
        }

    ui->tableWidget->setItem(2,0,new QTableWidgetItem(QString("Largest Prime magnitude")));
    if (MaxMag > -999.9)
        ui->tableWidget->setItem(2,1,new QTableWidgetItem(QString("%1").arg(MaxMag)));
    else
        ui->tableWidget->setItem(3,1,new QTableWidgetItem(QString("NO MAG")));

    MaxMag=-999.9;

    for (int i=0; i<NumEvents; ++i){
            Node = DataBase->GetEventByIndex(i);
            if (Node->hypocenters.first->magnitudes.ML.nmag>0)
                magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
            if (MaxMag < magnitude)
                MaxMag = magnitude;
        }

    ui->tableWidget->setItem(3,0,new QTableWidgetItem(QString("Largest ML")));
    if (MaxMag > -999.9)
        ui->tableWidget->setItem(3,1,new QTableWidgetItem(QString("%1").arg(MaxMag)));
    else
        ui->tableWidget->setItem(3,1,new QTableWidgetItem(QString("NO ML")));

    // Hi there,
    // if you want your function added to SE, please send us the source code
    // Good luck

}

sample_function_a::~sample_function_a() {
    delete ui;
}


