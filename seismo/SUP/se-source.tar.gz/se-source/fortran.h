#ifndef FORTRAN_H
#define FORTRAN_H

#define MAX_DATA 10000

typedef unsigned int uint;
typedef signed int sint;

extern "C" {
   // External fortran function prototypes.
   void findevin_(char*, char*, char*, char*, sint*, sint*, char*, sint*, sint*, sint*, uint, uint, uint, uint, uint);
   void rea_event_in_(sint*, sint*, char*, sint*, uint);
   void rea_event_out_(sint*, sint*, char*, sint*, uint);
   void merge_f_(char*, char*, sint*, sint*, sint*, sint*, sint*, uint, uint);
   void hypmain_(char*, sint*, char*, sint*, sint*, uint, uint);

   // External fortran common blocks.
   extern struct comblck_se {
      int se_out;
   } seisan_explorer_ ;

   extern struct comblck_rea_mes {
      char rea_message[1000][80];
      int rea_n_message;
   } rea_mes_ ;

   extern struct comblck_hyp1 {
      char hyp_model[100], hyp_dist_id[100], hyp_type[100], hyp_fix_org[100];
      char hyp_depth_flag[100], hyp_epi_flag[100], hyp_mag_type[100][6];
      int hyp_high_accuracy[100], hyp_error[100];
      char hyp_mag_type_all[200], mt_coor[100];
   }  hyp1_ ;

   extern struct comblck_hyp4 {
      int hyp_year[100], hyp_month[100], hyp_day[100], hyp_hour[100], hyp_min[100];
      float hyp_sec[100], hyp_lat[100], hyp_lon[100], hyp_depth[100];
      int hyp_nstat[100];
      float hyp_rms[100], hyp_mag[100][6], hyp_mag_all[200], hyp_gap[100];
      float hyp_sec_err[100], hyp_lat_err[100], hyp_lon_err[100];
      float hyp_depth_err[100], hyp_cov[100][3];
      char hyp_auto[100][20];
      int hyp_mag_all_main[200];
   } hyp4_ ;

   extern struct comblck_hyp5 {
      char hyp_agency[100][5], hyp_mag_agency[100][6][5], hyp_mag_agency_all[200][5];
   } hyp5_ ;

   extern struct comblck_rea1 {
      char rea_weight_in[MAX_DATA/2], rea_onset[MAX_DATA/2], rea_polarity[MAX_DATA/2];
   } rea1_ ;

   extern struct comblck_rea2 {
      char rea_co[MAX_DATA/2][2], rea_weight_out[MAX_DATA/2][2];
   } rea2_ ;

   extern struct comblck_rea3 {
      char rea_action[3];
   } rea3_ ;

   extern struct comblck_rea4 {
      char rea_comp[MAX_DATA/2][4];
      int rea_hour[MAX_DATA/2], rea_min[MAX_DATA/2];
      float rea_sec[MAX_DATA/2], rea_coda[MAX_DATA/2], rea_amp[MAX_DATA/2];
      float rea_per[MAX_DATA/2], rea_baz_obs[MAX_DATA/2], rea_baz_cal[MAX_DATA/2];
      float rea_vel[MAX_DATA/2], rea_ain[MAX_DATA/2], rea_baz_res[MAX_DATA/2];
      float rea_dist[MAX_DATA/2], rea_az[MAX_DATA/2];
      int rea_nstat, rea_nphase;
      float rea_res[MAX_DATA/2];
      int rea_year[MAX_DATA/2], rea_month[MAX_DATA/2], rea_day[MAX_DATA/2];
      float rea_moment[MAX_DATA/2];
      int rea_nmag;
      float rea_sdrop[MAX_DATA/2], rea_omega0[MAX_DATA/2], rea_cornerf[MAX_DATA/2];
      float rea_radius[MAX_DATA/2], rea_swin[MAX_DATA/2], rea_vs[MAX_DATA/2];
      float rea_vp[MAX_DATA/2], rea_q_below_1hz[MAX_DATA/2], rea_q0[MAX_DATA/2];
      float rea_qalpha[MAX_DATA/2],rea_kappa[MAX_DATA/2], rea_density[MAX_DATA/2];
      float rea_slope[MAX_DATA/2], rea_mc[MAX_DATA/2], rea_ml[MAX_DATA/2];
      float rea_mb[MAX_DATA/2], rea_ms[MAX_DATA/2], rea_mw[MAX_DATA/2];
      float rea_geo_dist[MAX_DATA/2];
      int rea_nhead, rea_nrecord, rea_nspec, rea_nhyp;
      char rea_id_line[80];
      int rea_nmacro, rea_nwav, rea_nfault, rea_ncomment;
      char rea_macro[100][80], rea_wav[500][80], rea_fault[100][80], rea_comment[1000][80];
      float rea_av_moment, rea_av_sdrop, rea_av_omega0, rea_av_cornerf;
      float rea_av_radius, rea_av_swin, rea_av_mw, rea_av_slope;
      char rea_auto[MAX_DATA/2][20];
      int rea_err_unit, rea_read_err, rea_write_err;
      char rea_locality[68];
   } rea4_ ;

   extern struct comblck_rea5 {
      char rea_stat[MAX_DATA/2][5];
   } rea5_ ;

   extern struct comblck_rea8 {
      char rea_phase[MAX_DATA/2][8];
      double rea_abs_time[MAX_DATA/2];
   } rea8_ ;

   extern struct comblck_rea9 {
      char rea_phase_cal[MAX_DATA/2][8];
      char rea_mag_type[MAX_DATA/2][2];
      float rea_time_obs[MAX_DATA/2], rea_time_cal[MAX_DATA/2];
      float rea_mag[MAX_DATA/2], rea_mag_res[MAX_DATA/2];
      float rea_wt[MAX_DATA/2], rea_baz_wt[MAX_DATA/2];
      float hyp_dx,hyp_dy,hyp_dz,hyp_do;
      int rea_di[MAX_DATA/2],rea_baz_di[MAX_DATA/2];
   } rea9_ ;

}

#endif // FORTRAN_H
