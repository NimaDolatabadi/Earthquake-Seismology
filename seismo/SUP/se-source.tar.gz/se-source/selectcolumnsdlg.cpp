#include "selectcolumnsdlg.h"
#include "ui_selectcolumnsdlg.h"


// *******************************
// Constructor function.
// *******************************
SelectColumnsDlg::SelectColumnsDlg(se_config* Config, QWidget *parent) : QDialog(parent), ui(new Ui::SelectColumnsDlg)
{
    // Save configuration.
    this->Config=Config;

    // Set up the user interface.
    ui->setupUi(this);

    // Set initial state for all widgets in dialog box.
    ui->checkBox_RowNum->setChecked(Config->EvtListColStat[0]);
    ui->checkBox_Action->setChecked(Config->EvtListColStat[1]);
    ui->checkBox_Model->setChecked(Config->EvtListColStat[2]);
    ui->checkBox_Agency->setChecked(Config->EvtListColStat[3]);
    ui->checkBox_RMS->setChecked(Config->EvtListColStat[4]);
    ui->checkBox_Gap->setChecked(Config->EvtListColStat[5]);
    ui->checkBox_LatError->setChecked(Config->EvtListColStat[6]);
    ui->checkBox_LonError->setChecked(Config->EvtListColStat[7]);
    ui->checkBox_DepthError->setChecked(Config->EvtListColStat[8]);
    ui->checkBox_Dist->setChecked(Config->EvtListColStat[9]);
    ui->checkBox_Event->setChecked(Config->EvtListColStat[10]);
    ui->checkBox_MacroInt->setChecked(Config->EvtListColStat[11]);
    ui->checkBox_NrSta->setChecked(Config->EvtListColStat[12]);
    ui->checkBox_MM->setChecked(Config->EvtListColStat[13]);
    ui->checkBox_MW->setChecked(Config->EvtListColStat[14]);
    ui->checkBox_ML->setChecked(Config->EvtListColStat[15]);
    ui->checkBox_MN->setChecked(Config->EvtListColStat[16]);
    ui->checkBox_MC->setChecked(Config->EvtListColStat[17]);
    ui->checkBox_Mb->setChecked(Config->EvtListColStat[18]);
    ui->checkBox_MB->setChecked(Config->EvtListColStat[19]);
    ui->checkBox_Ms->setChecked(Config->EvtListColStat[20]);
    ui->checkBox_MS->setChecked(Config->EvtListColStat[21]);
    ui->checkBox_Locality->setChecked(Config->EvtListColStat[22]);
    ui->checkBox_SFile->setChecked(Config->EvtListColStat[23]);
}




// *******************************
// Destructor function.
// *******************************
SelectColumnsDlg::~SelectColumnsDlg()
{
    delete ui;
}




void SelectColumnsDlg::accept(void)
{
    // User has pressed the 'OK' button.
    // Return checbox statuses to parent class.
    Config->EvtListColStat[0] = ui->checkBox_RowNum->isChecked();
    Config->EvtListColStat[1] = ui->checkBox_Action->isChecked();
    Config->EvtListColStat[2] = ui->checkBox_Model->isChecked();
    Config->EvtListColStat[3] = ui->checkBox_Agency->isChecked();
    Config->EvtListColStat[4] = ui->checkBox_RMS->isChecked();
    Config->EvtListColStat[5] = ui->checkBox_Gap->isChecked();
    Config->EvtListColStat[6] = ui->checkBox_LatError->isChecked();
    Config->EvtListColStat[7] = ui->checkBox_LonError->isChecked();
    Config->EvtListColStat[8] = ui->checkBox_DepthError->isChecked();
    Config->EvtListColStat[9] = ui->checkBox_Dist->isChecked();
    Config->EvtListColStat[10] = ui->checkBox_Event->isChecked();
    Config->EvtListColStat[11] = ui->checkBox_MacroInt->isChecked();
    Config->EvtListColStat[12] = ui->checkBox_NrSta->isChecked();
    Config->EvtListColStat[13] = ui->checkBox_MM->isChecked();
    Config->EvtListColStat[14] = ui->checkBox_MW->isChecked();
    Config->EvtListColStat[15] = ui->checkBox_ML->isChecked();
    Config->EvtListColStat[16] = ui->checkBox_MN->isChecked();
    Config->EvtListColStat[17] = ui->checkBox_MC->isChecked();
    Config->EvtListColStat[18] = ui->checkBox_Mb->isChecked();
    Config->EvtListColStat[19] = ui->checkBox_MB->isChecked();
    Config->EvtListColStat[20] = ui->checkBox_Ms->isChecked();
    Config->EvtListColStat[21] = ui->checkBox_MS->isChecked();
    Config->EvtListColStat[22] = ui->checkBox_Locality->isChecked();
    Config->EvtListColStat[23] = ui->checkBox_SFile->isChecked();

    // Close the dialog and return 'Accepted' signal.
    QDialog::accept();
}
