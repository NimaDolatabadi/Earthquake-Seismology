#ifndef LOGVIEWFILTER_H
#define LOGVIEWFILTER_H

#include <QObject>

class logviewfilter : public QObject
{
   Q_OBJECT

public:
   explicit logviewfilter(QObject *parent = 0);
   bool eventFilter(QObject*, QEvent*);

signals:
   void SetTimeInterval();
};

#endif // LOGVIEWFILTER_H
