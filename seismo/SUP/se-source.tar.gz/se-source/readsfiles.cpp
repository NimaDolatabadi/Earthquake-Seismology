#include <QDebug>
#include "fortran.h"
#include "library.h"
#include "readsfiles.h"


// **********************************************************
// This function is used to initialize the class with
// a full list of all s-files in the seisan database.
// This function must be called before read is started.
// **********************************************************
void readsfiles::Init(QStringList* SfileList, QMutex *mtx_db_cblock)
{
   sfilelist = SfileList;
   mtx_common_block = mtx_db_cblock;
}




// **********************************************************
// Reads all S-files into database-nodes and adds
// them to the database using the AddDbEvent signal.
// **********************************************************
void readsfiles::run()
{
   bool Problem;
   event_node_ *Node;
   char file[81], status;
   int num_files, filenr, progress;
   QStringList problems;

   // Reset the cancel flag.
   mtx_terminate.lock();
   terminate = false;
   terminated = false;
   mtx_terminate.unlock();

   // Initialize variables.
   progress = 0;
   Problem = false;
   num_files = sfilelist->size();

   // Read S-files into nodes and add nodes to database.
   // Operation will stop if we run out of memory, or
   // if we recieve a request to terminate the operation.
   for (filenr=0;filenr<num_files;filenr++) {
      // Read S-file into memory. Error messages from
      // ReadSfile() function will be returned in 'problems'.
      strcpy(file, sfilelist->at(filenr).toLatin1().constData());
      mtx_common_block->lock();
      Node = ReadSfile(file, &status, &problems);
      mtx_common_block->unlock();

      // If file was sucessfully read, add node to database.
      // Files with invalid dates will not be added.
      if (Node) emit AddDbEvent(Node);

      // Handle warnings and errors.
      if (status) {
         if (status == 1) {
            // The file could not be opened.
            Problem = true;
            emit FileProblem(sfilelist->at(filenr), problems, 1);
         }
         if (status == 2) {
            // The current file has errors and cannot be read.
            Problem = true;
            emit FileProblem(sfilelist->at(filenr), problems, 2);
         }
         if (status == 3) {
            // We are out of memory, reading will stop here.
            // Signal database class that reading is done.
            emit ReadSfilesDone(1);
            return;
         }
         if (status == 4) {
            // The current file has some non-fatal problem, but has been read.
            emit FileProblem(sfilelist->at(filenr), problems, 4);
         }
         if (status == 5) {
            // The current event file has an invalid date.
            Problem = true;
            emit FileProblem(sfilelist->at(filenr), problems, 5);
         }
      }

      // For every 300 file, check if thread has been asked to terminate.
      if (++progress > 300) {
         // Check if thread has been asked to terminate.
         mtx_terminate.lock();
         if (terminate) {
            mtx_terminate.unlock();
            return;
         }
         progress = 0;
         mtx_terminate.unlock();
      }
   }

   // Signal database class that reading is done.
   if (Problem) emit ReadSfilesDone(2);
   if (!Problem) emit ReadSfilesDone(0);
}




// **********************************************************
// This function can be called to stop the thread function.
// Thread will stop at the earliest convenience.
// **********************************************************
void readsfiles::Cancel()
{
   // Check if thread is running.
   if (isRunning()) {
      // Raise the terminate flag.
      mtx_terminate.lock();
      terminate = true;
      mtx_terminate.unlock();
   }
}
