#ifndef MAGVSMAGDLG_H
#define MAGVSMAGDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class MagVsMagDlg;
}

class MagVsMagDlg : public QDialog
{
    Q_OBJECT

public:
    explicit MagVsMagDlg(db *database, QWidget *parent = 0);
    ~MagVsMagDlg();

private slots:
    void MagVsMagDlg_plot();
    void outputPrint();

private:
    Ui::MagVsMagDlg *ui;
    db *DataBase;
};

#endif
