/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "timeofdaydistrdlg.h"
#include "ui_timeofdaydistrdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>

#include <iostream>
#include "qcustomplot.h"

TimeOfDayDistrDlg::TimeOfDayDistrDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::TimeOfDayDistrDlg) {

    ui->setupUi(this);

    ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Time of day distribution"));

    ui->radioButton_PDF->setChecked(true);
    ui->spinBox_X_Size->setRange(1.0,8000.0);
    ui->spinBox_X_Size->setValue(700.0);
    ui->spinBox_X_Size->setSingleStep(1.0);
    ui->spinBox_Y_Size->setRange(1.0,8000.0);
    ui->spinBox_Y_Size->setValue(700.0);
    ui->spinBox_Y_Size->setSingleStep(1.0);
    ui->radioButton_1h->setChecked(true);
    ui->checkBox_log10->setChecked(true);

    DataBase=database;

    // initial plot
    TimeOfDayDistrDlg_plot();

    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );

    // plot when "Replot" is clicked
    connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( TimeOfDayDistrDlg_plot() ) );

}

TimeOfDayDistrDlg::~TimeOfDayDistrDlg() {
    delete ui;
}

void TimeOfDayDistrDlg::outputPrint() {
    int xsize = ui->spinBox_X_Size->value();
    int ysize = ui->spinBox_Y_Size->value();
    if (ui->radioButton_PDF->isChecked())
        ui->customPlot->savePdf("se-TimeOfDayDistrDlg.pdf",0,xsize,ysize);
    if (ui->radioButton_PS->isChecked())
        ui->customPlot->savePdf("se-TimeOfDayDistrDlg.ps",0,xsize,ysize);
    if (ui->radioButton_PNG->isChecked())
        ui->customPlot->savePng("se-TimeOfDayDistrDlg.png",xsize,ysize,1,-1);
    if (ui->radioButton_JPG->isChecked())
        ui->customPlot->saveJpg("se-TimeOfDayDistrDlg.jpg",xsize,ysize,1,-1);
    if (ui->radioButton_BMP->isChecked())
        ui->customPlot->saveBmp("se-TimeOfDayDistrDlg.bmp",xsize,ysize,1);
}



void TimeOfDayDistrDlg::TimeOfDayDistrDlg_plot() {

    float magLow=-999.9, magHigh=-999.9;

    // magnitude type:
     int Show10m = 0, Show15m=0, Show30m=0, Show1h=0, Show2h=0, Show3h=0, Show4h=0, Show6h=0;
     if (ui->radioButton_10m->isChecked())  Show10m  = 1;
     if (ui->radioButton_15m->isChecked()) Show15m = 1;
     if (ui->radioButton_30m->isChecked()) Show30m = 1;
     if (ui->radioButton_1h->isChecked()) Show1h = 1;
     if (ui->radioButton_2h->isChecked()) Show2h = 1;
     if (ui->radioButton_3h->isChecked()) Show3h = 1;
     if (ui->radioButton_4h->isChecked()) Show4h = 1;
     if (ui->radioButton_6h->isChecked()) Show6h = 1;

    int NumEvents = DataBase->NumEvents();
    event_node_ *Node;

    // Determine incremental values yinc
    int intervals=24;
    float width = 1.0;
    if ( Show10m ) intervals=6*24;
    if ( Show15m ) intervals=4*24;
    if ( Show30m ) intervals=2*24;
    if ( Show2h )  intervals=24/2;
    if ( Show3h )  intervals=24/3;
    if ( Show4h )  intervals=24/4;
    if ( Show6h )  intervals=24/6;
    QVector<double> xinc(intervals);
    QVector<double> yinc(intervals);

    if ( Show10m ) width=1/6.0;
    if ( Show15m ) width=0.25;
    if ( Show30m ) width=0.5;
    if ( Show2h )  width=2;
    if ( Show3h )  width=3;
    if ( Show4h )  width=4;
    if ( Show6h )  width=6;

    double dum;
    xinc[0]=width/2;
    for (int i=1; i<intervals; ++i) {
        yinc[i]=0.0;
        xinc[i]=xinc[i-1]+width;
    }

    for (int i=0; i<NumEvents; ++i) {
        Node = DataBase->EventByIndex(i);
        dum=(double)Node->hypocenters.first->time.year;
        if (Show10m) {
            dum = (double) Node->hypocenters.first->time.minute;
            dum = dum + 60.0*(double) Node->hypocenters.first->time.hour;
            yinc[ (int) (dum/10) ]+=1.0;
        }
        if (Show15m) {
            dum = (double) Node->hypocenters.first->time.minute;
            dum = dum + 60.0*(double) Node->hypocenters.first->time.hour;
            yinc[(int) (dum/15)]+=1.0;
        }
        if (Show30m) {
            dum = (double) Node->hypocenters.first->time.minute;
            dum = dum + 60.0*(double) Node->hypocenters.first->time.hour;
            yinc[(int) (dum/30)]+=1.0;
        }
        if (Show1h) {
            dum = (double) Node->hypocenters.first->time.hour;
            yinc[dum]+=1.0;
        }
        if (Show2h) {
            dum = (double) Node->hypocenters.first->time.hour;
            yinc[ (int)(dum/2) ]+=1.0;
        }
        if (Show3h) {
            dum = (double) Node->hypocenters.first->time.hour;
            yinc[ (int)(dum/3) ]+=1.0;
        }
        if (Show4h) {
            dum = (double) Node->hypocenters.first->time.hour;
            yinc[ (int)(dum/4) ]+=1.0;
        }
        if (Show6h) {
            dum = (double) Node->hypocenters.first->time.hour;
            yinc[ (int)(dum/6) ]+=1.0;
        }
    }

    float Ymax=0.0, dummy;
    for (int i=0; i<intervals; ++i) {
        dummy=yinc[i];
        if ( dummy > Ymax )
            Ymax = dummy;
    }


    QPen pen;
    pen.setColor(QColor(255,0,0));

    ui->customPlot->clearPlottables();

    Qt::CheckState ShowLog10;
    ShowLog10 = ui->checkBox_log10->checkState();
    if (ShowLog10 == Qt::Checked){
        ui->customPlot->yAxis->setScaleType(QCPAxis::stLogarithmic);
        ui->customPlot->yAxis->setScaleLogBase(10);
        ui->customPlot->yAxis->setNumberFormat("eb"); // e = exponential, b = beautiful decimal powers
        ui->customPlot->yAxis->setNumberPrecision(0); // makes sure "1*10^4" is displayed only as "10^4"
        ui->customPlot->yAxis->setSubTickCount(10);
        ui->customPlot->yAxis->setRange(0.5, (4.0*Ymax));
    }
    else {
        ui->customPlot->yAxis->setScaleType(QCPAxis::stLinear);
        ui->customPlot->yAxis->setNumberFormat("f");
        ui->customPlot->yAxis->setRange(0, Ymax+Ymax/5.0);
    }

    // labels:
    //ui->customPlot->setTitle("Time of day distribution");
    //ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Time of day distribution"));
    ui->customPlot->xAxis->setLabel("Time of day [Hour]");
    ui->customPlot->yAxis->setLabel("Number of events");
    ui->customPlot->xAxis->setRange(-0.25, 24.25);

    // add histogram:
    QCPBars *MagHistogram = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);

    pen.setWidthF(1.2);
    pen.setColor(QColor(0, 0, 0));

    ui->customPlot->addPlottable(MagHistogram);
    MagHistogram->setName(QString("Magnitudes: [%1, %2]").arg(magLow).arg(magHigh));
    MagHistogram->setPen(pen);
    MagHistogram->setBrush(QColor(255, 0, 0));
    MagHistogram->setWidth(1);
    if ( Show10m ) MagHistogram->setWidth(1/6.0);
    if ( Show15m ) MagHistogram->setWidth(0.25);
    if ( Show30m ) MagHistogram->setWidth(0.5);
    if ( Show2h )  MagHistogram->setWidth(2);
    if ( Show3h )  MagHistogram->setWidth(3);
    if ( Show4h )  MagHistogram->setWidth(4);
    if ( Show6h )  MagHistogram->setWidth(6);
    MagHistogram->setData(xinc, yinc);

    //ui->customPlot->setRangeDrag(Qt::Horizontal|Qt::Vertical);
    //ui->customPlot->setRangeZoom(Qt::Horizontal|Qt::Vertical);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    ui->customPlot->replot();
}
