#ifndef COMPLETENESSCHECKDLG_H
#define COMPLETENESSCHECKDLG_H

#include <QDialog>
#include <QtCore>
#include <QtGui>
#include "logmodel.h"
#include "database.h"
#include "qcustomplot.h"

namespace Ui {
    class CompletenessCheckDlg;
}

class CompletenessCheckDlg : public QDialog
{
    Q_OBJECT

public:
    explicit CompletenessCheckDlg(db *database, QWidget *parent = 0);
    ~CompletenessCheckDlg();

signals:
    void WriteLog(logmodel::msg_type, QString);

private slots:
    void plotcompleteness();
    void outputPrint();
    void selectionChanged();

private:
    Ui::CompletenessCheckDlg *ui;
    db *DataBase;
};

#endif
