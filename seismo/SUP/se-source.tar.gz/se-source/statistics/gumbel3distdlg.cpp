/*
 * 2014-12-18 Peter Voss: Good luck
 * 2015-01-16 Peter Voss: added table
 *
#include <QDebug>
*/
#include "gumbel3distdlg.h"
#include "ui_gumbel3distdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>
#include <iostream>
#include "qcustomplot.h"

Gumbel3DistDlg::Gumbel3DistDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::Gumbel3DistDlg)
{
   ui->setupUi(this);

   // Write message to log.
   Message = "Seisan Explorer:";
   Message.append(" Starting Gumble Type III function");
   emit WriteLog(logmodel::info, Message);

   ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
   ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Gumbel III"));

   ui->radioButton_M->setChecked(true);

   QStringList TableHeader;
   TableHeader << "Parameter" << "Value";
   ui->tableWidget->setColumnCount(2);
   ui->tableWidget->setHorizontalHeaderLabels(TableHeader);
   ui->tableWidget->setColumnWidth(0,100);
   ui->tableWidget->setColumnWidth(1,100);
   ui->tableWidget->setRowCount(7);

   ui->radioButton_PDF->setChecked(true);

   ui->spinBox_X_Size->setRange(1.0,8000.0);
   ui->spinBox_X_Size->setValue(700.0);
   ui->spinBox_X_Size->setSingleStep(1.0);
   ui->spinBox_Y_Size->setRange(1.0,8000.0);
   ui->spinBox_Y_Size->setValue(700.0);
   ui->spinBox_Y_Size->setSingleStep(1.0);

   DataBase=database;

   // Initial call
   plotGumble3();

   connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
   connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );
   connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( plotGumble3() ) );
}

Gumbel3DistDlg::~Gumbel3DistDlg()
{
   delete ui;
}

void Gumbel3DistDlg::outputPrint()
{
   int xsize = ui->spinBox_X_Size->value();
   int ysize = ui->spinBox_Y_Size->value();
   if (ui->radioButton_PDF->isChecked()) ui->customPlot->savePdf("se-gumbel-type3.pdf",0,xsize,ysize);
   if (ui->radioButton_PS->isChecked()) ui->customPlot->savePdf("se-gumbel-type3.ps",0,xsize,ysize);
   if (ui->radioButton_PNG->isChecked()) ui->customPlot->savePng("se-gumbel-type3.png",xsize,ysize,1,-1);
   if (ui->radioButton_JPG->isChecked()) ui->customPlot->saveJpg("se-gumbel-type3.jpg",xsize,ysize,1,-1);
   if (ui->radioButton_BMP->isChecked()) ui->customPlot->saveBmp("se-gumbel-type3.bmp",xsize,ysize,1);
}

void Gumbel3DistDlg::plotGumble3()
{
   // magnitude type:
   int ShowM = 0, ShowML=0, ShowMW=0, ShowMC=0, ShowMb=0, ShowMB=0, ShowMs=0, ShowMS=0;
   if (ui->radioButton_M->isChecked())  ShowM  = 1;
   if (ui->radioButton_ML->isChecked()) ShowML = 1;
   if (ui->radioButton_MW->isChecked()) ShowMW = 1;
   if (ui->radioButton_MC->isChecked()) ShowMC = 1;
   if (ui->radioButton_Mb->isChecked()) ShowMb = 1;
   if (ui->radioButton_MB->isChecked()) ShowMB = 1;
   if (ui->radioButton_Ms->isChecked()) ShowMs = 1;
   if (ui->radioButton_MS->isChecked()) ShowMS = 1;

   int Show475 = 0;
   if (ui->checkBox_Show475->isChecked()) Show475 = 1;

   float magnitude=-999.9;

   int NumEvents = DataBase->NumEvents();
   event_node_ *Node;

   float MaxMag=-999.9;
   float MinMag=999.9;

   //float magLow, magHigh;

   int Year;
   int FirstYear;                  // MINT
   int LastYear;                   // MAXT

   int NumberOfYears;              // KA=MAXT-MINT+1
   int NumberOfExtrames=0;         // L
   int NumberOfMissingExtrames=0;  // M=KA-L

   int k=0;

   Node = DataBase->EventByIndex(0);
   FirstYear=Node->hypocenters.first->time.year;
   //qDebug() << "Year first eq:" << Node->hypocenters.first->time.year;

   Node = DataBase->EventByIndex(NumEvents-1);
   LastYear=Node->hypocenters.first->time.year;
   //qDebug() << "Year last eq:" << Node->hypocenters.first->time.year;

   NumberOfYears=LastYear-FirstYear+1;
   //qDebug() << "Number Of Years=" << NumberOfYears;

   ui->tableWidget->setItem(0,0,new QTableWidgetItem(QString("First year")));
   ui->tableWidget->setItem(0,1,new QTableWidgetItem(QString("%1").arg(FirstYear)));
   ui->tableWidget->setItem(1,0,new QTableWidgetItem(QString("Last year")));
   ui->tableWidget->setItem(1,1,new QTableWidgetItem(QString("%1").arg(LastYear)));
   ui->tableWidget->setItem(2,0,new QTableWidgetItem(QString("Number of years")));
   ui->tableWidget->setItem(2,1,new QTableWidgetItem(QString("%1").arg(NumberOfYears)));
   ui->tableWidget->setItem(3,0,new QTableWidgetItem(QString("Gaps")));
   ui->tableWidget->setItem(4,0,new QTableWidgetItem(QString("W")));
   ui->tableWidget->setItem(5,0,new QTableWidgetItem(QString("U")));
   ui->tableWidget->setItem(6,0,new QTableWidgetItem(QString("L")));

   if (NumberOfYears < 10)
       return;

   QVector<double> YearlyMaxMag(NumberOfYears); // the maximum magnitude for each year
   for (int i=0;i < NumberOfYears; ++i) {
       YearlyMaxMag[i]=-999.9;   // set to dummy
   }

   k=0;
   // find largest magnitude for each year:
   for (int i=0;i < NumEvents; ++i) {
        magnitude=-999.9;
       Node = DataBase->EventByIndex(i);
       Year=Node->hypocenters.first->time.year;
       if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
       if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
       if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
       if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
       if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
       if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
       if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
       if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
       if (YearlyMaxMag[Year-FirstYear] < magnitude)
           YearlyMaxMag[Year-FirstYear] = magnitude;
       if (MaxMag < magnitude)
           MaxMag = magnitude;
       if (MinMag > magnitude)
           MinMag = magnitude;
       if ( magnitude > -999.)
           k++;
   }

   ui->customPlot->clearPlottables();
   ui->customPlot->clearItems();
   if (k < 10){
       //qDebug() << QString("Not enough values: %1").arg(k);
       QCPItemText *eqText0 = new QCPItemText(ui->customPlot);
       ui->customPlot->addItem(eqText0);
       ui->customPlot->xAxis->setRange(-1,6);
       ui->customPlot->yAxis->setRange(4,7);
       eqText0->position->setCoords(4.2, 4.2);
       eqText0->setText(QString("Not enough values: %1").arg(k));
       eqText0->setFont(QFont(font().family(), 10));
       eqText0->setPositionAlignment(Qt::AlignTop|Qt::AlignRight);
       ui->customPlot->replot();
       return;
   }

   // Sort the yearly magnitudes
   qSort(YearlyMaxMag);

   // count NumberOfExtrames
   for (int i=0;i < NumberOfYears; ++i) {
       if(YearlyMaxMag[i]>2.0)
           NumberOfExtrames++;
   }
   NumberOfMissingExtrames=NumberOfYears-NumberOfExtrames;

   ui->tableWidget->setItem(3,1,new QTableWidgetItem(QString("%1").arg(NumberOfMissingExtrames)));

   QVector<double> YM(NumberOfExtrames); //
   k=0;
   for (int i=NumberOfMissingExtrames;i < NumberOfYears; ++i) {
       YM[k]=YearlyMaxMag[i];
       k++;
   }

   QVector<double> PRO(NumberOfExtrames); //
   QVector<double> negLnPv(NumberOfExtrames); //
   QVector<double> negLnnegLnPv(NumberOfExtrames); //

   QVector<double> HazM(NumberOfExtrames); //

   //qDebug() << "Max magnitude " << MaxMag;

   int m=NumberOfYears-NumberOfExtrames+1;

   for (int i=0;i < NumberOfExtrames; ++i) {
       //qDebug() << i<< YearlyMaxMag.at(i);
       //qDebug() << YearlyMaxMag.at(i);
       PRO[i]=(m-0.44)/(NumberOfYears+0.12);
       negLnPv[i]=-1.0*qLn(PRO[i]);
       negLnnegLnPv[i]=-1.0*qLn(negLnPv[i]);
       //ReturnPeriod[i]=1.0/(1.0-PRO[i]);
       HazM[i]=6.796-(6.796-3.61)*pow(negLnPv[i],0.6466);
       m++;
   }

   // Start curve fitting:
   // initial guess:
   double W,Wcur=7.0;
   double U,Ucur=3.0;
   double L,Lcur=0.5;
   W=Wcur;U=Ucur;L=Lcur;
   double CHISQ=0.0, FIT;
   // compute fit
   for (int i=0;i < NumberOfExtrames; ++i) {
       FIT=W-(W-U)*pow(negLnPv[i],L);
       CHISQ=CHISQ+1.0/YM[i]*(YM[i]-FIT)*(YM[i]-FIT);
   }
   CHISQ=CHISQ/NumberOfExtrames;
   //qDebug() << "CHISQ:" << CHISQ;
   double Z=CHISQ;
   //UUcur=UU;  //misfit
   double RandomStep;
   k=0;
   while (Z > 0.0001 && k < 999){
       k++;
       RandomStep=(qrand()/(double)RAND_MAX)-0.5;
       W=Wcur+RandomStep/10.;
       RandomStep=(qrand()/(double)RAND_MAX)-0.5;
       U=Ucur+RandomStep/10.;
       RandomStep=(qrand()/(double)RAND_MAX)-0.5;
       L=Lcur+RandomStep/100.;
       CHISQ=0.0;
       for (int i=0;i < NumberOfExtrames; ++i) {
           FIT=W-(W-U)*pow(negLnPv[i],L);
           CHISQ=CHISQ+1.0/YM[i]*(YM[i]-FIT)*(YM[i]-FIT);
       }
       CHISQ=CHISQ/NumberOfExtrames;
       //qDebug() << "CHISQ:" << CHISQ;
       //UU=Z-CHISQ;
       if (CHISQ < Z){
           Wcur=W;Ucur=U;Lcur=L;
           Z=CHISQ;
       }
       //qDebug() << "CHISQ:" << CHISQ << "Z"<< Z<< W << U << L ;//<< qrand()<<RandomStep;
   }
   //qDebug() << "CHISQ:" << CHISQ << "Z"<< Z<< W << U << L ;//<< qrand()<<RandomStep;
   // End curve-fitting
   W=Wcur;U=Ucur;L=Lcur;

   // compute Gumbel curve
   QVector<double> HazM3(NumberOfExtrames); //
   QVector<double> negLnnegLnPRO(NumberOfExtrames); //
   for (int i=0;i < NumberOfExtrames; ++i) {
       negLnnegLnPRO[i]=negLnnegLnPv[i];
       HazM3[i]=W-(W-U)*pow(negLnPv[i],L);
   }
   // append values at both endes of curve Gumble curve
   double dummy;
   for (int i=0;i < 9; ++i) {
       dummy=(double)(negLnPv[0]+negLnPv[0]*i/10.);
       HazM3.prepend(W-(W-U)*pow(dummy,L));
       negLnnegLnPRO.prepend(-1.0*qLn(dummy));
       dummy=(double)(negLnPv[NumberOfExtrames-1]-negLnPv[NumberOfExtrames-1]*i/10.);
       HazM3.append(W-(W-U)*pow(dummy,L));
       negLnnegLnPRO.append(-1.0*qLn(dummy));
   }
   QVector<double> ReturnPeriod(HazM3.size());
   for (int i=0;i < HazM3.size(); ++i) {
       ReturnPeriod[i]=1./(1.-(exp(-1.0*pow((W-HazM3[i])/(W-U),(1./L)))));
       //qDebug() << "ReturnPeriod:" << ReturnPeriod[i] << HazM3[i];
   }
   for (int i=0;i < NumberOfExtrames; ++i) {
       //qDebug() << "ReturnPeriod:" << 1./(1.-PRO[i]) << PRO[i] << ReturnPeriod[i] << HazM3[i] << (exp(-1.0*pow((W-HazM3[i])/(W-U),(1./L))));
   }

   float AxMin=-1.6;
   float AxMax=6.6;
   //   AxMin=negLnnegLnPv[0]-1.5;
   AxMin=negLnnegLnPv[0]-1.5;
   AxMax=negLnnegLnPv[NumberOfExtrames-1]+1.5;
   //qDebug()<< AxMax;
   float AyMin=MinMag-0.4;
   //float AyMax=MaxMag+0.6;
   float AyMax=W+0.6;
   QPen pen;

   ui->customPlot->clearPlottables();
   if (Show475)
       ui->customPlot->xAxis->setRange(AxMin, -1.*qLn(-1.*qLn(1.-1./475.))+(-1.*qLn(-1.*qLn(1.-1./475.))/20.));
   else
       ui->customPlot->xAxis->setRange(AxMin,AxMax);

   ui->customPlot->yAxis->setRange(AyMin,AyMax);
   ui->customPlot->xAxis->setLabel("-Ln(-Ln P)");
   ui->customPlot->yAxis->setLabel("M");

  QCPGraph *topGraph = ui->customPlot->addGraph();
  topGraph->setData(negLnnegLnPv, YM);
  topGraph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, QPen(Qt::black), QBrush(Qt::white), 6));
  topGraph->setLineStyle(QCPGraph::lsNone);

  QCPGraph *topGraph3 = ui->customPlot->addGraph();
  topGraph3->setData(negLnnegLnPRO, HazM3);
  topGraph3->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssNone));
  pen.setColor(Qt::blue);
  topGraph3->setLineStyle(QCPGraph::lsLine);
  topGraph3->setPen(pen);

  QVector<double> GumMaxVal,GumMaxMag; //
  GumMaxMag << W << W;
  GumMaxVal << AxMin << AxMax;
  QCPGraph *topGraph4 = ui->customPlot->addGraph();
  topGraph4->setData(GumMaxVal,GumMaxMag);
  topGraph4->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssNone));
  topGraph4->setLineStyle(QCPGraph::lsLine);
  pen.setColor(Qt::black);
  pen.setStyle(Qt::DashLine);
  topGraph4->setPen(pen);

  ui->tableWidget->setItem(4,1,new QTableWidgetItem(QString("%1").arg(W)));
  ui->tableWidget->setItem(5,1,new QTableWidgetItem(QString("%1").arg(U)));
  ui->tableWidget->setItem(6,1,new QTableWidgetItem(QString("%1").arg(L)));

  QCPItemText *eqText2 = new QCPItemText(ui->customPlot);
  ui->customPlot->addItem(eqText2);
  eqText2->position->setCoords(AxMax,W);
  eqText2->setText(QString("W"));
  eqText2->setFont(QFont(font().family(), 10));
  eqText2->setPositionAlignment(Qt::AlignBottom|Qt::AlignRight);

  if (Show475) {
  //HazM[i]=6.796-(6.796-3.61)*pow(negLnPv[i],0.6466);
  QVector<double> GumMag475x,GumMag475y; //
  GumMag475x << -1.*qLn(-1.*qLn(1.-1./475.)) << -1.*qLn(-1.*qLn(1.-1./475.));
  GumMag475y << -1. << W+W/20.;
  QCPGraph *topGraph5 = ui->customPlot->addGraph();
  topGraph5->setData(GumMag475x,GumMag475y);
  topGraph5->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssNone));
  topGraph5->setLineStyle(QCPGraph::lsLine);
  pen.setColor(Qt::black);
  pen.setStyle(Qt::DashLine);
  topGraph5->setPen(pen);
  }

   ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
   ui->customPlot->replot();
}

