#ifndef POISSONDLG_H
#define POISSONDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class poissondlg;
}

class poissondlg : public QDialog
{
    Q_OBJECT

public:
    explicit poissondlg(db *database, QWidget *parent = 0);
    ~poissondlg();

private slots:
    void setupPoisson();
    void outputPrint();

private:
    Ui::poissondlg *ui;
    db *DataBase;
};

#endif // POISSONDLG_H
