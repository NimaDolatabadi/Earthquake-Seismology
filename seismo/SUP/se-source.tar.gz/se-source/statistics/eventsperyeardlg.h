#ifndef EVENTSPERYEARDLG_H
#define EVENTSPERYEARDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class EventsPerYearDlg;
}

class EventsPerYearDlg : public QDialog
{
    Q_OBJECT

public:
    explicit EventsPerYearDlg(db *database, QWidget *parent = 0);
    ~EventsPerYearDlg();

private slots:
    void EventsPerYearDlg_table();
    void EventsPerYearDlg_plot();
    void EventsPerYearDlg_init_table();
    void outputPrint();

private:
    Ui::EventsPerYearDlg *ui;
    db *DataBase;
};

#endif
