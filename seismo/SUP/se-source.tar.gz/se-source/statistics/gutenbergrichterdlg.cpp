/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1

#include <QDebug>
*/
#include "gutenbergrichterdlg.h"
#include "ui_gutenbergrichterdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>
#include <iostream>
#include "qcustomplot.h"

GutenbergRichterDlg::GutenbergRichterDlg(db *database, QWidget *parent) : QDialog(parent), ui(new Ui::GutenbergRichterDlg)
{
   ui->setupUi(this);

   ui->customPlot->plotLayout()->insertRow(0); // inserts an empty row above the default axis rect
   ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Gutenberg-Richter relation"));

   ui->radioButton_M->setChecked(true);

   ui->doubleSpinBox_StartMag->setValue(0.0);
   ui->doubleSpinBox_StartMag->setSingleStep(0.1);
   ui->doubleSpinBox_StartMag->setRange(-5.0,11.0);

   ui->doubleSpinBox_Interval->setValue(1.0);
   ui->doubleSpinBox_Interval->setSingleStep(0.1);
   ui->doubleSpinBox_Interval->setRange(0.01,4.9);

   ui->doubleSpinBox_bStart->setValue(0.0);
   ui->doubleSpinBox_bStart->setSingleStep(0.1);
   ui->doubleSpinBox_bStart->setRange(-5.0,11.0);

   ui->doubleSpinBox_bMAX->setValue(9.9);
   ui->doubleSpinBox_bMAX->setSingleStep(0.1);
   ui->doubleSpinBox_bMAX->setRange(-5.0,11.0);

   ui->radioButton_PDF->setChecked(true);
   ui->spinBox_X_Size->setRange(1.0,8000.0);
   ui->spinBox_X_Size->setValue(700.0);
   ui->spinBox_X_Size->setSingleStep(1.0);
   ui->spinBox_Y_Size->setRange(1.0,8000.0);
   ui->spinBox_Y_Size->setValue(700.0);
   ui->spinBox_Y_Size->setSingleStep(1.0);

   DataBase=database;

   // Initial call
   plotGutenbergRichter();

   connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
   connect( ui->pushButton_Print, SIGNAL( clicked() ), this, SLOT( outputPrint() ) );
   connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( plotGutenbergRichter() ) );
}


GutenbergRichterDlg::~GutenbergRichterDlg()
{
   delete ui;
}


void GutenbergRichterDlg::outputPrint()
{
   int xsize = ui->spinBox_X_Size->value();
   int ysize = ui->spinBox_Y_Size->value();
   if (ui->radioButton_PDF->isChecked()) ui->customPlot->savePdf("se-gutenberg-richter.pdf",0,xsize,ysize);
   if (ui->radioButton_PS->isChecked()) ui->customPlot->savePdf("se-gutenberg-richter.ps",0,xsize,ysize);
   if (ui->radioButton_PNG->isChecked()) ui->customPlot->savePng("se-gutenberg-richter.png",xsize,ysize,1,-1);
   if (ui->radioButton_JPG->isChecked()) ui->customPlot->saveJpg("se-gutenberg-richter.jpg",xsize,ysize,1,-1);
   if (ui->radioButton_BMP->isChecked()) ui->customPlot->saveBmp("se-gutenberg-richter.bmp",xsize,ysize,1);
}


void GutenbergRichterDlg::plotGutenbergRichter()
{
   // magnitude type:
   int ShowM = 0, ShowML=0, ShowMW=0, ShowMC=0, ShowMb=0, ShowMB=0, ShowMs=0, ShowMS=0;
   if (ui->radioButton_M->isChecked())  ShowM  = 1;
   if (ui->radioButton_ML->isChecked()) ShowML = 1;
   if (ui->radioButton_MW->isChecked()) ShowMW = 1;
   if (ui->radioButton_MC->isChecked()) ShowMC = 1;
   if (ui->radioButton_Mb->isChecked()) ShowMb = 1;
   if (ui->radioButton_MB->isChecked()) ShowMB = 1;
   if (ui->radioButton_Ms->isChecked()) ShowMs = 1;
   if (ui->radioButton_MS->isChecked()) ShowMS = 1;

   float startmag = ui->doubleSpinBox_StartMag->value();
   float MagInterval = ui->doubleSpinBox_Interval->value();

   float bStart = ui->doubleSpinBox_bStart->value();
   if (bStart < startmag) ui->doubleSpinBox_bStart->setValue(startmag);
   bStart = ui->doubleSpinBox_bStart->value();

   int bStartNum=0;

   float bMax = ui->doubleSpinBox_bMAX->value();
   if (bMax < bStart) ui->doubleSpinBox_bMAX->setValue(9.9);
   bMax = ui->doubleSpinBox_bMAX->value();

   int bMaxNum;

   //qDebug() << "startmag "<< startmag<<"interval "<< MagInterval<<"bstart "<< bStart<< "bMax "<< bMax;

   // checkBox_ShowIncremental
   Qt::CheckState ShowIncremental;
   ShowIncremental = ui->checkBox_ShowIncremental->checkState();

   // checkBox_ShowCumulative
   Qt::CheckState ShowCumulative;
   ShowCumulative = ui->checkBox_ShowCumulative->checkState();

   // checkBox_B_incremental
   Qt::CheckState B_incremental;
   B_incremental = ui->checkBox_B_incremental->checkState();

   // checkBox_B_cumulative
   Qt::CheckState B_cumulative;
   B_cumulative = ui->checkBox_B_cumulative->checkState();

   float magnitude=-999.9;

   int NumEvents = DataBase->NumEvents();
   event_node_ *Node;

   double MAXy=0.0;
   float MaxMag=-999.9;

   float magLow, magHigh;

   // find largest magnitude:
   for (int i=0; i<NumEvents; ++i) {
      Node = DataBase->EventByIndex(i);
      if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
      if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
      if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
      if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
      if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
      if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
      if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
      if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
      if (MaxMag < magnitude) MaxMag = magnitude;
   }

   //qDebug() << "Max magnitude " << MaxMag;

   // Count number of intervals:
   magLow=startmag;
   magHigh=startmag+MagInterval;
   int count=0;
   while (magLow<MaxMag){
      magLow=magHigh;
      magHigh=magHigh+MagInterval;
      count++;
   }
   int NumInterval=count;
   //qDebug() << "NumIntervals "<< NumInterval;

   // Determine inteval number for bStart and bMax
   bMaxNum=NumInterval;
   magLow=startmag;
   magHigh=startmag+MagInterval;
   count=0;
   while (magLow<MaxMag){
      // check if bStart is in this interval
      if (bStart >= magLow && bStart < magHigh){
         bStartNum=count;
         //qDebug() << "magLow "<< magLow << "magHigh"<<magHigh<< "bStartNum "<< bStartNum;
      }
      // check if bMax is in this interval
      if(bMax >= magLow && bMax < magHigh) bMaxNum=count;
      // set next interval:
      magLow=magHigh;
      magHigh=magHigh+MagInterval;
      count++;
   }
   //qDebug() << "bStartNum "<< bStartNum;
   //qDebug() << "bMaxNum "<< bMaxNum;

   // Determine incremental values yinc
   QVector<double> yinc(NumInterval);
   QVector<double> MagValue(NumInterval);
   magLow=startmag;
   magHigh=startmag+MagInterval;
   for (count=0; count<NumInterval; ++count) {
      yinc[count]=0.0;
      MagValue[count]=magLow+(double)MagInterval/2.;
      for (int i=0; i<NumEvents; ++i) {
         Node = DataBase->EventByIndex(i);
         //magnitude = Node->hypocenters.mag_all[0].mag;
         if (ShowM && Node->hypocenters.nmag>0) magnitude = Node->hypocenters.mag_all[0].mag;
         if (ShowML && Node->hypocenters.first->magnitudes.ML.nmag>0) magnitude = Node->hypocenters.first->magnitudes.ML.mag[0];
         if (ShowMW && Node->hypocenters.first->magnitudes.MW.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MW.mag[0];
         if (ShowMC && Node->hypocenters.first->magnitudes.MC.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MC.mag[0];
         if (ShowMb && Node->hypocenters.first->magnitudes.Mb.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Mb.mag[0];
         if (ShowMB && Node->hypocenters.first->magnitudes.MB.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MB.mag[0];
         if (ShowMs && Node->hypocenters.first->magnitudes.Ms.nmag>0) magnitude = Node->hypocenters.first->magnitudes.Ms.mag[0];
         if (ShowMS && Node->hypocenters.first->magnitudes.MS.nmag>0) magnitude = Node->hypocenters.first->magnitudes.MS.mag[0];
         if(magnitude >= magLow && magnitude < magHigh) yinc[count]+=1;
      }
      if (MAXy < yinc[count]) MAXy = yinc[count];

      // Set next interval:
      magLow=magHigh;
      magHigh=magHigh+MagInterval;
   }

   // Determine cumulative values ycum
   QVector<double> ycum(NumInterval);
   // log of ycum:
   QVector<double> lycum(NumInterval);
   QVector<double> lyinc(NumInterval);
   double fdum=0.0;
   for (int i=NumInterval-1; i>-1; --i) {
      ycum[i]=yinc[i]+fdum;
      lycum[i]=log10(ycum[i]);
      fdum=yinc[i]+fdum;
      lyinc[i]=log10(yinc[i]);
   }

   // Determine b-value for incremental values with linear regression:
   double sumx=0.0, sumy=0.0, sumxy=0.0, sumxx=0.0;
   for (int i=bStartNum; i<bMaxNum; ++i) {
      sumx=sumx+MagValue[i];
      sumy=sumy+lyinc[i];
      sumxy=sumxy+lyinc[i]*MagValue[i];
      sumxx=sumxx+MagValue[i]*MagValue[i];
   }
   int i=bMaxNum-bStartNum;
   double b_dum=((double)i*sumxy-sumx*sumy)/((double)i*sumxx-sumx*sumx);
   double a_dum=(sumy-b_dum*sumx)/(double)i;
   double a_inc=a_dum;
   double b_inc=-1.0*b_dum;

   // Estimate incremental values from a and b: yie
   QVector<double> yie(bMaxNum-bStartNum);
   QVector<double> MagValue_b(bMaxNum-bStartNum);
   for (int i=0; i<(bMaxNum-bStartNum); ++i) {
      MagValue_b[i]=MagValue[i+bStartNum];
      yie[i]=pow(10,a_inc-b_inc*MagValue_b[i]);
   }

   // Determine b-value for cumulative values with linear regression:
   sumx=0.0, sumy=0.0, sumxy=0.0, sumxx=0.0;
   for (int i=bStartNum; i<bMaxNum; ++i){
      sumx=sumx+MagValue[i];
      sumy=sumy+lycum[i];
      sumxy=sumxy+lycum[i]*MagValue[i];
      sumxx=sumxx+MagValue[i]*MagValue[i];
   }
   i=bMaxNum-bStartNum;
   b_dum=((double)i*sumxy-sumx*sumy)/((double)i*sumxx-sumx*sumx);
   a_dum=(sumy-b_dum*sumx)/(double)i;
   double a_cum=a_dum;
   double b_cum=-1.0*b_dum;

   // Estimate cumulative values from a and b: yce
   QVector<double> yce(bMaxNum-bStartNum);
   for (int i=0;i<(bMaxNum-bStartNum);++i) yce[i]=pow(10,a_cum-b_cum*MagValue_b[i]);

   // Initiate plot
   ui->customPlot->clearPlottables();

   //ui->customPlot->setRangeDrag(Qt::Horizontal|Qt::Vertical);
   //ui->customPlot->setRangeZoom(Qt::Horizontal|Qt::Vertical);
   ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);

   //ui->customPlot->setupFullAxesBox();
   //ui->customPlot->setTitle("Gutenberg-Richter relation");
   //ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, "SEISAN: Gutenberg-Richter relation"));

   ui->customPlot->legend->setVisible(true);
   QFont legendFont = font();
   legendFont.setPointSize(10);
   ui->customPlot->legend->setFont(legendFont);
   ui->customPlot->legend->setSelectedFont(legendFont);
   //ui->customPlot->legend->setSelectable(QCPLegend::spItems); // legend box shall not be selectable, only legend items
   // Prepare x axis:
   ui->customPlot->xAxis->setSubTickCount(0);
   //ui->customPlot->xAxis->grid()->setGrid(false);
   ui->customPlot->xAxis->setRange(startmag, 10);
   ui->customPlot->xAxis->setLabel("Earthquake magnitude");
   // Prepare y axis:
   ui->customPlot->yAxis->setScaleType(QCPAxis::stLogarithmic);
   ui->customPlot->yAxis->setScaleLogBase(10);
   ui->customPlot->yAxis->setNumberFormat("eb"); // e = exponential, b = beautiful decimal powers
   ui->customPlot->yAxis->setNumberPrecision(0); // makes sure "1*10^4" is displayed only as "10^4"
   ui->customPlot->yAxis->setSubTickCount(10);
   ui->customPlot->yAxis->setRange(0.5, (100.*MAXy));
   ui->customPlot->yAxis->setPadding(5); // a bit more space to the left border
   ui->customPlot->yAxis->setLabel("Number of earthquakes");
   //ui->customPlot->yAxis->grid()->setSubGrid(true);
   QPen gridPen;
   gridPen.setStyle(Qt::SolidLine);
   gridPen.setColor(QColor(0, 0, 0, 25));
   //ui->customPlot->yAxis->grid()->setGridPen(gridPen);
   gridPen.setStyle(Qt::DotLine);
   //ui->customPlot->yAxis->setSubGridPen(gridPen);

   // Add histogram
   QCPBars *MagHistogram = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
   ui->customPlot->addPlottable(MagHistogram);
   QPen pen;
   pen.setWidthF(1.2);

   // Plot histogram:
   MagHistogram->setName("Number of Earthquakes");
   pen.setColor(QColor(0, 0, 0));
   MagHistogram->setPen(pen);
   MagHistogram->setBrush(QColor(255, 0, 0));
   MagHistogram->setWidth(MagInterval);
   MagHistogram->setData(MagValue, yinc);

   // plot incremental values
   if (ShowIncremental == Qt::Checked){
      pen.setWidth(2);
      pen.setColor(QColor(0,0,255));
      ui->customPlot->addGraph();
      ui->customPlot->graph()->setPen(pen);
      ui->customPlot->graph()->setData(MagValue, yinc);
      ui->customPlot->graph()->setName("incremental values");
      ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
      //ui->customPlot->graph()->setScatterStyle(QCP::ssTriangleInverted);
      //ui->customPlot->graph()->setScatterSize(10);
      ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssTriangleInverted, Qt::blue, Qt::white, 10));
   }

   if (B_incremental == Qt::Checked){
      pen.setWidth(2);
      pen.setColor(QColor(0,0,255));
      ui->customPlot->addGraph();
      ui->customPlot->graph()->setPen(pen);
      ui->customPlot->graph()->setData(MagValue_b, yie);
      ui->customPlot->graph()->setName(QString("a=%1, b=%2").arg(a_inc).arg(b_inc));
      ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);
      //ui->customPlot->graph()->setScatterStyle(QCP::ssDisc);
      //ui->customPlot->graph()->setScatterSize(5);
      ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssTriangleInverted, Qt::blue, Qt::white, 5));
   }

   // Plot Cumulative values
   if (ShowCumulative == Qt::Checked){
      pen.setWidth(2);
      pen.setColor(QColor(0,0,0));
      ui->customPlot->addGraph();
      ui->customPlot->graph()->setPen(pen);
      ui->customPlot->graph()->setData(MagValue, ycum);
      ui->customPlot->graph()->setName("cumulative values");
      ui->customPlot->graph()->setLineStyle(QCPGraph::lsNone);
      //ui->customPlot->graph()->setScatterStyle(QCP::ssSquare);
      //ui->customPlot->graph()->setScatterSize(10);
      ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssSquare, Qt::blue, Qt::white, 10));
   }

   if (B_cumulative == Qt::Checked){
      pen.setWidth(2);
      pen.setColor(QColor(0,0,0));
      ui->customPlot->addGraph();
      ui->customPlot->graph()->setPen(pen);
      ui->customPlot->graph()->setData(MagValue_b, yce);
      ui->customPlot->graph()->setName(QString("a=%1, b=%2").arg(a_cum).arg(b_cum));
      ui->customPlot->graph()->setLineStyle(QCPGraph::lsLine);
      //ui->customPlot->graph()->setScatterStyle(QCP::ssDisc);
      //ui->customPlot->graph()->setScatterSize(5);
      ui->customPlot->graph()->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::blue, Qt::white, 5));
   }

   ui->customPlot->replot();
}
