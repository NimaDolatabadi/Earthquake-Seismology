#ifndef DRIFTOFHYPOCENTERSDLG_H
#define DRIFTOFHYPOCENTERSDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h" // the header file of QCustomPlot. Don't forget to add it to your project, if you use an IDE, so it gets compiled.


namespace Ui {
    class DriftOfHypocentersDlg;
}

class DriftOfHypocentersDlg : public QDialog
{
    Q_OBJECT

public:
    explicit DriftOfHypocentersDlg(db *database, QWidget *parent = 0);
    ~DriftOfHypocentersDlg();

private slots:
    void DriftOfHypocentersDlg_plot_lat();
    void DriftOfHypocentersDlg_plot_long();
    void DriftOfHypocentersDlg_plot_depth();
    void outputPrint();

private:
    Ui::DriftOfHypocentersDlg *ui;
    db *DataBase;
};

#endif
