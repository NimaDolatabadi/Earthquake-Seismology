#ifndef TODVSDISTDLG_H
#define TODVSDISTDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h"


namespace Ui {
    class TodVsDistDlg;
}

class TodVsDistDlg : public QDialog
{
    Q_OBJECT

public:
    explicit TodVsDistDlg(db *database, QWidget *parent = 0);
    ~TodVsDistDlg();

private slots:
    void plot();
    void outputPDF();
    void outputPNG();

private:
    Ui::TodVsDistDlg *ui;
    db *DataBase;
};

#endif
