#ifndef GUTENBERGRICHTERDLG_H
#define GUTENBERGRICHTERDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h"


namespace Ui {
    class GutenbergRichterDlg;
}

class GutenbergRichterDlg : public QDialog
{
    Q_OBJECT

public:
    explicit GutenbergRichterDlg(db *database, QWidget *parent = 0);
    ~GutenbergRichterDlg();

private slots:
    void plotGutenbergRichter();
    void outputPrint();

private:
    Ui::GutenbergRichterDlg *ui;
    db *DataBase;
};

#endif
