#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "types.h"
#include "setcwd.h"
#include "sebase.h"
#include "database.h"
#include "locatedlg.h"
#include "operatorid.h"
#include "qcustomplot.h"
#include "configuredlg.h"
#include "filterviewdlg.h"
#include "logviewfilter.h"
#include "eventlistmodel.h"
#include "timeintervaldlg.h"
#include "selectcolumnsdlg.h"
#include "eventlistviewfilter.h"

namespace Ui {
   class MainWindow;
}

class MainWindow : public QMainWindow
{
   Q_OBJECT

public:
   explicit MainWindow(QWidget *parent = 0);
   ~MainWindow();

protected:
   void closeEvent(QCloseEvent*);      // Handles File|Exit and close button.

signals:
   // Signals for the log view.
   void ClearLog();
   void WriteLog(logmodel::msg_type, QString);
   void WriteLog2File();

public slots:
   // General main window slots.
   void appStarting();
   void SetWindowTitle();
   void ShowLogView();

   // Used by the 'File' menu.
   bool Close_Database();
   void Create_Database();
   void Edit_SeisanDef();
   void Edit_MulpltDef();
   void Edit_StationHyp();
   void Open_CatalogFile();
   void Open_Database();
   void Open_DefaultDatabase();
   void Open_IndexFile();
   void Open_LastUsedDatabase();
   void Open_LocalDatabase();
   void SetConfiguration();
   bool SetTimeInterval();
   void SetWorkDir();

   // Used by the 'Event List' menu.
   void Locate_Event();
   void RemoveFilter();
   void ResizeColumns();
   void SelectColumns();
   void SetFilter();

   // Used by the 'Statistics' menu.
   void CompletenessCheck();
   void Export2CSV();
   void Gumbel3DistributionPlot();
   void GutenbergRichterRelation();
   void MagnitudeVsMagnitude();
   void PoissonDistribution();
   void SpatialDistribution();
   void TimeOfDayDistribution();
   void TimeOfDayVsDistance();
   void TimeOfDayVsTimeOfYear();
   void WeichertMethod();
   void YearlyDistribution();

   // Used by the 'Help' menu.
   void AboutSeisanExplorer();

   // Used by the database tab widget.
   void CurrentTabChanged(int);

   // Slots for the status bar.
   void SetStatusBarOperator();
   void SetStatusBarTimeInterval();

   // Used by the SEBASE instances.
   void DbOpenResult(db::dbStatus, db::dbError, int);

   // Used by the Log View widget.
   void CCMR_LogView(const QPoint&);
   void LV_Edit_Event();
   void LV_Edit_LogFile();
   void LV_AutoSaveLog();

private:
   Ui::MainWindow *ui;

   // Objects related to name, version and build date.
   QString AppName;                         // Application name.
   QString AppVersion;                      // Application version.

   // Objects related to program configuration.
   se_config AppConf;                       // Structure holding program configuration data.

   // Objects related to application status.
   QString CatalogFile;                     // Full path to open catalog file.
   bool CatFileOpened;                      // 'True' if a catalog file is currently open as a local database.
   QLabel LblOperator;                      // This label is used to show operator id in the status bar.
   QLabel LblInterval;                      // This label is used to show time interval in the status bar.
   void LoadProgramSettings();              // Load program settings.
   bool OpenLastUsed;                       // Used when opening the last used database from file menu.
   void SaveProgramSettings();              // Save program settings.
   OperatorId Operator;                     // Instance of the operator identity class.
   SetCWD WD;                               // Class for handling the setting of current working directory.

   // Objects related to SEISAN database.
   db_info DbInfo;                          // Holds information about a database.
   SEBASE *SEDB;                            // Pointer to instance of the database class.
   SEBASE_CONF SEDBCONF;                    // Holds startup configuration for an instance of the SEBASE class.
   QStringList PredefComments;              // List of predefined comments loaded from SEISAN.DEF.
   QStringList PredefNetworks;              // List of predefined virtual networks loaded from SEISAN.DEF.
   bool NoCloseQuery;                       // If true when closing a database, do not ask user for confirmation.
   bool NoTimeIntQuery;                     // If true when opening a database, do not ask user for time interval.

   // Objects related to the log widget/model.
   logmodel LogModel;                       // Model for the log view.
   logviewfilter LVFilter;                  // Filter for the log view.

   // Objects related to the 'SE Locate' dialog.
   LocateDlg *LocateView;                   // Pointer to the hypocenter location dialog.

   // Other objects.
   char ConsFile[80];                       // Console file used by SEISAN fortran functions.
   QString Message;                         // Used to hold messages.

   // Local functions.
   void ActivateTab(QWidget*);
   void CleanUpOnExit();
   void EditParamFile(char, char);
};

#endif // MAINWINDOW_H
