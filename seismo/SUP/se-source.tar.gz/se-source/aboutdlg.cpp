﻿#include "aboutdlg.h"
#include "ui_aboutdlg.h"
#include "mainwindow.h"

aboutdlg::aboutdlg(QWidget *parent, QString AppBuildDate, QString AppVersion) : QDialog(parent), ui(new Ui::aboutdlg)
{
    ui->setupUi(this);

    // Load picture into label named 'image'.
    ui->image->setScaledContents(true);
    ui->image->setPixmap(QPixmap(":/resources/skinner.jpg"));

    // Set label texts.
    ui->label1->setText("Date: "+ AppBuildDate);
    ui->label2->setText("Version: " + AppVersion);
    ui->label3->setText("Qt Version: " + QString(QT_VERSION_STR));
    ui->label4->setText("Copyright: University of Bergen, Department of Earth Science");
    ui->label5->setText("Developer: Øyvind Natvik  -   Contact: lars.ottemoller@uib.no");
 }

aboutdlg::~aboutdlg()
{
    delete ui;
}
