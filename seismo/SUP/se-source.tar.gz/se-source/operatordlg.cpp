#include "operatordlg.h"
#include "ui_operatordlg.h"
#include "library.h"

OperatorDlg::OperatorDlg(QWidget *parent) : QDialog(parent), ui(new Ui::OperatorDlg)
{
    ui->setupUi(this);
}


OperatorDlg::~OperatorDlg()
{
    delete ui;
}


// Initialize the dialog.
void OperatorDlg::InitDialog(QString *Id)
{
    operatorid = Id;
    ui->lineEdit->setText(*Id);
    ui->lineEdit->selectAll();
    ui->lineEdit->setMaxLength(4);
    setWindowFlags(Qt::CustomizeWindowHint);
    setWindowFlags(Qt::WindowTitleHint);
}


// Handle the OK button.
void OperatorDlg::accept(void)
{
    // Get operator id from dialog.
    QString Id = ui->lineEdit->text();

    // Remove any whitespace from both
    // ends, and convert to uppercase.
    Id = Id.simplified().toUpper();

    // Check string. Return if errors are found.
    if (!IsOperatorIdentityOK(Id)) return;

    // Return identity string.
    *operatorid = Id;

    // Close the dialog and return 'Accepted' signal.
    QDialog::accept();
}


// Reject the close button.
void OperatorDlg::reject(void)
{
    return;
}
