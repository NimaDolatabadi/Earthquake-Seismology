#ifndef SELECTWORKDIRDLG_H
#define SELECTWORKDIRDLG_H

#include <QDialog>
#include "types.h"
#include "logmodel.h"

namespace Ui {
   class SelectWorkDirDlg;
}

class SelectWorkDirDlg : public QDialog
{
   Q_OBJECT

public slots:
   void accept();
   void UseAltWD();
   void UseSeisanWD();
   void UseLaunchWD();
   void BrowseWorkDir();

public:
   explicit SelectWorkDirDlg(se_config*, QWidget *parent = 0);
   ~SelectWorkDirDlg();

private:
   Ui::SelectWorkDirDlg *ui;
   se_config *pConfig, DlgConfig;
};

#endif // SELECTWORKDIRDLG_H
