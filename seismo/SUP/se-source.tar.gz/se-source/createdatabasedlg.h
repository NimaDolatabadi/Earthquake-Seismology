#ifndef CREATEDATABASEDLG_H
#define CREATEDATABASEDLG_H

#include <QDialog>

namespace Ui {
   class CreateDatabaseDlg;
}

class CreateDatabaseDlg : public QDialog
{
   Q_OBJECT

public slots:
   void accept();
   void SelectFolder();

public:
   explicit CreateDatabaseDlg(QWidget *parent = 0, QString = "");
   ~CreateDatabaseDlg();

private:
   Ui::CreateDatabaseDlg *ui;
   bool CreateREA, CreateWAV;
   int StartYear, StartMonth, EndYear, EndMonth;
   QString StartTime, EndTime, AppName;
   QString Message, DbDir, DbTopDir, DbName;
};

#endif // CREATEDATABASEDLG_H
