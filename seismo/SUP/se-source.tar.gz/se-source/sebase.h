#ifndef SEBASE_H
#define SEBASE_H

#include <QMenu>
#include <QLabel>
#include <QWidget>
#include <QObject>
#include <QUdpSocket>
#include <QStatusBar>
#include <QTableView>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QApplication>
#include "types.h"
#include "setcwd.h"
#include "library.h"
#include "database.h"
#include "operatorid.h"
#include "mulplthandler.h"
#include "filterviewdlg.h"
#include "eventlistmodel.h"
#include "eventlistviewfilter.h"


struct SEBASE_CONF {
   QStringList PredefComments;
   QStringList PredefNetworks;
   se_config AppConf;
   OperatorId *Operator;
   logmodel *LogModel;
   QTabWidget *TabWidget;
};


class SEBASE: public QObject
{
   Q_OBJECT

signals:
   // Signals.
   void closed(SEBASE*);                              // SEBASE has closed.
   void close_file_editor();                          // Signal running editors to close.
   void cur_row_changed(SEBASE*);                     // The row number/current active row has changed.
   void cur_row_data_changed(SEBASE*);                // The node data for the current active row has changed.
   void edit_stationhyp_file();                       // User want to edit the parameter file.
   void locate_event();                               // User want to locate selected event.
   void num_events_changed(int);                      // Number of events in SEBASE has changed. Not signaled during DB load.
   void open_result(db::dbStatus, db::dbError, int);  // Signals the result of trying to open a database.
   void opened(SEBASE*, int);                         // SEBASE has opened.
   void set_time_interval();                          // User want to set the time interval.
   void show_sb_message(QString, int);                // Signal for showing a message in the mainwindow status bar.

private slots:
   // Slots for database (DB) events.
   void db_filter_progress(char);                     // Signals the filtering progress.
   void db_open_progress(db::dbStatus, int);
   void db_open_result(db::dbStatus, db::dbError);

   // Slots for the Event List View widget.
   void CCMR_EventListView(const QPoint&);
   void ELV_Add_ARC_Line_To_Sfile();
   void ELV_Add_Type1_Line_To_Sfile();
   void ELV_Associate_Events();
   void ELV_Copy_Events();
   void ELV_Delete_Events();
   void ELV_Duplicate_Event();
   void ELV_Edit_Comment_Lines();
   void ELV_Edit_With_Text_Editor();
   void ELV_Launch_EEV();
   void ELV_Reload_Event();
   void ELV_Load_Event();
   void ELV_Unload_Event();
   void ELV_Locate_Event();
   void ELV_Merge_Events();
   void ELV_Plot_With_Mulplot();
   void ELV_Plot_With_Mulplot_Menu();
   void ELV_Refresh_View();
   void ELV_Register_Event();
   void ELV_Set_Distance_Indicator();
   void ELV_Set_Event_Indicator();
   void ELV_Set_Model_Indicator();
   void ELV_Set_Filter();
   void ELV_Set_Time_Interval();
   void ELV_Show_Events_With_GE();
   void ELV_Show_Events_With_SV();
   void ELV_SimpleWaveformViewer();
   void ELV_GoToRowNr();
   void ELV_GoToNextNewEvent();
   void ELV_Select_All();
   void ELV_Sort_Indicator_Changed(int, Qt::SortOrder);
   void ELV_Double_Click(const QModelIndex&);

   // Slots for the event list view keyboard filter.
   void ELV_Edit_StationHyp();

   // Slots for the Event List View data model.
   void EventsDropped(QStringList);
   void RowChanged(int);

   // Slot for the FileEditor class.
   void FileSaved(QString);

   // Slots for the HandleMulplt class.
   void HandleMulpltMsg(MulpltHandler*, QString, QString);

public:
   SEBASE(SEBASE_CONF *Config);
   ~SEBASE();
   void AutoSizeColumns();
   void Close();
   int CurrentRow();                         // Returns the index for the current active row.
   bool DeleteEvent(int, int*, bool, bool);  // Delete an event from database and disk.
   int LoadEvent(QString);                   // Load an event file from disk.
   void NavigateDown();                      // Move event list view selection up one place.
   void NavigateUp();                        // Move event list view selection down one place.
   int NumEvents();                          // Returns number of events in database.
   void Open(db_info);                       // Open a database from disk.
   int ReloadEvent(int);                     // Reload an event file from disk.
   void RemoveFilter();                      // Remove a filter from database.
   void SelectedEvents(QListEventID*);       // Returns a list of event ID's for all selected events.
   void SetEventListViewHeaders(se_config);  // Names the columns in the event list view.
   void SetFilter();                         // Apply a filter to the database.
   void SetKeyboardFocus();                  // Give the keyboard input focus to the event list view.
   void SetTimeInterval(tm_int);             // Set new time interval dates.
   int TabIndex();                           // Returns the index in the tab widget for this instance.
   void UnloadEvent(int);                    // Unloads an event from database.
   bool WriteToCatFile(QString CatFile);     // Writes selected events to a catalog file.
   db *DB;                                   // Pointer to database class used to hold S-file data.
   db_info DbInfo;                           // Database information.
   db::dbStatus DbStatus;                    // Current status of database.
   QWidget PageWidget;                       // Page widget which will occupy the tabwidget tab.

private:
   SEBASE_CONF Conf;                      // Startup configuration for this class.
   QString AppName;
   bool DoOnceAtLoadStart;
   QString CatalogFile;                   // Full path to open catalog file.
   db::dbError DbError;                   // Database error.
   QVBoxLayout PageLayout;                // Layout for the page widget.
   QHeaderView *ELVHeader;                // Pointer to Event List View header.
   QTableView ELView;                     // Event list table view.
   eventlistmodel *ELVModel;              // Pointer to model for the event list view.
   eventlistviewfilter ELVFilter;         // Keyboard filter for the event list view.
   QListEventID ELVSelection;             // Holds list of selected rows in Event List View.
   int AccTimeInt;                        // Used with associate event function.
   int RowNum;                            // Used to hold a row number.
   QString Message;
   SetCWD WD;                             // Class for handling the setting of current working directory.
   QDateTime LdStartTime;                 // Used to calculate database load time.
   QString File, FileName;                // For general use.

   // Objects related to database filtering.
   FilterViewDlg *FilterDlg;
   db_filter DbFilter;                     // Holds the database filter configuration.

   // Objects related to MulpltHandler class.
   QList <MulpltHandler*> MulpltHandlers; // List of pointers to running instances of the MulpltHandler class.

   // Objects related to the register function.
   QString AltDestDir;

   // Private functions.
   void ShowMessage(int, bool = false); // Display a standard message in a dilog box or status bar.
   bool LoadEvents(QStringList);        // Loads several S-files into the database.
   void Plot_With_Mulplot(bool);
   bool IsEventOpenInMulplt(QString);   // Check if an event is open in a running mulplt instance.
   void RegisterEvent(int);             // Registers an event into the Seisan database.
   void SetTabTitle();
};

#endif // SEBASE_H
