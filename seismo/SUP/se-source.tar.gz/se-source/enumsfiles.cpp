#include <QDir>
#include <QDebug>
#include "enumsfiles.h"
#include "fortran.h"
#include "library.h"

void enumsfiles::SetDatabase(db_info DbInfo, QDate StartDate, QDate StopDate, QStringList *SfileList)
{
   // Save some variables.
   dbtype = DbInfo.Type;
   dbpath = QDir::cleanPath(DbInfo.Path);
   sfilelist = SfileList;

   // Prepare to read from default database. Uses StartDate and StopDate.
   if (DbInfo.Type == default_database) {
      fstrcpy(dbname, (char*)"", sizeof dbname);         // Database name must be empty.
      date = StartDate.toString("yyyyMMdd");
      CopyQstrToChar(date, startdate);
      PadString(startdate, sizeof startdate);            // Set start date.
      date = StopDate.toString("yyyyMMdd");
      CopyQstrToChar(date, stopdate);
      PadString(stopdate, sizeof stopdate);              // Set stop date.
   }

   // Prepare to read from normal database. Uses StartDate, StopDate and dbpath.
   if (DbInfo.Type == normal_database) {
      dbpath = QDir::toNativeSeparators(dbpath);
      CopyQstrToChar(dbpath, dbname);
      strcat(dbname, "/");
      PadString(dbname, sizeof dbname);
      date = StartDate.toString("yyyyMMdd");
      CopyQstrToChar(date, startdate);
      PadString(startdate, sizeof startdate);            // Set start date.
      date = StopDate.toString("yyyyMMdd");
      CopyQstrToChar(date, stopdate);
      PadString(stopdate, sizeof stopdate);              // Set stop date.
   }

   // Prepare to read from local database.
   if (DbInfo.Type == local_database) {
      fstrcpy(dbname, (char*)",,", sizeof dbname);       // Set database name to ",,".
      dbpath = QDir::toNativeSeparators(dbpath);
      startdate[0] = 0; stopdate[0] = 0;
      PadString(startdate, sizeof startdate);
      PadString(stopdate, sizeof stopdate);
   }

   // Prepare to read from index file.
   if (DbInfo.Type == index_file) {
      CopyQstrToChar(DbInfo.Name, dbname);
      PadString(dbname, sizeof dbname);                  // Full path to index file in 'dbname'.
      fstrcpy(startdate, (char*)"", sizeof startdate);   // Start date should be empty.
      fstrcpy(stopdate, (char*)"", sizeof stopdate);     // Stop date should be empty.
   }
}




// *******************************************************************
// This function scans a Seisan database for S-files, and stores all
// found S-files (with full path name) in QStringList 'sfilelist'.
// Function also reports on its progress by signaling class 'database'.
// Function also signals class 'database' when scanning is complete.
// *******************************************************************
void enumsfiles::run()
{
   char key[10], eventfile[81];
   QString CurrentDir, EventFile;
   int progress, last_progress, num_sfiles;
   sint fromeev, filenr, newmonth, status, fstart;

   // Clear the termination flag.
   mtx_terminate.lock();
   terminate = false;
   mtx_terminate.unlock();

   // Check if we are opening a local database.
   if (dbtype == local_database) {
      // Save current directory, and change current
      // working directory to folder with S-Files.
      CurrentDir = QDir::currentPath();
      QDir::setCurrent(dbpath);
   }

   // Call fortran function 'findevin' repeatedly to get all
   // S-files in database/indexfile. Files are added to 'sfilelist'.
   seisan_explorer_.se_out = 1;
   fstrcpy(key, (char*)"start", sizeof key);
   num_sfiles = progress = last_progress = 0;
   fromeev = filenr = status = fstart = newmonth = 0;
   while (status == 0 && sfilelist->size() <= MAX_EVENTS) {
      fstrcpy(eventfile, (char*)"", sizeof eventfile);
      findevin_(dbname, startdate, stopdate, key, &fromeev, &filenr, eventfile,
                &fstart, &newmonth, &status, sizeof dbname, sizeof startdate,
                sizeof stopdate, sizeof key, sizeof eventfile);
      fstrcpy(key, (char*)"next", sizeof key);

      if (status == 0) {
         // Append path to filename and add filename to 'sfilelist'.
         UnPadString(eventfile, sizeof eventfile);
         EventFile = eventfile;
         if (dbtype == local_database) EventFile.prepend(dbpath + "/");
         EventFile = QDir::cleanPath(EventFile);
         sfilelist->append(QDir::toNativeSeparators(EventFile));
         num_sfiles = sfilelist->size();

         // For every 1000 file, report progress and
         // check if thread has been asked to terminate.
         progress = (num_sfiles/1000)*1000;
         if (progress > last_progress) {
            // Save last progress value.
            last_progress = progress;

            // Inform db class of current progress.
            emit EnumSfilesProgress(progress);

            // Check if thread has been asked to terminate.
            mtx_terminate.lock();
            if (terminate) {
               mtx_terminate.unlock();
               // If we have opened an index file, then
               // change back to saved working directory.
               if (dbtype == local_database) QDir::setCurrent(CurrentDir);
               return;
            }
            mtx_terminate.unlock();
         }

         // Check number of file read against program limitation.
         if (num_sfiles == MAX_EVENTS+1) {
            // Remove the last read file from file list.
            sfilelist->removeLast();
            // If we have opened an index file, then
            // change back to saved working directory.
            if (dbtype == local_database) QDir::setCurrent(CurrentDir);
            // Signal database class that reading has been stopped.
            emit EnumSfilesDone(1);
            return;
         }
      }
   }

    // If we have opened a local database, then
    // change back to saved working directory.
    if (dbtype == local_database) QDir::setCurrent(CurrentDir);

    // Signal database class that reading is sucessfully done.
    emit EnumSfilesProgress(num_sfiles);
    emit EnumSfilesDone(0);
    return;
}




// **********************************************************
// This function can be called to stop the thread function.
// Thread will stop at the earliest convenience.
// **********************************************************
void enumsfiles::Cancel()
{
   // Check if thread is running.
   if (isRunning()) {
      // Set cancel signal.
      mtx_terminate.lock();
      terminate = true;
      mtx_terminate.unlock();
   }
}
