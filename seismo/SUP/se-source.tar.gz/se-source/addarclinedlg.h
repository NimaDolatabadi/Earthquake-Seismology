#ifndef ADDARCLINEDLG_H
#define ADDARCLINEDLG_H

#include <QDialog>
#include <QStringList>
#include "types.h"
#include "database.h"
#include "eventnode.h"

namespace Ui {
   class AddArcLineDlg;
}

class AddArcLineDlg : public QDialog
{
   Q_OBJECT

public:
   explicit AddArcLineDlg(db*, int, QStringList, QWidget *parent = 0);
   ~AddArcLineDlg();

public slots:
   void accept();
   void reject();

private:
   Ui::AddArcLineDlg *ui;
   db *DB;
   int Index;
   event_node_ *Node;
   QString Date, Time;
};

#endif // ADDARCLINEDLG_H
