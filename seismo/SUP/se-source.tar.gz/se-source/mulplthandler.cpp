#include <QDir>
#include <QDebug>
#include <QProcess>
#include "mulplthandler.h"
#include "library.h"

const bool DEBUG = false;


// *******************************************************************
// Constructor function.
// *******************************************************************
MulpltHandler::MulpltHandler(QString SeisanTop, logmodel *log, QObject *parent) : QObject(parent)
{
   // Initialize the class.
   LogModel = log;
   Running = false;
   SEISAN_TOP = SeisanTop;
   MyPort = PeerPort = 0;

   // Initialize the network.
   // Bind UDP socket for communication from localhost.
   NetworkOk = InitNetwork();

   // Set a platform dependant shell program.
   #ifdef Q_OS_WIN32
   Shell = "cmd.exe";
   ShellPar = "/c";
   #endif
   #ifdef Q_OS_LINUX
   Shell = "xterm";
   ShellPar = "-e";
   #endif

   // Set platform dependant name for 'mulplot'.
   #ifdef Q_OS_WIN32
      Mulplt = "mulplt.exe";
   #endif
   #ifdef Q_OS_LINUX
      Mulplt = "mulplt";
   #endif
}



// *******************************************************************
// Destructor function.
// *******************************************************************
MulpltHandler::~MulpltHandler()
{
   // Disconnect the readyRead signal so we don't receive any more messages.
   disconnect(&Socket, SIGNAL(readyRead()), this, SLOT(GetUdpMessages()));

   // Send a QUIT message to mulplt (if it is running).
   Close();

   // Close the UDP socket.
   Socket.close();
}




// *******************************************************************
// Starts the mulplt program using QProcess.
// *******************************************************************
bool MulpltHandler::Start(QString File, QStringList ArgList)
{
   // Check if mulplt is already started.
   if (Running) return true;

   // Check that the 'mulplt' program exists.
   if (!IsFileInPath(Mulplt)) {
      Message = "Can not find mulplt in the path.";
      LogModel->WriteLog(logmodel::error, Message);
      LogModel->ShowLogView();
      return false;
   }

   // Check that the network is ready for communication.
   if (!NetworkOk) {
      Message = "Can not start mulplt. Failed to set up socket for UDP communication.";
      LogModel->WriteLog(logmodel::error, Message);
      LogModel->ShowLogView();
      return false;
   }

   // Build the argument list for mulplt.
   ArgList.insert(0, ShellPar);
   ArgList.insert(1, BuildPath(SEISAN_TOP, "PRO", Mulplt));
   ArgList.append("-sfile"); ArgList.append(File);
   ArgList.append("-se");
   ArgList.append("-port"); ArgList.append(QString::number(MyPort));

   // Start mulplt.
   Running = QProcess::startDetached(Shell, ArgList);
   if (!Running) {
      Message = "Unable to launch mulplt. Unknown problem.";
      LogModel->WriteLog(logmodel::error, Message);
      LogModel->ShowLogView();
   }

   // Save the current S-file.
   SFile = File;

   return Running;
}




// *******************************************************************
// Close the mulplt program by sending the QUIT message.
// *******************************************************************
void MulpltHandler::Close()
{
   if (Running) SendUdpMessage("QUIT");
}




// *******************************************************************
// Send a message to mulplt.
// *******************************************************************
void MulpltHandler::SendMsg(QString Msg)
{
   if (Running) SendUdpMessage(Msg);
}




// *******************************************************************
// Instruct mulplt to load another S-file.
// *******************************************************************
void MulpltHandler::LoadFile(QString File)
{
   if (PeerPort && Running) {
      SFile = File;
      SendUdpMessage("LOAD " + File);
   }
}




// *********************************************************
// This function is signaled from the QUdpSocket class when
// it receives datagrams from mulplt on the UDP connection.
// *********************************************************
void MulpltHandler::GetUdpMessages()
{
   bool ForwardMsg;
   quint16 SenderPort;
   QString Datagram;
   QHostAddress Sender;
   QByteArray SocketData;

   // Receive one or more UDP messages.
   while (Socket.hasPendingDatagrams()) {
      // Receive a message.
      ForwardMsg = true;
      SocketData.resize(Socket.pendingDatagramSize());
      Socket.readDatagram(SocketData.data(), SocketData.size(), &Sender, &SenderPort);
      Datagram = SocketData.data();
      if (DEBUG) {
         Message = "Class MulpltHandler: Received message: " + Datagram;
         LogModel->WriteLog(logmodel::info, Message);
      }

      // Handle incoming UDP message from mulplt.
      if (Datagram.startsWith("PORT")) {
         // Mulplt is giving us the port number it listens to. We need
         // to save this port number so we can send messages to mulplt.
         // This message will not be forwarded to our parent class.
         ForwardMsg = false;
         PeerPort = Datagram.mid(5).toInt();
      }
      if (Datagram.startsWith("EXIT")) {
         // Mulplt is telling us that it is closing.
         // This message will not be forwarded to our parent class.
         Running = ForwardMsg = false;
      }
      // Forward incoming message to parent.
      if (ForwardMsg) {
         emit message_received(this, Datagram, SFile);
      }
   }
}




// *******************************************************************
// Send an UDP message to mulplt.
// *******************************************************************
void MulpltHandler::SendUdpMessage(QString Msg)
{
   Socket.writeDatagram(Msg.toLatin1().constData(), Msg.size(), QHostAddress("127.0.0.1"), PeerPort);
   if (DEBUG) {
      Message = "Class MulpltHandler: Message sent: " + Msg;
      LogModel->WriteLog(logmodel::info, Message);
   }
}




// *******************************************************************
// Create and bind a UDP socket for receiving messages from mulplt.
// *******************************************************************
bool MulpltHandler::InitNetwork()
{
   // Bind the socket to localhost address.
   quint16 port = 0;
   if (!Socket.bind(QHostAddress::LocalHost, port, QAbstractSocket::DefaultForPlatform)) return false;

   // Save the port we listen too.
   MyPort = Socket.localPort();
   if (DEBUG) {
      Message = "Class MulpltHandler: Listening to port " + QString::number(MyPort);
      LogModel->WriteLog(logmodel::info, Message);
   }


   // Connect readyRead signal to function GetUdpMessages().
   // The GetUdpMessages function will be called automatically
   // when a new incoming UDP message is ready to be read.
   connect(&Socket, SIGNAL(readyRead()), this, SLOT(GetUdpMessages()));

   return true;
}
