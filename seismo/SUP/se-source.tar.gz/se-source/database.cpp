#include <QDir>
#include <QApplication>
#include <QProgressDialog>
#include "database.h"
#include "fortran.h"
#include "library.h"
#include "filter.h"
#include <cmath>


// *****************************
// Constructor function.
// *****************************
db::db(logmodel *logmodel)
{
   // Save variables to local storage.
   Log = logmodel;

   // Connect signals from the 'EnumSfiles' and 'ReadSfiles' thread classes;
   connect(&EnumSfiles, SIGNAL(EnumSfilesProgress(int)), this, SLOT(EnumSfilesProgress(int)));
   connect(&EnumSfiles, SIGNAL(EnumSfilesDone(char)), this, SLOT(EnumSfilesDone(char)));
   connect(&ReadSfiles, SIGNAL(FileProblem(QString, QStringList, int)), this, SLOT(FileProblem(QString, QStringList, int)));
   connect(&ReadSfiles, SIGNAL(ReadSfilesDone(char)), this, SLOT(ReadSfilesDone(char)));
   connect(&ReadSfiles, SIGNAL(AddDbEvent(event_node_*)), this, SLOT(AddDbEvent(event_node_*)));

   // Init the ReadSfiles class instance;
   ReadSfiles.Init(&sfilelist, &mtx_db_cblock);

   // Call Init() to do the rest of the initialization.
   Init();
}




// **********************************
// Initialize the database structure.
// Does NOT free any allocated nodes.
// **********************************
void db::Init()
{
   mIndex.clear();
   pIndex.clear();
   sfilelist.clear();
   last_progress = 0;
   db_status = closed;
   db_error = no_error;
   sort_col = DateTime;
   sort_ord = Qt::AscendingOrder;
   node_id_counter = 0;
   filter_applied = false;
   ss_last_found_index = 0;
}




// *************************************************************************
// Load S-files (events) into the Seisan Explorer internal database.
// *************************************************************************
void db::Open(db_info DbInfo, QDate StartDate, QDate StopDate)
{
   // Check if database is already open or loading.
   if (db_status != closed) return;

   // Save the data base path.
   DatabasePath = DbInfo.Path;

   // Give class 'EnumSfiles' needed info about the database.
   EnumSfiles.SetDatabase(DbInfo, StartDate, StopDate, &sfilelist);

   // Launch a background thread to do S-file enumeration.
   // Thread will signal EnumSfilesDone() when finished.
   EnumSfiles.start();

   // Update database status.
   set_db_status(enum_sfiles);

   // Signal that enumeration has started.
   emit db_open_progress(db_status, 0);
}




// *******************************************
// Closes the database. This function returns
// immediately. Database may not have closed
// before it returns.
// *******************************************
void db::Close()
{
   switch (db_status) {
   case open:
      // Database is open, do normal close.
      FreeDatabaseNodes(); Init();
      break;

   case enum_sfiles:
      // Database is enumerating S-files. Stop thread.
      if (EnumSfiles.isRunning()) EnumSfiles.Cancel();

      // Wait for thread to stop.
      while (EnumSfiles.isRunning()) QThread::msleep(200);

      // Close database.
      Init();

      // Give parent class the result of the open operation.
      emit db_open_result(db_status, cancelled);
      break;

   case read_sfiles:
      // Database is reading S-files. Stop thread.
      if (ReadSfiles.isRunning()) ReadSfiles.Cancel();

      // Wait for thread to stop.
      while (ReadSfiles.isRunning()) QThread::msleep(200);

      // Close database.
      FreeDatabaseNodes(); Init();

      // Give parent class the result of the open operation.
      emit db_open_result(db_status, cancelled);
      break;

   default:
      break;
   }
}




// *****************************************************
// Sort database by given sort column.
// *****************************************************
void db::SetSortCol(sortCol SortColumn)
{
   if (db_status == open && SortColumn != sort_col) {
      // Sort column has changed.
      sort_col = SortColumn;
      sort_ord = Qt::AscendingOrder;

      // Rebuild the presentation index.
      RebuildPresenIndex();
   }
}




// *****************************************************
// Sets the current sort order (descending/ascending).
// *****************************************************
void db::SetSortOrd(Qt::SortOrder SortOrder)
{
   if (db_status == open && SortOrder != sort_ord) {
      // Sort order has changed.
      sort_ord = SortOrder;

      // Reverse the list.
      int size = pIndex.size(); int half = size/2;
      for (int i=0;i<half;i++) pIndex.swap(i, size - i - 1);

      // Move all unsortable events to end of the list.
      if (sort_col != DateTime) MoveUnsortablesDown();

      // Update pointers into pIndex.
      UpdateNodePositions(false);
   }
}




// ****************************************************
// Resorts (rebuilds) the presentation index list.
// Optionally resorts the master index list as well.
// ****************************************************
void db::Resort(bool SortMaster)
{
   if (db_status == open) {
      // Sort the master index list if requested.
      // This list is always sorted by date/time.
      if (SortMaster) {
         QApplication::setOverrideCursor(Qt::WaitCursor);
         SortMasterIndex();
         QApplication::restoreOverrideCursor();
      }

      // Rebuild the presentation index.
      RebuildPresenIndex();
   }
}




// ***************************************************************
// Copy all nodes from the master index to the presentation index.
// If a filter is applied, only events that are not filtered out
// will be copied.
// ***************************************************************
void db::CopyMasterToPresentation()
{
   if (!filter_applied) {
      // No filter is currently applied. The whole list is copied.
      pIndex = mIndex;
   } else {
      // A filter is currently applied.
      // Only copy pointers to events that are not filtered out.
      pIndex.clear();
      int size = mIndex.size();
      for(int i=0;i<size;i++) {
         if (!mIndex[i]->metadata.filtered_out) pIndex.append(mIndex[i]);
      }
   }
}




// *****************************************************
// Returns the current sort criteria.
// *****************************************************
void db::SortCriteria(sortCol *Column, Qt::SortOrder *Order)
{
   *Order = sort_ord;
   *Column = sort_col;
}




// *****************************************************
// Return pointer to event node by presentation index.
// A pointer in the pIndex list is returned.
// *****************************************************
event_node_* db::EventByIndex(int index)
{
   // Check that index is not out of bounds.
   if (index >= num_pi_events()) return 0;

   // Return pointer to event node.
   return pIndex[index];
}




// *****************************************************
// Return number of event nodes in presentation index.
// *****************************************************
int db::NumEvents(void)
{
   if (db_status == closed) return 0;
   return num_pi_events();
}




// *****************************************************
// Return file name for single event by index.
// *****************************************************
bool db::FileByIndex(int index, QString *FileName)
{
   // Check that index is not out of bounds.
   if (index < 0) return false;
   if (index >= num_pi_events()) return false;

   // Get filename for event.
   *FileName = pIndex[index]->metadata.sfile;

   return true;
}




// ******************************************************
// Return file name for single event by event id.
// ******************************************************
bool db::FileById(int EventId, QString *FileName)
{
   bool found;
   int NumEvents, index;

   // Clear the file name.
   FileName->clear();

   // Get number of events.
   NumEvents = num_pi_events();

   // Search trough the presentation index.
   found = false; index = -1;
   while (!found && index < NumEvents) {
      index++;
      if (pIndex[index]->metadata.event_id == EventId) found = true;
   }

   // Return if event id was not found.
   if (!found) return false;

   // Return filename for event.
   *FileName = pIndex[index]->metadata.sfile;

   return true;
}




// ****************************************************
// Returns the event's unique identity number by index.
// ****************************************************
int db::IdByIndex(int index)
{
   // Check that index is not out of bounds.
   if (index >= num_pi_events()) return -1;

   // Return unique event identity.
   return pIndex[index]->metadata.event_id;
}




// *************************************************************
// Return database index to an event by event's identity number.
// *************************************************************
int db::IndexById(int EventId)
{
   bool found;
   int NumEvents, index;

   // Get number of events.
   NumEvents = num_pi_events();

   // Search trough the presentation index.
   found = false; index = -1;
   while (!found && index < NumEvents) {
      index++;
      if (pIndex[index]->metadata.event_id == EventId) found = true;
   }

   // Return -1 if not found.
   if (!found) return -1;

   return index;
}




// *************************************************************
// Return database index to an event by event's file name.
// Variable 'EventFile' must give full path to file.
// Function returns '-1' if event file is not found.
// *************************************************************
int db::IndexByFile(QString EventFile)
{
   QString FileName;

   // Make sure event file path uses native seperators.
   EventFile = QDir::toNativeSeparators(EventFile);

   // Search trough the presentation index.
   int NumEvents = pIndex.size();
   for (int i=0;i<NumEvents;i++) {
      FileName = pIndex[i]->metadata.sfile;
      FileName = QDir::toNativeSeparators(FileName);
      if (FileName == EventFile) return i;
   }

   return -1;
}




// *********************************************************
// Returns a list of indexes for all marked events.
// *********************************************************
void db::MarkedEvents(QListInt *EventList)
{
   // Search trough the presentation index.
   int NumEvents = pIndex.size();
   for (int i=0;i<NumEvents;i++) {
      if (pIndex[i]->metadata.marked) EventList->append(i);
   }
}




// **************************************************************
// Unmarks all marked events in the database.
// **************************************************************
void db::UnmarkAllEvents()
{
   int NumEvents = mIndex.size();
   for (int i=0;i<NumEvents;i++) mIndex[i]->metadata.marked = false;
}




// *************************************************************
// Removes an event by index. S-file is NOT removed from disk.
// If the event was removed, this function sends a signal giving
// the old presentation index for the deleted event.
// *************************************************************
bool db::RemoveEvent(int index)
{
   int mindex;

   // Check that index is not out of bounds.
   if (index < 0) return false;
   if (index >= num_pi_events()) return false;

   // Get the index into master index list.
   mindex = pIndex[index]->metadata.pos_mindex;

   // Release the node memory.
   FreeNode(pIndex[index]);

   // Remove event from index lists.
   pIndex.removeAt(index);
   mIndex.removeAt(mindex);

   // Update the node positions in both index lists.
   UpdateNodePositions(true);

   // Signal that an event was removed from the database.
   emit db_event_removed(index);

   return true;
}




// ************************************************************
// Load a new S-file into the database and resort the database.
// Returns the new node's position in the presentation index.
// If the event was loaded, this function sends a signal giving
// the presentation index for the loaded event.

// Return values:
// -1 = Unable to load S-file.
// -2 = Event is filtered out from presentation index.
// ************************************************************
int db::LoadEventAndResort(QString sfile)
{
   event_node_ *node;
   char file[MAX_PATH], status;

   // Check that S-file exists.
   if (!QFile::exists(sfile)) return -1;

   // Check that database is open.
   if (db_status != open) return -1;

   // Read the S-file from disk.
   CopyQstrToChar(sfile, file);
   node = ReadSfile(file, &status);
   if (status != 0 && status != 4) return -1;

   // Add a unique event number to event node.
   node->metadata.event_id = node_id_counter++;

   // Add event node to master index and resort.
   mIndex.append(node);
   SortMasterIndex();

   // If a filter is applied, filter the node.
   if (isFilterApplied()) FilterNode(node);

   // Rebuild the presentation index list.
   RebuildPresenIndex();

   // If node is filtered out return -2.
   if (node->metadata.filtered_out) return -2;

   // Get index for the new event.
   int index = IndexById(node->metadata.event_id);

   // Signal that an event was added to the database.
   emit db_event_added(index);

   // Return the index in pIndex.
   return index;
}




// *************************************************************
// Load a new S-file into the master index. This function can be
// called several times in a row to add events. Database will
// need to be resorted afterwards. This function will NOT signal
// that an event has been added. Function returns unique event
// number, or -1 if load failed.
// *************************************************************
int db::LoadEvent(QString sfile)
{
   event_node_ *node;
   char file[MAX_PATH], status;

   // Check that S-file exists.
   if (!QFile::exists(sfile)) return -1;

   // Check that database is not loading.
   if (db_status != open) return -1;

   // Read the S-file from disk.
   CopyQstrToChar(sfile, file);
   node = ReadSfile(file, &status);
   if (status != 0 && status != 4) return -1;

   // Add a unique event number to event node.
   node->metadata.event_id = node_id_counter++;

   // Add event node to the end of the master index.
   mIndex.append(node);

   // If a filter is applied, filter the node.
   if (isFilterApplied()) FilterNode(node);

   return node->metadata.event_id;
}




// ***************************************************
// Reloads an S-file. Database will also be resorted.
// Function returns the status from ReadSfile().
// ***************************************************
int db::ReloadEventAndResort(int index)
{
   int EventId, mindex;
   event_node_ *OldNode;
   char sfile[81], status;

   // Check that index is not out of bounds.
   if (index < 0) return -1;
   if (index >= num_pi_events()) return -1;

   // Get the index into master index list.
   mindex = pIndex[index]->metadata.pos_mindex;

   // Save the unique id number for this event.
   EventId = mIndex[mindex]->metadata.event_id;

   // Save the full path to the event file.
   strcpy(sfile, mIndex[mindex]->metadata.sfile);

   // Save pointer to the current node.
   OldNode = mIndex[mindex];

   // Read the S-file from disk.
   mIndex[mindex] = ReadSfile(sfile, &status);

   // Handle result of read.
   if (status == 0 || status == 4) {
      // S-file was sucessfully read. Release the old node.
      FreeNode(OldNode);
      // Set/use the same event id for the new node.
      mIndex[mindex]->metadata.event_id = EventId;
      // Resort both indexes.
      SortMasterIndex();
      // If a filter is applied, filter the node.
      if (isFilterApplied()) FilterNode(mIndex[mindex]);
      // Rebuild the presentation index list.
      RebuildPresenIndex();
   } else {
      // S-file could not be read. Restore the old node.
      mIndex[mindex] = OldNode;
   }

   return status;
}




// ***********************************************************
// Add an event node to database. This function will only be
// called from class 'ReadSfiles'. Function will also signal
// class 'SEBASE' about the read progress. No need to do
// sorting in this function since class 'ReadSfiles' will add
// all events in the default 'DateTime' sort order.
// ***********************************************************
void db::AddDbEvent(event_node_ *node)
{
   int size;

   // Add event node to master index.
   mIndex.append(node);

   // Add event node to presentation index.
   mtx_pindex.lock();
   size = pIndex.size();
   pIndex.append(node);
   mtx_pindex.unlock();

   // Add a unique event number to event node.
   node->metadata.event_id = node_id_counter++;
   // Add node's position in index lists.
   node->metadata.pos_mindex = mIndex.size() - 1;
   node->metadata.pos_pindex = size;

   // Update statusbar progress info.
   int progress = 100.0/((float)sfilelist.size()/(float)mIndex.size());
   if (progress > last_progress) {
      last_progress = progress;
      emit db_open_progress(db_status, progress);
   }
}




// *****************************************************************
// A problem was detected while reading an S-file. This function
// will report the problem in the program log. A list of issues is
// received in the 'Problems' list. This function signaled from
// the 'ReadSfiles' class.
// *****************************************************************
void db::FileProblem(QString File, QStringList Problems, int Status)
{
   // The file could not be opened.
   if (Status == 1) {
      Message = "Unable to open event file '";
      Message.append(File); Message.append("'.");
      Log->WriteLog(logmodel::error, Message, File);
      return;
   }

   // The current file has errors and cannot be loaded.
   if (Status == 2) {
      Message = "Errors was detected while reading event file '";
      Message.append(File); Message.append("'. File has been skipped.");
      Log->WriteLog(logmodel::error, Message, File);
      for (int i=0; i<Problems.size(); i++) {
         Message = "Error: " + Problems.at(i);
         Log->WriteLog(logmodel::error, Message, true);
      }
      return;
   }

   // The current file has non-fatal problems, but has been loaded.
   if (Status == 4) {
      Message = "A problem was detected while reading event file '";
      Message.append(File); Message.append("'.");
      Log->WriteLog(logmodel::warning, Message, File);
      for (int i=0; i<Problems.size(); i++) {
         Message = "Problem: " + Problems.at(i);
         Log->WriteLog(logmodel::warning, Message, true);
      }
      return;
   }

   // The current event file has an invalid date.
   if (Status == 5) {
      Message = "Event file has invalid date: '";
      Message.append(File); Message.append("'.");
      Log->WriteLog(logmodel::error, Message, File);
      return;
   }
}



// *****************************************************
// This signal comes from the event log model. Function
// must return index of first event that matches the
// search string.
// *****************************************************
void db::SpeedSearch(QString SearchStr, bool Start)
{
   QString DateTime;
   int Index, NumEvents;

   // Reset the 'LastFoundIndex' variable if
   // this is the that start of a new search.
   if (Start) ss_last_found_index = 0;

   // If string is empty, return the first event.
   if (!SearchStr.size()) {
      ss_last_found_index = 0;
      emit db_speedsearch_reply(0);
      return;
   }

   // Get number of events in database and search for first match.
   NumEvents = mIndex.size();
   for (Index=0;Index<NumEvents;Index++) {
      DateTime = mIndex[Index]->metadata.datetime;
      if (DateTime.startsWith(SearchStr)) {
         if (mIndex[Index]->metadata.pos_pindex != -1) {
            emit db_speedsearch_reply(mIndex[Index]->metadata.pos_pindex);
            ss_last_found_index = Index;
            return;
         }
      }
   }

   // No match was found. Return last found event.
   emit db_speedsearch_reply(mIndex[ss_last_found_index]->metadata.pos_pindex);
   return;
}




// **********************************************************************
// This function is signaled from class 'EnumSfiles'. It is used to
// report to class MainWindow the progress of S-file enumeration.
// Progress = number of files read so far.
// **********************************************************************
void db::EnumSfilesProgress(int Progress)
{
   if (db_status == db::closed) return;
   emit db_open_progress(db_status, Progress);
}




// *************************************************************************************
// This function is signaled from class 'EnumSfiles' when S-file enumeration is done.
// Value of 'status': 0-OK, 1-Limitation reached.
// *************************************************************************************
void db::EnumSfilesDone(char status)
{
   switch (status) {
   case 0:
      // If S-files was found, read them into database.
      // This is done in a separate background thread.
      if (sfilelist.size()) {
         // At lease one S-file was found.
         set_db_status(read_sfiles);
         ReadSfiles.start();
      } else {
         // No events was read, init database.
         Init();
         // Give parent class the result of the open operation.
         emit db_open_result(db_status, no_files_found);
      }
      break;

   case 1:
      // We reached the limitation for max number of files. Write warning to the log.
      Message = "The program limitation of ";
      Message.append(QString().number(MAX_EVENTS));
      Message.append(" events has been reached. Seisan database has not been fully read.");
      Log->WriteLog(logmodel::warning, Message);

      // Read S-files into database. This is done in a separate background thread.
      set_db_status(read_sfiles);
      ReadSfiles.start();
      break;
   }
}




// **********************************************************************
// This function is called from 'ReadSfiles' when reading is done.
// Value of 'status': 0=OK, 1=Out of memory,
//                    2=One or several bad S-files was skipped.
// **********************************************************************
void db::ReadSfilesDone(char Status)
{
   // Get number of events in database.
   int numevents = num_pi_events();

   // Signal that S-file reading is 100% done.
   emit db_open_progress(db_status, 100);

   switch (Status) {
   case 0:
      // ReadSfiles() succeeded with no errors.
      if (numevents) {
         // Change database status to 'open'.
         set_db_status(open);
         // Give parent class the result of the open operation.
         emit db_open_result(db_status, no_error);
      } else {
         // No events was read, close database.
         Init();
         // Give parent class the result of the open operation.
         emit db_open_result(db_status, no_files_found);
      }
      break;

   case 1:
      // We run out of memory while reading S-files.
      if (numevents) {
         // Database will open with too few events.
         set_db_status(open);
         emit db_open_result(db_status, out_of_memory);
      } else {
         // No events was read, close database.
         Init();
         // Give parent class the result of the open operation.
         emit db_open_result(db_status, out_of_memory);
      }
      break;

   case 2:
      // One or several corrupt S-files was skipped.
      if (numevents) {
         // Database will open with too few events.
         set_db_status(open);
         emit db_open_result(db_status, corrpupt_files);
      } else {
         // No events was read, close database.
         Init();
         // Give parent class the result of the open operation.
         emit db_open_result(db_status, corrpupt_files);
      }
      break;
   }
}




// *****************************************************
// Get database operational status.
// *****************************************************
db::dbStatus db::Status(void)
{
   return get_db_status();
}




// *****************************************************
// Apply a filter to the database.
// *****************************************************
int db::ApplyFilter(db_filter Filter)
{
   int size;
   QString ErrMsg;
   char progr, lastprogr;
   QStringList iQuery, eQuery;

   // If a filter is already applied then remove it first.
   if (filter_applied) RemoveFilter();

   // Convert filter expressions from infix to postfix.
   // Return -1 if any errors occurs during conversion.
   if (!Infix2Postfix(Filter.InclQuery, &iQuery, &ErrMsg)) return -1;
   if (!Infix2Postfix(Filter.ExclQuery, &eQuery, &ErrMsg)) return -1;

   // Save the filter (in postfix format).
   DbFilter.Description = Filter.Description;
   DbFilter.InclQuery = iQuery;
   DbFilter.ExclQuery = eQuery;

   // Evaluate filter expressions for all nodes.
   // The metadata property 'filtered_out' will
   // be set 'true' for nodes that are excluded
   // by the filter include/exclude expressions.
   progr = lastprogr = 0; size = mIndex.size();
   for (int index=0;index<size;index++) {
      // Filter the node.
      FilterNode(mIndex[index]);
      // Update status bar progress info.
      progr = (char)(100.0/((float)size/(float)index));
      if (progr > lastprogr) {
         lastprogr = progr;
         emit db_filter_progress(progr);
      }
   }
   // Make sure that 100% progress is reported.
   if (progr < 100) emit db_filter_progress(100);

   // Set filter status.
   filter_applied = true;

   // Rebuild presentation index.
   RebuildPresenIndex();

   // Write message to the program log.
   Message = "Event List filter is applied. ";
   if (Filter.Description.size()) Message.append("Filter description: " + Filter.Description);
   Log->WriteLog(logmodel::info, Message);

   // Return the new number of events in pIndex.
   return num_pi_events();
}




// *****************************************************
// Remove filter from database.
// *****************************************************
void db::RemoveFilter(void)
{
   if (filter_applied) {
      // Clear filter flag on all nodes in master index.
      int size = mIndex.size();
      for (int i=0;i<size;i++) mIndex[i]->metadata.filtered_out = false;

      // Set filter status.
      filter_applied = false;

      // Rebuild the presentation index.
      RebuildPresenIndex();

      // Write message to the program log.
      Log->WriteLog(logmodel::info, "Filter has been removed.");
   }
}




// *************************************************
// Evaluate filter expressions for a node. The value
// metadata->filtered_out will be set to true if the
// node is excluded by the filter.
// *************************************************
void db::FilterNode(event_node_ *Node)
{
   // Evaluate the include expression for this node.
   if (EvaluatePostfix(DbFilter.InclQuery, Node)) {
      // The include expression has included this node.
      // Evaluate the exclude expression for this node.
      if (EvaluatePostfix(DbFilter.ExclQuery, Node)) {
         // The current node is excluded.
         Node->metadata.pos_pindex = -1;
         Node->metadata.filtered_out = true;
      }
   } else {
      // The current node is excluded.
      Node->metadata.pos_pindex = -1;
      Node->metadata.filtered_out = true;
   }
}




// *****************************************************
// Returns true if a filter is applied to database.
// *****************************************************
bool db::isFilterApplied()
{
   return filter_applied;
}




// ******************************************************************
// Starts from bottom of the index list and searches upward for an
// event that can not be sorted. Stops at the first found event
// and returns the offset into index list for this event. Function
// will return -1 if no unsortable event was found.
// ******************************************************************
int db::GetLastUnsortable()
{
   int index = num_pi_events() -1 ;
   while (index >= 0) {
      switch (sort_col) {
         case Action:
         if (!pIndex[index]->action[0]) return index;
         break;

         case Latitude:
         if (pIndex[index]->hypocenters.first->lat == -999.0) return index;
         break;

         case Longitude:
         if (pIndex[index]->hypocenters.first->lon == -999.0) return index;
         break;

         case Depth:
         if (pIndex[index]->hypocenters.first->depth == -999.0) return index;
         break;

         case Model:
         if (pIndex[index]->hypocenters.first->modl_id == 32) return index;
         break;

         case Agency:
         if (pIndex[index]->hypocenters.first->agency[0] == 32) return index;
         break;

         case RMS:
         if (pIndex[index]->hypocenters.first->rms == -999.0) return index;
         break;

         case Gap:
         if (pIndex[index]->hypocenters.first->gap == -999.0) return index;
         break;

         case ErrLat:
         if (pIndex[index]->hypocenters.first->lat_err == -999.0) return index;
         break;

         case ErrLon:
         if (pIndex[index]->hypocenters.first->lon_err == -999.0) return index;
         break;

         case ErrDep:
         if (pIndex[index]->hypocenters.first->depth_err == -999.0) return index;
         break;

         case Dist:
         if (pIndex[index]->hypocenters.first->dist_id == 32) return index;
         break;

         case Type:
         if (pIndex[index]->hypocenters.first->evnt_id == 32) return index;
         break;

         case MInt:
         if (!pIndex[index]->macros.numlines) return index;
         break;

         case NSta:
         if (pIndex[index]->hypocenters.first->nstat == -999) return index;
         break;

         case M:
         if (!pIndex[index]->hypocenters.mag_all) return index;
         break;

         case MW:
         if (pIndex[index]->hypocenters.first->magnitudes.MW.nmag == 0) return index;
         break;

         case ML:
         if (pIndex[index]->hypocenters.first->magnitudes.ML.nmag == 0) return index;
         break;

         case MN:
         if (pIndex[index]->hypocenters.first->magnitudes.MN.nmag == 0) return index;
         break;

         case MC:
         if (pIndex[index]->hypocenters.first->magnitudes.MC.nmag == 0) return index;
         break;

         case Mb:
         if (pIndex[index]->hypocenters.first->magnitudes.Mb.nmag == 0) return index;
         break;

         case MB:
         if (pIndex[index]->hypocenters.first->magnitudes.MB.nmag == 0) return index;
         break;

         case Ms:
         if (pIndex[index]->hypocenters.first->magnitudes.Ms.nmag == 0) return index;
         break;

         case MS:
         if (pIndex[index]->hypocenters.first->magnitudes.MS.nmag == 0) return index;
         break;

         case Locality:
         if (!pIndex[index]->locality[0]) return index;
         break;

         default:
         break;
      }
      index--;
   }

   // If we return down here, then all events are sortable.
   return -1;
}




// ******************************************************************
// This function moves all unsortable events
// in the pIndex list to the bottom.
// ******************************************************************
void db::MoveUnsortablesDown()
{
   int numevents, count;
   int num_unsortables, index;
   event_node_* pNode;

   numevents = pIndex.size();
   if ((index = GetLastUnsortable()) != -1) {
      num_unsortables = index + 1;
      if (num_unsortables < numevents) {
         for (count=1;count<=num_unsortables; count++) {
            pNode = pIndex.first();
            pIndex.append(pNode);
            pIndex.removeFirst();
         }
      }
   }
}




// ******************************************************************
// Sorts the master index list by date/time.
// ******************************************************************
void db::SortMasterIndex()
{
   // Sort mIndex by date/time using qStableSort.
   // The 'LessThan_DateTime' function are implemented in eventnode.cpp.
   qStableSort(mIndex.begin(), mIndex.end(), LessThan_DateTime);

   // Updates the 'pos_mindex' metatag for all nodes so that
   // they hold the node's current position in the mIndex list.
   int size = mIndex.size();
   for (int index=0;index<size;index++) { mIndex[index]->metadata.pos_mindex = index; }
}




// *******************************************************************
// Sorts the presentation index list by the currently selected
// column. Unsortable events will be placed last. If pIndex is sorted
// by date/time before calling this function, then the unsortable
// events will be ordered by date/time.
// *******************************************************************
void db::SortPresenIndex()
{
   // Sort pIndex by current sort column using qStableSort.
   // The 'LessThan' functions are implemented in eventnode.cpp.
   if (sort_col == Action) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Action);
   if (sort_col == Latitude) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Latitude);
   if (sort_col == Longitude) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Longitude);
   if (sort_col == Depth) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Depth);
   if (sort_col == Model) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Model);
   if (sort_col == Agency) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Agency);
   if (sort_col == RMS) qStableSort(pIndex.begin(), pIndex.end(), LessThan_RMS);
   if (sort_col == Gap) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Gap);
   if (sort_col == ErrLat) qStableSort(pIndex.begin(), pIndex.end(), LessThan_ErrLat);
   if (sort_col == ErrLon) qStableSort(pIndex.begin(), pIndex.end(), LessThan_ErrLon);
   if (sort_col == ErrDep) qStableSort(pIndex.begin(), pIndex.end(), LessThan_ErrDep);
   if (sort_col == Dist) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Dist);
   if (sort_col == Type) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Type);
   if (sort_col == MInt) qStableSort(pIndex.begin(), pIndex.end(), LessThan_MInt);
   if (sort_col == NSta) qStableSort(pIndex.begin(), pIndex.end(), LessThan_NSta);
   if (sort_col == M) qStableSort(pIndex.begin(), pIndex.end(), LessThan_M);
   if (sort_col == MW) qStableSort(pIndex.begin(), pIndex.end(), LessThan_MW);
   if (sort_col == ML) qStableSort(pIndex.begin(), pIndex.end(), LessThan_ML);
   if (sort_col == MN) qStableSort(pIndex.begin(), pIndex.end(), LessThan_MN);
   if (sort_col == MC) qStableSort(pIndex.begin(), pIndex.end(), LessThan_MC);
   if (sort_col == Mb) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Mb);
   if (sort_col == MB) qStableSort(pIndex.begin(), pIndex.end(), LessThan_MB);
   if (sort_col == Ms) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Ms);
   if (sort_col == MS) qStableSort(pIndex.begin(), pIndex.end(), LessThan_MS);
   if (sort_col == Locality) qStableSort(pIndex.begin(), pIndex.end(), LessThan_Locality);
   if (sort_col == SFile) qStableSort(pIndex.begin(), pIndex.end(), LessThan_SFile);
}




// **********************************************************************
// This function rebuilds the presentation index from the master index.
// **********************************************************************
void db::RebuildPresenIndex()
{
   // This may take some time. Show the wait cursor.
   QApplication::setOverrideCursor(Qt::WaitCursor);

   // Copy all events from the master index.
   CopyMasterToPresentation();

   // Sort the presentation index. This function
   // will move all unsortables to the bottom of
   // the list and they will be sorted by date/time.
   SortPresenIndex();

   // Reverse the presentation index if
   // sort order is 'Qt::DescendingOrder'.
   if (sort_ord == Qt::DescendingOrder) {
      int size = pIndex.size(); int half = size/2;
      for (int i=0;i<half;i++) pIndex.swap(i, size - i - 1);

      // After reversing, move all unsortable nodes to the bottom.
      if (sort_col != DateTime) MoveUnsortablesDown();
   }

   // Update the node's positions in pIndex.
   UpdateNodePositions(false);

   // Restore the cursor.
   QApplication::restoreOverrideCursor();
}




// **********************************************************************
// This function updates the 'pos_pindex' metatag for all nodes in the
// presentation index list so that they hold the node's current position
// in the pIndex list. Optionally also updates the 'pos_mindex' metatag
// for all nodes in the master index list.
// **********************************************************************
void db::UpdateNodePositions(bool update_pos_mindex)
{
   int size = num_pi_events();
   for (int index=0;index<size;index++) {
      pIndex[index]->metadata.pos_pindex = index;
   }
   if (update_pos_mindex) {
      size = mIndex.size();
      for (int index=0;index<size;index++) {
         mIndex[index]->metadata.pos_mindex = index;
      }
   }
}




// *****************************************************************
// This function safely sets the value of variable db_status.
// ******************************************************************
void db::set_db_status(dbStatus status)
{
   mtx_db_status.lock();
   db_status = status;
   mtx_db_status.unlock();
}




// *****************************************************************
// This function safely return the value of variable db_status.
// ******************************************************************
db::dbStatus db::get_db_status()
{
   mtx_db_status.lock();
   dbStatus status = db_status;
   mtx_db_status.unlock();
   return status;
}




// ******************************************************************
// This function safely returns number of events in the pIndex list.
// This function is needed becase QList is not thread safe.
// ******************************************************************
int db::num_pi_events()
{
   mtx_pindex.lock();
   int size = pIndex.size();
   mtx_pindex.unlock();
   return size;
}




// ***************************************************************************
// This function writes a updated S-file for a loaded event. The loaded event
// node must have been been updated before calling this function, and should
// be ready to be written to file.
//
// If 'OldFile' is given, then new the S-file will be written with a different
// name than the existing file, and the old file will be deleted. The new name
// for the event file must be present in the node's metadata structure.
//
// Note: The new event file will not be reloaded by this function.
//
// Return values in 'status':
// 0 - No error.
// 1 - Could not backup the old S-file.
// 2 - Could not write new S-file. Backup file has been restored.
// 3 - Could not write new S-file. Could not restore backup file.
// *************************************************************************
bool db::UpdateSfile(int index, char *Status, QString OldFile)
{
   bool bStatus;
   char cStatus;
   QString EventFile, BackupFile;

   // Check that index is not out of bounds.
   if (index < 0) return false;
   if (index >= num_pi_events()) return false;

   // Make pointer to the event node.
   event_node_ *Node = pIndex[index];

   // Name the new event file.
   EventFile = QString(Node->metadata.sfile);

   if (OldFile.size()) {
      // Event file will be saved with a different name.
      // Delete the new event file if it already exists.
      if (QFile::exists(EventFile)) QFile::remove(EventFile);
      // Write the new event file.
      mtx_db_cblock.lock();  bStatus = WriteSfile(Node, &cStatus); mtx_db_cblock.unlock();
      // Handle result from WriteSfile().
      if (!bStatus) {
         // Failed to write new event file.
         // Delete the new event file if it exists.
         if (QFile::exists(EventFile)) QFile::remove(EventFile);
         *Status = 2; return false;
      } else {
         // Succeeded writing the new event file. Remove the old file.
         QFile::remove(OldFile);
      }
   } else {
      // Event file will be saved with the same name.
      // Create the name of the temporary backup file.
      BackupFile = EventFile + ".sebk";
      // Delete an existing file with the same name.
      if (QFile::exists(BackupFile)) if (!QFile::remove(BackupFile)) { *Status = 1; return false; }
      // Rename the event file to the name of the backup file.
      if (!QFile::rename(EventFile, BackupFile)) { *Status = 1; return false; }
      // Write the new event file.
      mtx_db_cblock.lock(); bStatus = WriteSfile(Node, &cStatus); mtx_db_cblock.unlock();
      if (!bStatus) {
         // Failed to write new event file. Restore backup file if possible.
         if (QFile::exists(EventFile)) QFile::remove(EventFile);
         if (QFile::rename(BackupFile, EventFile)) { *Status = 2; } else { *Status = 3; }
         return false;
      } else {
         // Succeeded writing the new event file. Remove the backup file.
         QFile::remove(BackupFile);
      }
   }

   // S-file was sucessfully created.
   *Status = 0;
   return true;
}




// *************************************************************************
// Find events in pIndex that are close to each other in time. Function will
// always traverse event list from top to bottom regardless of current sort
// order. Returns a list of indexes in 'IndexList'.
// *************************************************************************
void db::AssociateEvents(int TimeInt, int StartIndex, QList<int> *IndexList)
{
   bool done;
   int i, NumEvents;
   db_time *Time1, *Time2;

   // Find events that are close in time.
   NumEvents = num_pi_events(); i = StartIndex;
   while (i < NumEvents-1) {
      Time1 = &pIndex[i]->hypocenters.first->time;
      Time2 = &pIndex[i+1]->hypocenters.first->time;
      if (TimeDiff(Time1, Time2) <= abs(TimeInt)) {
         // We have found two events close in time.
         // Add the two events to IndexList.
         IndexList->append(i); IndexList->append(i+1);
         // See if more events fit within time interval.
         done = false; i = i+2;
         while (i < NumEvents && !done) {
            Time2 = &pIndex[i]->hypocenters.first->time;
            if (TimeDiff(Time1, Time2) <= (double)TimeInt) {
               // Add another event to IndexList.
               IndexList->append(i); i++;
            } else {
               done = true; i--;
            }
         }
      }
      // Go to the next event.
      i++;
   }
}




// *****************************************************
// Free up all memory used by the database event nodes.
// *****************************************************
void db::FreeDatabaseNodes()
{
   // Get size of mIndex list (number of nodes).
   int size = mIndex.size();

   // Free all database nodes.
   for (int node=0;node<size;node++) FreeNode(mIndex[node]);
}
