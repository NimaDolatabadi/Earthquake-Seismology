#ifndef NUMBEREDTXTLISTDLG_H
#define NUMBEREDTXTLISTDLG_H

#include <QDialog>

namespace Ui {
class NumberedTxtListDlg;
}

class NumberedTxtListDlg : public QDialog
{
   Q_OBJECT

public slots:
   void accept();
   void reject();

public:
   explicit NumberedTxtListDlg(QWidget *parent = 0);
   ~NumberedTxtListDlg();
   void Init(QString, QStringList, QString, QString*, bool*);
   void Init(QString, QStringList, QStringList, QString, QString*, QString*, bool*);

private:
   Ui::NumberedTxtListDlg *ui;
   bool *CheckStatus, ReturnValue;
   QString TextLine, *Selection, *Value;
};

#endif // NUMBEREDTXTLISTDLG_H
