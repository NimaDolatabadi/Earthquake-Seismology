#ifndef SEISANDB_H
#define SEISANDB_H

#include <QDir>
#include <QDate>
#include <QTime>
#include <QString>
#include "types.h"

struct sfile_nameinfo {
   QString Year;
   QString Month;
   QString Path;
   QString Name;
   QDate Date;
   QTime Time;
   QDateTime DateTime;
   QString DateStr;
   QString TimeStr;
   QString Database;
   QString DatabaseType;
   QChar DistId;
};

void GetSfileNameInfo(QString, sfile_nameinfo*);
void AddOneSecToSfileName(QString*);
bool DuplicateSfileOnDisk(QString, QString*, QString);
int MergeSfilesOnDisk(QString, QString);
bool GetSfileIdLine(QString, QString*);
bool SetSfileIdLine(QString, QString);
int DeleteSfileFromDisk(QString, db_info);

#endif // SEISANDB_H
