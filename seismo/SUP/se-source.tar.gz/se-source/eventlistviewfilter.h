#ifndef EVENTLISTVIEWFILTER_H
#define EVENTLISTVIEWFILTER_H

#include <QObject>

class eventlistviewfilter : public QObject
{
   Q_OBJECT

public:
   explicit eventlistviewfilter(QObject *parent = 0);
   bool eventFilter(QObject*, QEvent*);

signals:
   void ActivateSpeedSearch(char);
   void ELV_Add_ARC_Line_To_Sfile();
   void ELV_Add_Type1_Line_To_Sfile();
   void ELV_Associate_Events();
   void ELV_Copy_Events();
   void ELV_Delete_Events();
   void ELV_Merge_Events();
   void ELV_Duplicate_Event();
   void ELV_Edit_With_Text_Editor();
   void ELV_Edit_StationHyp();
   void ELV_Edit_Comment_Lines();
   void ELV_GoToNextNewEvent();
   void ELV_GoToRowNr();
   void ELV_Launch_EEV();
   void ELV_Reload_Event();
   void ELV_Load_Event();
   void ELV_Unload_Event();
   void ELV_Locate_Event();
   void ELV_Unmark_All();
   void ELV_Plot_With_Mulplot();
   void ELV_Plot_With_Mulplot_Menu();
   void ELV_Refresh_View();
   void ELV_Select_All();
   void ELV_Register_Event();
   void ELV_Set_Distance_Indicator();
   void ELV_Set_Event_Indicator();
   void ELV_Set_Model_Indicator();
   void ELV_Set_Filter();
   void ELV_Set_Time_Interval();
   void ELV_Show_Events_With_GE();
   void ELV_Show_Events_With_SV();
   void MarkUnmarkSelectedRows();
   void UnmarkAllRows();
   void ScrollToNextMarkedEvent();
   void ScrollToPrevMarkedEvent();
   void ScrollToNextSelection();
   void ScrollToPrevSelection();
};

#endif // EVENTLISTVIEWFILTER_H
