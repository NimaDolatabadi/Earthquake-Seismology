#ifndef SIMPLEWAVEFORMVIEWERDLG_H
#define SIMPLEWAVEFORMVIEWERDLG_H

#include <QDialog>
#include "database.h"
#include "qcustomplot.h"


namespace Ui {
   class SimpleWaveformViewerDlg;
}

class SimpleWaveformViewerDlg : public QDialog
{
   Q_OBJECT

public:
   explicit SimpleWaveformViewerDlg(QWidget *parent = 0);
   ~SimpleWaveformViewerDlg();

private slots:
   void SimpleWaveformViewerDlg_plot();
   void outputPDF();
   void outputPNG();

private:
   Ui::SimpleWaveformViewerDlg *ui;
   db *DataBase;
};

#endif
