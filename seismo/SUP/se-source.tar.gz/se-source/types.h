#include <QtGlobal>
#include <QDate>
#include <QString>
#include <QStringList>
#include <stdlib.h>

#ifndef TYPES_H
#define TYPES_H

// Type definitions.
typedef QList<int> QListInt;
typedef QList<struct event_id> QListEventID;
typedef QList<struct coord> QListCoord;
typedef QList<struct phase_> QListPhase;

// Program limitations.
#define MAX_EVENTS  1000000             // Max number of S-files the program can handle. Must be divisible by 1000.
#define MAX_SFILE_LINES  10000          // Max number of lines in an S-file.
#define MAX_PATH 260                    // Max allowed length of full path to a file.

// Define name of files.
#define WORKDIR_LOCK_FILE (const char *)("se-workdir.lock")

// Defines related to Google Earth.
#define PRI_KML_FILE (const char *)("se-gmap.kml")
#define SEC_KML_FILE (const char *)("gmap.cur.kml")

// Defines related to the use of QMessageBox.
#define QMB_YES QMessageBox::Yes
#define QMB_NO QMessageBox::No


//**********************************************
// Define names for all event list view columns.
//**********************************************
#define NumElvColumns  28
#define ColRowNumber    0
#define ColAction       1
#define ColDateTime     2
#define ColLatitude     3
#define ColLongitude    4
#define ColDepth        5
#define ColModel        6
#define ColAgency       7
#define ColRMS          8
#define ColGap          9
#define ColErrLat       10
#define ColErrLon       11
#define ColErrDep       12
#define ColDist         13
#define ColType         14
#define ColMInt         15
#define ColNrSta        16
#define ColM            17
#define ColMW           18
#define ColML           19
#define ColMN           20
#define ColMC           21
#define ColMb           22
#define ColMB           23
#define ColMs           24
#define ColMS           25
#define ColLocality     26
#define ColSFile        27

enum sortCol {
   RowNr,                              // Cannot sort by this column.
   Action,                             // Always present in event node.
   DateTime,                           // Not always present, or partly present.
   Latitude,                           // Not always present in event node.
   Longitude,                          // Not always present in event node.
   Depth,                              // Not always present in event node.
   Model,                              // Not always present in event node.
   Agency,                             // Always present in event node.
   RMS,                                // Not always present in event node.
   Gap,                                // Not always present in event node.
   ErrLat,                             // Not always present in event node.
   ErrLon,                             // Not always present in event node.
   ErrDep,                             // Not always present in event node.
   Dist,                               // Always present in event node.
   Type,                               // Not always present in event node.
   MInt,                               // Not always present in event node.
   NSta,                               // Not always present in event node.
   M,                                  // Not always present in event node.
   MW,                                 // Not always present in event node.
   ML,                                 // Not always present in event node.
   MN,                                 // Not always present in event node.
   MC,                                 // Not always present in event node.
   Mb,                                 // Not always present in event node.
   MB,                                 // Not always present in event node.
   Ms,                                 // Not always present in event node.
   MS,                                 // Not always present in event node.
   Locality,                           // Not always present in event node.
   SFile                               // Always present in event node.
};

struct event_id {
   int index;
   int id;
};

struct db_filter {
   QString Description;
   QString InclQuery;
   QString ExclQuery;
};

struct coord {
   float lat;
   float lon;
};

struct frdata {
   QString SearchText;
   QString ReplaceText;
   bool CaseSensitive;
};

struct tm_int {
   QDate StartDate;                 // Start of interval (oldest date).
   QDate EndDate;                   // End of interval (newest date).
   int EndDateType;                 // Indicates one of 1='Current date', 2='End of month', or 3='User specified'.
};


// *****************************************************
// Structures related to the database.
// *****************************************************
enum db_type {
   default_database,                   // Database with name given in environment variable 'DEF_BASE'. Database
                                       // folders must be located in a REA folder. Location of REA folder is given
                                       // in environment variable 'SEISAN_TOP'.
   normal_database,                    // Folder containing database with year/month subfolers (C:\Seismo\REA\TEST_).
   local_database,                     // Folder with collection of S-files.
   index_file,                         // A file with list of S-files.
   no_database
};

struct db_info {
   db_type Type;
   QString Name;
   QString Path;
};

struct db_time {
   int year = -999;
   int month  = -999;
   int day  = -999;
   int hour  = -999;
   int minute  = -999;
   float second  = -999;
};


// ****************************************
// Class holding the program configuration.
// ****************************************
struct se_config {
   // Time interval dialog.
   tm_int TimeIntDates;             // Time interval dates.

   // Configuration dialog.
   int TimeInterval;                // Default timespan between start date and stop date (in days).
   bool UsePrevTimeInterval;        // Specifies if Explorer will load last used timeinterval at startup. In this case 'EndDateType' will be set to 3.
   bool AutoLoad;                   // Specifies if Explorer will load last used database at startup.

   // Database.
   db_type LastUsedDatabaseType;    // Type of database last opened. Valus of 0 means 'no last used database'.
   QString LastUsedDatabaseName;    // Name of last used database.
   QString LastUsedDatabasePath;    // Path to last used database.

   // Event List View.
   bool EvtListColStat[NumElvColumns-4]; // List of bools deciding which columns to show in event list.

   // Log View.
   bool AutoSaveLog;                // Specifies if Explorer will save the log window at exit.

   // Work directory.
   int WorkDirType;                 // Type of working directory currently chosen. Default type = 0;
                                    // 0 = $SEISAN_TOP/WOR,
                                    // 1 = The directory that SE was launched from.
                                    // 2 = A user specified directory.
   QString UserWorkDir;             // The user specified work directory.

   // Google Static Map.
   QString StaticMapApiKey;         // Google static map API key. Can be used with 'Show on Google Map'.
   QString DefaultMapType;          // Default map type.
   QString DefaultZoomLevel;        // Default zoom level.

   // These members that are placed here for convenience.
   // They are NOT saved/loaded between program sessions.
   QString AppLaunchDir;            // The directory that Explorer was launched from.
   QString SeisanWorkDir;           // The standard Seisan work directory ($SEISAN_TOP/WOR).
   QString SeisanDatDir;            // The Seisan DAT directory ($SEISAN_TOP/DAT).
   QString SEISAN_TOP;              // The Seisan installation folder.
   QString DEF_BASE;                // The default database in REA folder.
   QString SEISAN_DEF;              // Path to SEISAN.DEF file.
};


// *****************************************************
// Structures used to hold event data in database.
// *****************************************************
struct metadata_ {
   int event_id = 0;                    // A unique Sisan Explorer ID for the event
   int pos_mindex = 0;                  // Event's index in the mIndex list
   int pos_pindex = 0;                  // Event's index in the pIndex list
   float dist2rp = 0;                   // Distance to ref. point. Holds value for column 'DstToRP'
   bool filtered_out = false;           // True if event is filtered out from event list view
   bool marked = false;                 // True if this event is marked in the event list view
   char sfile[MAX_PATH] = "";           // Full path to the event file.
   char datetime[13]  = "";             // Date/time for event in string format ('yyyymmddhhmm')
};

struct text_lines {
   int numlines = 0;                    // Number of lines in the 'lines' string
   char *lines = 0;                     // Pointer to string with lines. All lines are 80 characters long
};                                      // The lines in the string are NOT seperated by any character

struct spectral_ {
   float moment = 0;                    // Log moment, Nm
   float sdrop = 0;                     // Stress drop, bar
   float omega0 = 0;                    // Log spectral flat level, ns
   float cornerf = 0;                   // Corner f
   float radius = 0;                    // Source radius
   float swin = 0;                      // Window lenght used
   float vs = 0;                        // S-velocity at source, km/s
   float vp = 0;                        // P-velocity at source, km/s
   float q0 = 0;                        // Q0
   float qalpha = 0;                    // Q alpha
   float kappa = 0;                     // Kappa
   float density = 0;                   // Density g/cm**3
   float slope = 0;                     // Measured slope of spectrum
   float geo_dist = 0;                  // Geo distance
};

struct magn_ {
   float mc = -999;                     // Coda
   float ml = -999;                     // Local
   float mb = -999;                     // mb
   float ms = -999;                     // ms
   float mw = -999;                     // mw
};

struct phase_ {
   // Phase data parameters.
   char agency[6] = "";                 // Agency
   char comp[5] = "";                   // Components
   char co[3] = "";                     // 2 letter components
   char phase[9] = "";                  // Phase name
   char onset = 32;                     // Onset I or E or blank
   char weight_in = 32;                 // Input weight
   char weight_out[3] ="";              // Weight out
   char polarity;                       // Polarity, D or C
   int year = -999;                     // Date and time
   int month = -999;
   int day = -999;
   int hour = -999;
   int min = -999;
   float sec = -999;
   double abs_time = 0;                 // Abs time of phase time
   float coda = -999;                   // Coda length in sec
   float amp = -999;                    // Amplitude (in Nm)
   float per = 0;                       // Period of amplitude
   float baz_obs = -999;                // Observed back azimuth
   float baz_cal = -999;                // Calculated back azimuth
   float vel = -999;                    // Observed apparent velocity
   float ain = -999;                    // Observed signal to noise ratio
   float baz_res = -999;                // Back azimuth residual
   float res = -999;                    // Travel time residual
   float dist = -999;                   // Epicentral distance
   float az = -999;                     // Azimuth
   char autoproc[21] = "";              // Name of auto process for making par
   struct spectral_ spectral;           // Spectral data for phase
   struct magn_ magnitudes;             // Magnitude data for phase
   struct phase_ *next;                 // Pointer to the next phase in linked list
};

struct phases_ {
   int nphase = 0;                      // Number of phases
   struct phase_ *first = 0;            // Pointer to first phase in list
};

struct mag_info {
   float mag = -999;                    // Magnitude value
   char type = 32;                      // Magnitude type
   char agency[6] = "";                 // Magnitude agency
   bool main_agency;                    // If true, this magnitude belongs to the prime location.
};

struct hyp_mag_type {
   char nmag = 0;                                   // Number of magnitudes in arrays
   float mag[6] = {-999,-999,-999,-999,-999,-999};  // Magnitude
   char mag_agency[6][6] {"","","","","",""};       // Agency
   int order[6] = {-999,-999,-999,-999,-999,-999};  // Magnitude order (zero based). This array is used by WriteSfile
                                                    // to write magnitues back to common blocks in the right order;
};

struct hyp_magnitudes_ {
   struct hyp_mag_type MW;
   struct hyp_mag_type ML;
   struct hyp_mag_type MN;
   struct hyp_mag_type MC;
   struct hyp_mag_type Mb;
   struct hyp_mag_type MB;
   struct hyp_mag_type Ms;
   struct hyp_mag_type MS;
   struct hyp_mag_type MU;                      // This magnitude has an unknown/blank type.
};

struct hypocenter_ {
   struct db_time time;                         // Hypocenter date and time
   char modl_id = 32;                           // Location model indicator
   char dist_id = 32;                           // Distance indicator (LRD)
   char evnt_id = 32;                           // Event indicator (like E)
   char fix_org = 32;                           // Fix origin time flag
   float lat = -999;                            // Latitude
   float lon = -999;                            // Longitude
   float depth  = -999;                         // Depth
   char depth_flag = 32;                        // Depth flag
   char epi_flag = 32;                          // Epicenter flag
   char agency[6] = "";                         // Hypocenter agency, 3 characters only
   int nstat = -999;                            // Number of stations
   float rms = -999;                            // RMS of hypocenter solution
   char high_accuracy = 0;                      // High accurcy flag
   char error = 0;                              // True if hypocenter has an error
   char autoproc[21] = "";                      // Name of auto process for parameter
   float gap = -999;                            // Gap, degrees
   float sec_err = -999;                        // Origin time error (sec)
   float lat_err = -999;                        // Latitude error (km)
   float lon_err = -999;                        // Longitude error (km)
   float depth_err= -999;                       // Depth error (km)
   float cov[3] = {-9.9e10, -9.9e10, -9.9e10};  // Covariance, xy,xz,yz (kmXkm) (Allways 3 values here)
   struct hyp_magnitudes_ magnitudes;           // Magnitudes
   struct hypocenter_ *next = 0;                // Pointer to the next hypocenter
};

struct hypocenters_ {
   int nhyp = 0;                       // Number of hypocenters
   int nmag = 0;                       // Number of magnitudes in 'mag_all' array.
   mag_info *mag_all = 0;              // All magnitudes. Pointer to array of nmag mag_info structures
   struct hypocenter_ *first = 0;      // Pointer to the first hypocenter
};

struct spec_avg_ {
   float av_moment = -999;             // Log moment (Nm)
   float av_sdrop = -999;              // Stress drop, bar
   float av_omega0 = -999;             // Log spectral flat level, ns
   float av_cornerf = -999;            // Corner f
   float av_radius = -999;             // Source radius
   float av_swin = -999;               // Window length used
   float av_mw = -999;                 // Moment mag
   float av_slope = -999;              // Slope
};


struct event_node_ {
   int nstat = 0;                      // Number of stations
   int nhead = 0;                      // Number of header lines
   int nrecord = 0;                    // Number of records
   int nspec = 0;                      // Number of spectra
   char id_line[81] = "";              // Event ID line
   char action[4] = "";                // Action parameter from ID line
   char locality[69] = "";             // Locality
   struct metadata_ metadata;          // Metadata (data not read from eventfile)
   struct text_lines macros;           // Structure holding all macro data
   struct text_lines wavefiles;        // Structure holding all wave filenames
   struct text_lines faults;           // Structure holding all fault lines
   struct text_lines comments;         // Structure holding all comment lines
   struct phases_ phases;              // Structure holding all phase data
   struct spec_avg_ spectral_avg;      // Structure holding spectral averages
   struct hypocenters_ hypocenters;    // Structure holding all hypcocenter data
};

#endif // TYPES_H
