/*
 * 2014-06-20 Peter Voss: fixed for qcp 1.2.1
*/
#include "waveformviewerdlg.h"
#include "ui_waveformviewerdlg.h"
#include "mainwindow.h"
#include <cstdlib>
#include <QString>
#include <QFileDialog>

#include <iostream>
#include "qcustomplot.h"

SimpleWaveformViewerDlg::SimpleWaveformViewerDlg(QWidget *parent) : QDialog(parent), ui(new Ui::SimpleWaveformViewerDlg) {

    ui->setupUi(this);

    // Initial plot
    SimpleWaveformViewerDlg_plot();
    connect( ui->pushButton_done, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( ui->pushButton_PDF, SIGNAL( clicked() ), this, SLOT( outputPDF() ) );
    connect( ui->pushButton_PNG, SIGNAL( clicked() ), this, SLOT( outputPNG() ) );

    // Plot when "Replot" is clicked
    connect( ui->pushButton_plot, SIGNAL( clicked() ), this, SLOT( SimpleWaveformViewerDlg_plot() ) );
}

SimpleWaveformViewerDlg::~SimpleWaveformViewerDlg() {
    delete ui;
}


void SimpleWaveformViewerDlg::outputPDF() {
    ui->customPlot->savePdf("pv.pdf",0,700,700);
}


void SimpleWaveformViewerDlg::outputPNG() {
    ui->customPlot->savePng("pv.png",700,700,1,-1);
}


void SimpleWaveformViewerDlg::SimpleWaveformViewerDlg_plot() {

   ui->customPlot->clearPlottables();

   QString fn = QFileDialog::getOpenFileName(this, tr("Open File..."),
                 QDir::currentPath(), tr("*.WAV Files (*.wav);;All Files (*)"));

   // Return if no file has been selected.
   if (!fn.size()) return;

   QFile inputFile(fn);
   int count=0;
   double minX=0.0;
   double maxX=100.0;
   QVector<double> StartTime(999);
   QVector<double> samples(999);
   QVector<double> SampleInterval(999);
   int HeaderLine=0;
   int NumberOfSamples;
   int trace;
   int NumberOfTraces = 0;

   QTextStream in(&inputFile);
   QList< QStringList > header;
   QList< QStringList > lists;
   if (inputFile.open(QIODevice::ReadOnly)) {
        // Main header
        QString line = in.readLine();
        HeaderLine=0;
        header << line.split(" ", QString::SkipEmptyParts);
        NumberOfTraces = header[0][0].toInt();
        //qDebug() << "Number of traces" << header[0][0] <<
        //"hdr" << header[0][1] <<
        //"hdr" << header[0][2] <<
        //"hdr" << header[0][3] <<
        //"hdr" << header[0][4] <<
        //"sfile" << header[0][5];
        line = in.readLine();
        HeaderLine++;
        header << line.split(" ", QString::SkipEmptyParts);
        //qDebug() << "line format" << header[1][0];
        // end main header
        trace=0;
        while (trace<NumberOfTraces) {
            //trace header, two lines:
            line = in.readLine();
            HeaderLine++;
            header << line.split(" ", QString::SkipEmptyParts);
            line = in.readLine();
            HeaderLine++;
            header << line.split(" ", QString::SkipEmptyParts);

            NumberOfSamples = header[HeaderLine][0].toInt();
            samples[trace] = NumberOfSamples;
            SampleInterval[trace] = header[HeaderLine][1].toDouble();

            //qDebug() << "Station" << header[HeaderLine][3]<<
            //            "number of samples" << header[HeaderLine][0] <<
            //            "trace" << trace <<
            //            "NumberOfSamples" << NumberOfSamples<<
            //            "SampleInterval" << SampleInterval[trace];

            //qDebug() << "line" << line;
            //qDebug() << "Start" << line.mid(42,4)<<line.mid(47,2)<<
            //            line.mid(49,2)<<line.mid(52,2)<<line.mid(54,2)<<
            //            line.mid(58,6);
            StartTime[trace] = (line.mid(42,4).toDouble()-1970.)*365*24.0*3600.0 +
                    //line.mid(47,2).toDouble()*31*24.0*3600.0 +
                    (31+29+31+30+31+30)*24.0*3600.0+
                    line.mid(49,2).toDouble()*24.0*3600.0 +
                    line.mid(52,2).toDouble()*3600.0 +
                    line.mid(54,2).toDouble()*60.0 +
                    line.mid(58,6).toDouble();
            count=0;
            while (count < samples[trace]/7.0) {
                QString line = in.readLine();
                lists << line.split(" ", QString::SkipEmptyParts);
                ++count;
            }
            trace++;
        }
        //qDebug() << "Station" << header[HeaderLine][3];
   }
   //qDebug() << "count" << count;
   inputFile.close();

   // Generate some data:
   int i, j;
   int EndLine=-1;
   int StartLine=0;

   double maxY=-99999999.0;
   double minY=99999999.0;
   double dcY=0.0;

   QCPItemText *textLabel = new QCPItemText(ui->customPlot);
   QCPItemText *textLabelchan = new QCPItemText(ui->customPlot);

   trace=0;
   while(trace < NumberOfTraces){
      QVector<double> x0(samples[trace]), y0(samples[trace]);
      maxY=-99999999.0;
      minY=99999999.0;
      dcY=0.0;
      int k=0;
      StartLine=EndLine+1;
      EndLine=(int)(samples[trace]/7.0)+StartLine;
      //qDebug()<<"data lines:"<<(int)(samples[trace]/7.0)<<", trace:"<<trace<<", NumberOfTraces:"<<NumberOfTraces;
      //qDebug() <<StartLine<<EndLine;
      for (i = StartLine; i < EndLine; ++i ) {
        for (int j = 0; j < 7; ++j ) {
            y0[k]=lists[i][j].toDouble();
            if(y0[k] < minY) minY=y0[k];
            if(y0[k] > maxY) maxY=y0[k];
            dcY = dcY+y0[k];
            //qDebug() <<y0[k]<<k;
            k++;
        }
      }
      //qDebug() <<"samples[trace]" << samples[trace] << "k" << k;
      j=0;
      if(k==(int)(samples[trace])) EndLine--;
      while (k<(int)(samples[trace])) {
        y0[k] = lists[EndLine][j].toDouble();
        if(y0[k] < minY) minY=y0[k];
        if(y0[k] > maxY) maxY=y0[k];
        dcY = dcY+y0[k];
        j++; k++;
      }
      //qDebug() <<StartLine<<EndLine<< "samples[0]" << samples[0] << "k" << k;
      // Remove the dc and normalize.
      dcY=dcY/k;

      double normalizeY=maxY-dcY;
      if ((maxY-dcY)<(dcY-minY)) normalizeY=dcY-minY;

      QDateTime datedummy = QDateTime::currentDateTime();
      for (int i = 0; i < k; ++i ) {
        y0[i]=(y0[i]-dcY)/normalizeY-trace*2.0;
        x0[i] = i*SampleInterval[trace]+StartTime[trace];
      }
      minX=x0[0];
      maxX=x0[k-1];
      //qDebug()<<trace<<"minX"<<minX<<"maxX"<<maxX;

      // Create graph and assign data to it:
      ui->customPlot->addGraph();
      ui->customPlot->graph(trace)->setPen(QPen(Qt::red)); // line color red for second graph
      if(SampleInterval[trace]==1)
        ui->customPlot->graph(trace)->setPen(QPen(Qt::blue)); // line color red for second graph
      if(SampleInterval[trace]==0.05)
        ui->customPlot->graph(trace)->setPen(QPen(Qt::black)); // line color red for second graph
      ui->customPlot->graph(trace)->setData(x0, y0);

      // Add station code
      textLabel = new QCPItemText(ui->customPlot);
      textLabel->setFont(QFont(font().family(), 8)); // make font a bit larger
      textLabel->setPositionAlignment(Qt::AlignBottom|Qt::AlignLeft);
      textLabel->position->setCoords(minX+1.0, -2.0*trace); // place position at center/top of axis rect
      textLabel->setText(header[trace*2+3][3]);
      ui->customPlot->addItem(textLabel);

      // Give channel code
      textLabelchan = new QCPItemText(ui->customPlot);
      textLabelchan->setFont(QFont(font().family(), 8)); // make font a bit larger
      textLabelchan->setText(header[trace*2+3][5]);
      textLabelchan->position->setCoords(minX+11.0, -2.0*trace-0.3);
      trace++;
    }

    ui->customPlot->yAxis->setTicks(false);
    ui->customPlot->yAxis->setTickLabels(false);
    // time??
    ui->customPlot->xAxis->setTickLabelType(QCPAxis::ltDateTime);
    ui->customPlot->xAxis->setDateTimeFormat("hh:mm:ss\nyyyy-MM-dd");

    // Set axes ranges, so we see all data:
    ui->customPlot->xAxis->setRange(minX, maxX);
    ui->customPlot->yAxis->setRange(1, -2.0*trace+1);
    ui->customPlot->xAxis2->setVisible(true);
    ui->customPlot->xAxis2->setTickLabels(false);
    ui->customPlot->yAxis2->setVisible(true);
    ui->customPlot->yAxis2->setTickLabels(false);
    ui->customPlot->yAxis2->setTicks(false);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
}
