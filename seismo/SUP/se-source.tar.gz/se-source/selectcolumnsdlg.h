#ifndef SELECTCOLUMNSDLG_H
#define SELECTCOLUMNSDLG_H

#include <QDialog>
#include "types.h"

namespace Ui {
    class SelectColumnsDlg;
}

class SelectColumnsDlg : public QDialog
{
   Q_OBJECT

public:
   explicit SelectColumnsDlg(se_config*, QWidget *parent = 0);
   ~SelectColumnsDlg();

public slots:
   void accept();

private:
   Ui::SelectColumnsDlg *ui;
   se_config *Config;
};

#endif // SELECTCOLUMNSDLG_H
