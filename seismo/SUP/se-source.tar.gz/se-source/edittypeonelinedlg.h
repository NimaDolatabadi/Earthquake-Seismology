#ifndef EDITTYPEONELINEDLG_H
#define EDITTYPEONELINEDLG_H

#include "types.h"
#include <QDialog>

struct phase_mag {
   QString agency;
   QChar type;
   float value;
};

namespace Ui {
   class EditTypeOneLineDlg;
}

class EditTypeOneLineDlg : public QDialog
{
   Q_OBJECT

public:
   explicit EditTypeOneLineDlg(QWidget *parent = 0, hypocenter_* = 0);
   ~EditTypeOneLineDlg();

public slots:
   void accept();
   void reject();

private slots:
   void FixLocChanged(int);
   void StartLocChanged(int);
   void FixDepthChanged(int);
   void StartDepthChanged(int);

private:
   Ui::EditTypeOneLineDlg *ui;
   hypocenter_ *Hyp;
   QString String;
   QList<phase_mag> MagList;

   // Private functions.
   void GetHypocenterMags();
};

#endif // EDITTYPEONELINEDLG_H
