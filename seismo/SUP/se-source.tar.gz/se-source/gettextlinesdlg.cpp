#include <QMessageBox>
#include <QDebug>
#include <QDialog>
#include "library.h"
#include "gettextlinesdlg.h"
#include "ui_gettextlinesdlg.h"


// ************************************
// Constructor function for this class.
// ************************************
GetTextLinesDlg::GetTextLinesDlg(QWidget *parent) : QDialog(parent), ui(new Ui::GetTextLinesDlg)
{
    ui->setupUi(this);

    // Use monospaced font in editor.
    QFont font("Monospace");
    font.setStyleHint(QFont::TypeWriter);
    ui->TextEdit->setFont(font);
}




// ************************************
// Destructor function for this class.
// ************************************
GetTextLinesDlg::~GetTextLinesDlg()
{
    delete ui;
}




// *******************************************************************
// This function is used to set initial text in editor. Also the title
// for the dialog box is set. This function must be called before
// window is shown. 'MaxLine' is max allowed line length.
// *******************************************************************
void GetTextLinesDlg::InitDialog(QStringList *LineList, int MaxLine, QString Title)
{
   // Copy incoming variables to local storage.
   TextLines = *LineList;
   textlines = LineList;
   MaxLineLen = MaxLine;

   // Get application name.
   AppName = QCoreApplication::applicationName();

   // Set dialog box title.
   this->setWindowTitle(Title);

   // Copy text lines into edit box.
   EditorText = TextLines.join("\n");
   ui->TextEdit->setPlainText(EditorText);

   // Activate the TextEdit widget.
   ui->TextEdit->setFocus();
   ui->TextEdit->setTabChangesFocus(true);
}




// ***********************************
// User has pressed the 'OK' button.
// ***********************************
void GetTextLinesDlg::accept()
{
   // Copy file contents from edit box into TextLines.
   EditorText = ui->TextEdit->toPlainText();
   TextLines = EditorText.split("\n", QString::SkipEmptyParts, Qt::CaseInsensitive);

   // Remove all lines containing only spaces.
   for (int i=0;i<TextLines.size();i++) {
      if (IsQStrAllSpace(TextLines.at(i))) TextLines.removeAt(i);
   }

   // Check length of all lines against 'MaxLine' value.
   for (int i=0;i<TextLines.size();i++) {
      QString line = TextLines.at(i);
      if (line.size() > MaxLineLen) {
         Message = "The maximum allowed line length (";
         Message.append(QString::number(MaxLineLen));
         Message.append(" characters) has been exceeded.");
         QMessageBox::critical(NULL, AppName, Message);
         return;
      }
   }

   // Return lines to caller.
   *textlines = TextLines;

   // Close the dialog and return 'Accepted' signal.
   QDialog::done(QDialog::Accepted);
}




// **************************************
// User has pressed the 'Cancel' button.
// **************************************
void GetTextLinesDlg::reject()
{
   // Close the dialog and return 'Rejected' signal.
   QDialog::done(QDialog::Rejected);
}




// ***********************************************
// This function is signaled from QPlainTextEdit
// when user moves the cursor to a different line.
// ***********************************************
void GetTextLinesDlg::CursorPositionChanged()
{
    // Cursor position has changed. Update column label.
    QTextCursor cursor = ui->TextEdit->textCursor();
    QString string = "Column: ";
    string.append(QString::number(cursor.columnNumber()+1));
    ui->ColumnLabel->setText(string);
    // Warn user with beeps if he's working past maximum line length.
    if (cursor.columnNumber() > MaxLineLen) QApplication::beep();
}
