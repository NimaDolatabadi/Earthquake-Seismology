#ifndef LIBRARY_H
#define LIBRARY_H

#define PI 3.14159265358979323846
#define EARTHRADIUSKM 6371.0

#include "types.h"

// Function prototyping for all functions in 'library.cpp'.
bool IsSfileNameOk(QString);
bool IsWaveformFileNameOk(QString FileName);
bool IsOperatorIdentityOK(QString);
void CopyQstrToChar(QString, char*);
void PadString(char*, int);
void PadQString(QString*, int);
void UnPadString(char*, int);
void UnPadQString(QString *string);
void StrDelete(char*, int);
void StrRmvTrailingSpaces(char*);
void TrimSpaces(QString*);
bool IsQStrAllSpace(QString);
bool IsQStrInteger(QString, int*);
void fstrcpy(char*, char*, int);
bool CreatePath(QString);
QString BuildPath(QString, QString, QString = QString(), QString = QString());
bool CleanDir(QString);
void PathCdUp(QString*);
void CreateElvTimeStr(db_time*, QString*);
void CreateISO8601TimeStr(db_time*, QString*);
void CreateDateStr(db_time, QString*);
void CreateTimeStr(db_time, QString*);
void GetFileModTime(QString, QDateTime*);
QString GetNameFromFilePath(QString);
QString GetSfileID(char[]);
void HttpRequest(QString, QStringList*);
void ClearCommonBlocks();
void ConvertCatFileToLocalDb(QString, QString, int*, int*);
bool MergeFiles(QStringList, QString);
bool IsDataLineEmpty(char[], qint64);
bool IsFileInPath(QString);
ulong JulianDay(db_time*);
char TimeCmp(db_time*, db_time*);
double TimeDiff(db_time*, db_time*);
int ReadFileLine(QString, int, QString*);
int ReadTextFile(QString, QStringList*);
bool WriteTextFile(QString, QStringList);
double Deg2Rad(double);
double Rad2Deg(double);
double EarthDistance(double, double, double, double);
bool CreateSeisanDb(QString, QString, int, int, int, int, bool, bool);
bool LoadPredefComments(QString, QStringList*);
bool LoadPredefNetworks(QString, QStringList*);
bool ProcessCmdLine(se_config*);
bool GetReaMesMessages(QStringList*);
void CopyTextToClipboard(QString);
#endif // LIBRARY_H
