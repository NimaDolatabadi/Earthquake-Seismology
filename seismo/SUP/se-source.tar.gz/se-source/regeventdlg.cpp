#include <QDebug>
#include <QKeyEvent>
#include "regeventdlg.h"
#include "ui_regeventdlg.h"
#include "numberedtxtlistdlg.h"


// ****************************************************
// Constructor function.
// ****************************************************
RegEventDlg::RegEventDlg(RegEventData *DlgData, QWidget *parent) : QDialog(parent), ui(new Ui::RegEventDlg)
{
   // Save pointer to dialog data.
   this->DlgData = DlgData;

   // Set up the user interface.
   ui->setupUi(this);

   // Set up an event filter for the dialog. See the 'eventFilter' function.
   installEventFilter(this);

   // Initialize 'Distance indicator' widgets.
   if (QString(DlgData->Node->hypocenters.first->dist_id).simplified().toUpper() == "L") ui->RadioButtonL->setChecked(true);
   if (QString(DlgData->Node->hypocenters.first->dist_id).simplified().toUpper() == "R") ui->RadioButtonR->setChecked(true);
   if (QString(DlgData->Node->hypocenters.first->dist_id).simplified().toUpper() == "D") ui->RadioButtonD->setChecked(true);

   // Initialize 'Event indicator' widget.
   ui->EventInd->setText(QString(DlgData->Node->hypocenters.first->evnt_id).simplified());

   // Initialize 'Model indicator' widget.
   ui->ModelInd->setText(QString(DlgData->Node->hypocenters.first->modl_id).simplified());

   // Prepare the 'FileList' table.
   ui->FileList->setColumnCount(2);
   ui->FileList->setSortingEnabled(false);
   ui->FileList->setFocusPolicy(Qt::NoFocus);
   ui->FileList->verticalHeader()->setVisible(false);
   ui->FileList->setSelectionMode(QAbstractItemView::NoSelection);
   ui->FileList->horizontalHeader()->setStretchLastSection(true);
   ui->FileList->setHorizontalHeaderLabels(QString("Waveform File;Default Destination Folder").split(";"));
   ui->FileList->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

   // Initialize 'Alternative destination folder' widget.
   ui->AltDestFolder->setText(DlgData->AltDestDir);

   // Populate the 'FileList' table.
   PopulateFileTable();

   // Give input focus to the 'Event indicator' widget.
   ui->RadioButtonL->setFocus();

   // Move window to front.
   this->raise(); this->activateWindow();
}



// ****************************************************
// Destructor function.
// ****************************************************
RegEventDlg::~RegEventDlg()
{
    delete ui;
}



// ****************************************************
// This function popuplates the Waveform Files table.
// ****************************************************
void RegEventDlg::PopulateFileTable()
{
   QString Str;
   QStringList Lines;
   wavfileinfo FileInfo;

   // Get all type 6 lines in the event file.
   NodeGetWaveFiles(DlgData->Node, &Lines);

   // Remove all ARC lines from the list.
   for (int index=Lines.size()-1;index>=0;index--) {
      Str = Lines.at(index);
      if (Str.startsWith(" ARC")) Lines.removeAt(index);
   }

   // Check if there are waveform files in event file.
   if (!Lines.size()) return;

   // Add all files to the 'WaveFiles' list together with some info
   // about each file. Also add the file to the 'FileList' table view.
   ui->FileList->setRowCount(Lines.size());
   for (int i=0;i<Lines.size();i++) {
      // Add file name to 'FileInfo'.
      Str = Lines.at(i);
      FileInfo.Name = Str.mid(1, 29);

      // Add file name to 'FileList' table view.
      QTableWidgetItem *Item = new QTableWidgetItem(FileInfo.Name + " ");
      Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
      ui->FileList->setItem(i,0, Item);

      // Check if file exist in current work directory.
      if (QFile::exists(QDir::currentPath() + "/" + FileInfo.Name)) {
         // Waveform file exists. Create path to destination folder.
         Str = DlgData->SEISAN_TOP + "/WAV";
         if (IsWaveformFileNameOk(FileInfo.Name)) {
            // File has a valid name. Destination folder will be a subfolder under WAV.
            Str.append("/" + DlgData->DbName + "/" + FileInfo.Name.mid(0,4) + "/" + FileInfo.Name.mid(5,2));
         }
         FileInfo.DestPath = QDir::toNativeSeparators(Str);

         // Add destination folder to 'FileList' table view.
         QTableWidgetItem *Item = new QTableWidgetItem(" " + FileInfo.DestPath);
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->FileList->setItem(i,1, Item);

         // Add file to 'WaveFiles' list. This list is used to copy the files.
         DlgData->WaveFiles.append(FileInfo);
      } else {
         // File do exists in the current work directory. This file will not be copied.
         FileInfo.DestPath = QString();
         QTableWidgetItem *Item = new QTableWidgetItem(" Not found in work folder. File will NOT be copied.");
         Item->setFlags(Item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
         ui->FileList->setItem(i,1, Item);
      }
  }

  // Resize column widths to fit contents.
  ui->FileList->resizeColumnsToContents();
}




// **********************************
// User has pressed the 'OK' button.
// **********************************
void RegEventDlg::accept(void)
{
   bool ValueOK;
   QString Value, AltDestFolder;

   // Return the distance indicator.
   if (ui->RadioButtonL->isChecked()) DlgData->DistInd = 'L';
   if (ui->RadioButtonR->isChecked()) DlgData->DistInd = 'R';
   if (ui->RadioButtonD->isChecked()) DlgData->DistInd = 'D';

   // Get and check the event indicator.
   ValueOK = false; DlgData->EventInd = 32;
   Value = ui->EventInd->text().trimmed();
   if (!Value.size() || Value == " ") ValueOK = true;
   if (Value.size() == 1 && Value.at(0).isLetter()) ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(NULL, "Register event", "Invalid Event indicator.");
      ui->EventInd->selectAll(); ui->EventInd->setFocus();
      return;
   }
   if (Value.size()) DlgData->EventInd = Value.at(0).toLatin1();

   // Get and check the model indicator.
   ValueOK = false; DlgData->ModelInd = 32;
   Value = ui->ModelInd->text().trimmed();
   if (!Value.size() || Value == " ") ValueOK = true;
   if (Value.size() == 1 && Value.at(0).isLetter()) ValueOK = true;
   if (Value.size() == 1 && Value.at(0).isNumber()) ValueOK = true;
   if (!ValueOK) {
      QMessageBox::critical(this, "Register event", "Invalid Model indicator.");
      ui->ModelInd->selectAll(); ui->ModelInd->setFocus();
      return;
   }
   if (Value.size()) DlgData->ModelInd = Value.at(0).toLatin1();

   // Get and check the alternative directory.
   AltDestFolder = ui->AltDestFolder->text().trimmed();
   if (AltDestFolder.size()) {
      QDir Path = QDir(AltDestFolder);
      // Check if folder exist.
      if (!Path.exists()) {
         // Folder does not exist. Ask user if folder should be created.
         QString Message = "The alternative destination folder do not exist. Do you want to create it?";
         if ((QMessageBox::question(0, "Register event", Message, QMB_YES|QMB_NO, QMB_YES) == QMB_YES)) {
            if (!Path.mkpath(AltDestFolder)) {
               Message = "Unable to create alternative destination folder. Please check the given path.";
               QMessageBox::critical(this, "Register event", Message);
               ui->AltDestFolder->setFocus();
               return;
            }
         } else {
            return;
         }
      }
      // Destination folder already exists, or have been
      // created. Return alternative destination folder.
      DlgData->AltDestDir = AltDestFolder;
   }

   // Check if event indicator is V (Volcano). If so, bring up a
   // list and let user select the volcano subclass. The selected
   // class will be written to the S-file as type 3 line.
   if (DlgData->EventInd == 'V') {
      // Open a new dialog box and let user choose
      // from the list of pre-defined volcano classes.
      bool Checked;
      QString SubClass, SubClassVal;
      QStringList SubClasses = {"Volcano-tectonic", "Hybrid", "Long-period", "Volcanic tremor", "Rockfall", "Unknown"} ;
      QStringList SubClassesVal = {"vt", "hybrid", "lp", "tremor", "rf", "un"} ;
      NumberedTxtListDlg *Dialog = new NumberedTxtListDlg();
      Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
      Dialog->Init("Please select a volcanic subclass", SubClasses, SubClassesVal, QString(), &SubClass, &SubClassVal, &Checked);
      if (Dialog->exec() == QDialog::Rejected) return;
      DlgData->VolcSubClass = SubClass;
      DlgData->VolcSubClassVal = SubClassVal;
   }

   // Close the dialog and return 'Accepted' signal.
   QDialog::accept();
}




// **********************************************************
// This is the event filter for the dialog.
// **********************************************************
bool RegEventDlg::eventFilter(QObject* object, QEvent* event)
{
   Q_UNUSED(object)

   if (event->type()==QEvent::KeyPress) {
      // Transform QEvent into QKeyEvent.
      QKeyEvent* pKeyEvent=static_cast<QKeyEvent*>(event);

      // Handle pressed key.
      switch(pKeyEvent->key()) {
         case Qt::Key_A: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("A"); return true; } return false;
         case Qt::Key_B: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("B"); return true; } return false;
         case Qt::Key_C: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("C"); return true; } return false;
         case Qt::Key_D: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->RadioButtonD->setChecked(true); return true; } return false;
         case Qt::Key_E: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("E"); return true; } return false;
         case Qt::Key_F: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("F"); return true; } return false;
         case Qt::Key_G: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("G"); return true; } return false;
         case Qt::Key_H: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("H"); return true; } return false;
         case Qt::Key_I: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("I"); return true; } return false;
         case Qt::Key_J: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("J"); return true; } return false;
         case Qt::Key_K: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("K"); return true; } return false;
         case Qt::Key_L: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->RadioButtonL->setChecked(true); return true; } return false;
         case Qt::Key_M: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("M"); return true; } return false;
         case Qt::Key_N: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("N"); return true; } return false;
         case Qt::Key_O: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("O"); return true; } return false;
         case Qt::Key_P: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("P"); return true; } return false;
         case Qt::Key_Q: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("Q"); return true; } return false;
         case Qt::Key_R: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->RadioButtonR->setChecked(true); return true; } return false;
         case Qt::Key_S: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("S"); return true; } return false;
         case Qt::Key_T: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("T"); return true; } return false;
         case Qt::Key_U: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("U"); return true; } return false;
         case Qt::Key_V: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("V"); return true; } return false;
         case Qt::Key_W: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("W"); return true; } return false;
         case Qt::Key_X: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("X"); return true; } return false;
         case Qt::Key_Y: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("Y"); return true; } return false;
         case Qt::Key_Z: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->setText("Z"); return true; } return false;
         case Qt::Key_Delete: if (pKeyEvent->modifiers() == Qt::NoModifier) { ui->EventInd->clear(); return true; } return false;
      }
   }
   return false;
}
