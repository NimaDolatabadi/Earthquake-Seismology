#ifndef MERGEDLG_H
#define MERGEDLG_H

#include <QDialog>

namespace Ui {
   class MergeDlg;
}

class MergeDlg : public QDialog
{
   Q_OBJECT

public:
   explicit MergeDlg(QString, QWidget *parent = 0);
   ~MergeDlg();

public slots:
   void MergeButton();
   void MergeDelButton();
   void CancelButton();

private:
   Ui::MergeDlg *ui;
};

#endif // MERGEDLG_H
