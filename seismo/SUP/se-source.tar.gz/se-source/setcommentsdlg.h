#ifndef SETCOMMENTSDLG_H
#define SETCOMMENTSDLG_H

#include <QDialog>

namespace Ui { class SetCommentsDlg; }

class SetCommentsDlg : public QDialog
{
   Q_OBJECT

public:
   explicit SetCommentsDlg(QWidget *parent, QStringList *Comments, QStringList PredefComments);
   ~SetCommentsDlg();

public slots:
   void accept();                   // 'Save' button is pressed.
   void reject();                   // 'Cancel' button is pressed.
   void AddPreDefinedComment();     // 'Pre-defined comments' button is pressed.
   void CursorPositionChanged();    // User has moved the cursor in the editor.

private slots:
   bool eventFilter(QObject*, QEvent*);

private:
   Ui::SetCommentsDlg *ui;
   QStringList *Comments, PredefComments, TextLines;
   QString Message, AppName, EditorText;
};

#endif // SETCOMMENTSDLG_H
