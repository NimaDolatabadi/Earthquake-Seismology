#include <QDir>
#include <QDate>
#include <QFileDialog>
#include <QMessageBox>
#include "library.h"
#include "createdatabasedlg.h"
#include "ui_createdatabasedlg.h"

CreateDatabaseDlg::CreateDatabaseDlg(QWidget *parent, QString DbFolder) :
                   QDialog(parent), ui(new Ui::CreateDatabaseDlg)
{
   ui->setupUi(this);

   // Save the database folder.
   DbDir = DbFolder;

   // Get application name.
   AppName = QCoreApplication::applicationName();

   // Initialize widgets.
   QDate CurDate = QDate::currentDate();
   QString Date = QString::number(CurDate.year());
   Date.append(QString("%1").arg(CurDate.month(), 2, 10, QChar('0')));
   ui->StartTime->setText(Date);
   CurDate = CurDate.addYears(3);
   Date = QString::number(CurDate.year()); Date.append("12");
   ui->EndTime->setText(Date);
   ui->CreateREA->setChecked(true); ui->CreateWAV->setChecked(true);
   ui->ParentFolder->setText(DbFolder);
   ui->DatabaseName->setFocus();
}


CreateDatabaseDlg::~CreateDatabaseDlg()
{
   delete ui;
}




// ********************************************
// User has pressed the 'Select folder' button.
// Open a dialog and let user select a folder.
// ********************************************
void CreateDatabaseDlg::SelectFolder()
{
   Message = "Please select a parent folder for the database:";
   QString Folder = QFileDialog::getExistingDirectory(this, Message, DbDir, QFileDialog::ShowDirsOnly);
   if (Folder.size()) ui->ParentFolder->setText(QDir::toNativeSeparators(Folder));
}




// ********************************************
// Handle the OK button.
// ********************************************
void CreateDatabaseDlg::accept(void)
{
   // Get and check database name.
   DbName = ui->DatabaseName->text();
   if (!DbName.size()) {
      Message = "Please enter a database name." ;
      QMessageBox::critical(NULL, AppName, Message);
      ui->DatabaseName->setFocus();
      return;
   } else {
      // Make database name uppercase.
      DbName = DbName.toUpper();
       // Make sure database name is 5 characters long.
      if (DbName.size() < 5) for (int i=DbName.size();i<5;i++) DbName.append("_");
   }

   // Get and check database top folder. This is the
   // folder that should have the REA/WAV subfolders.
   DbTopDir = ui->ParentFolder->text();
   if (!QFile::exists(DbTopDir)) {
      Message = "Unable to find database top folder." ;
      QMessageBox::critical(NULL, AppName, Message);
      ui->ParentFolder->setFocus();
      return;
   }

   // Get and check start/end times.
   StartTime = ui->StartTime->text();
   EndTime = ui->EndTime->text();
   if (StartTime.size() != 6) {
      Message = "Please enter a valid start time." ;
      QMessageBox::critical(NULL, AppName, Message);
      ui->StartTime->setFocus();
      return;
   }
   if (EndTime.size() != 6) {
      Message = "Please enter a valid end time." ;
      QMessageBox::critical(NULL, AppName, Message);
      ui->EndTime->setFocus();
      return;
   }
   StartYear = StartTime.left(4).toInt();
   StartMonth = StartTime.right(2).toInt();
   EndYear = EndTime.left(4).toInt();
   EndMonth = EndTime.right(2).toInt();
   if (StartMonth < 1 || StartMonth > 12) {
       Message = "Please enter a valid start time." ;
       QMessageBox::critical(NULL, AppName, Message);
       ui->StartTime->setFocus();
       return;
   }
   if (EndMonth < 1 || EndMonth > 12) {
       Message = "Please enter a valid end time." ;
       QMessageBox::critical(NULL, AppName, Message);
       ui->EndTime->setFocus();
       return;
   }

   // Get and check selection of database creation under REA/WAV subfolders.
   CreateREA = ui->CreateREA->isChecked();
   CreateWAV = ui->CreateWAV->isChecked();
   if (!CreateREA && !CreateWAV) {
      Message = "You must create database under REA folder, or WAV folder, or both.";
      QMessageBox::critical(NULL, AppName, Message);
      ui->CreateREA->setFocus();
      return;
   }
   // Check that database top folder contains REA/WAV subfolders.
   if (CreateREA && !QFile::exists(DbTopDir + "/REA")) {
      Message = "Unable to locate 'REA' folder in '" + DbTopDir + "'." ;
      QMessageBox::critical(NULL, AppName, Message);
      ui->ParentFolder->setFocus();
      return;
   }
   if (CreateWAV && !QFile::exists(DbTopDir + "/WAV")) {
      Message = "Unable to locate 'WAV' folder in '" + DbTopDir + "'." ;
      QMessageBox::critical(NULL, AppName, Message);
      ui->ParentFolder->setFocus();
      return;
   }

   // Create the Seisan database.
   bool Status = CreateSeisanDb(DbName, DbTopDir, StartYear, StartMonth,
                 EndYear, EndMonth, CreateREA, CreateWAV);

   // Inform user about the outcome.
   if (Status) {
      Message = "Database '" + DbName + "' has been created.";
      QMessageBox::information(NULL, AppName, Message);
   } else {
      Message = "Database creation failed. Unable to create folders.";
      QMessageBox::critical(NULL, AppName, Message);
   }

   // Close the dialog.
   QDialog::accept();
}


