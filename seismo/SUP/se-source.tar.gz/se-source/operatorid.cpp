#include "operatorid.h"
#include "library.h"

OperatorId::OperatorId(QObject *parent) : QObject(parent)
{
    Confirmed = false;
    Identity.clear();
}


//
// Sets the current unconfirmed operator identity.
//
void OperatorId::SetUnconfirmedId(QString Id)
{
    // Save operator identity if it is OK.
    if (IsOperatorIdentityOK(Id)) Identity = Id;

    // Update status bar text.
    emit SetStatusBarOperator();
}



//
// Returns the current operator identity to the caller.
//
QString OperatorId::GetCurrentId()
{
    return Identity;
}



//
// Returns a user-confirmed operator identity to the caller.
//
QString OperatorId::GetConfirmedId()
{
    // Return confirmed operator identity if it exists.
    if (Confirmed) return Identity;

    // If not, then prompt for and return operator identity.
    Dialog = new OperatorDlg();
    Dialog->InitDialog(&Identity);
    Dialog->exec();
    delete Dialog;

    // Operator identity is now confirmed.
    Confirmed = true;

    // Update status bar text.
    emit SetStatusBarOperator();

    // Write message to logview.
    Message = "Operator was set to '";
    Message.append(Identity); Message.append("'.");
    emit WriteLog(logmodel::info, Message);

    // Return operator confirmed identity.
    return Identity;
}



//
// Returns 'true' if ID has been set.
//
bool OperatorId::IsSet()
{
    if (Identity.size()) return true;

    return false;
}
