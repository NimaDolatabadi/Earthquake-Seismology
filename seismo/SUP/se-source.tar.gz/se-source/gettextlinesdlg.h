#ifndef GETTEXTLINESDLG_H
#define GETTEXTLINESDLG_H

#include <QDialog>

namespace Ui {
   class GetTextLinesDlg;
}

class GetTextLinesDlg : public QDialog
{
   Q_OBJECT

public:
   explicit GetTextLinesDlg(QWidget *parent = 0);
   ~GetTextLinesDlg();
   void InitDialog(QStringList*, int, QString);

public slots:
   void accept();
   void reject();
   void CursorPositionChanged();

private:
   Ui::GetTextLinesDlg *ui;
   int MaxLineLen;
   QStringList *textlines, TextLines;
   QString Message, AppName, EditorText;
};

#endif // GETTEXTLINESDLG_H
