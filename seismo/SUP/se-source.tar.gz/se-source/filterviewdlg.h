#ifndef FILTERVIEWDLG_H
#define FILTERVIEWDLG_H

#include <QDialog>
#include <QString>
#include "types.h"

namespace Ui {
class FilterViewDlg;
}

class FilterViewDlg : public QDialog
{
   Q_OBJECT

public:
   explicit FilterViewDlg(QWidget *parent = 0);
   ~FilterViewDlg();
   void InitDialog(db_filter*);

public slots:
   void EditInclQuery();
   void EditExclQuery();
   void accept();
   void reject();
   void clear();
   void load();
   void save();

private:
   Ui::FilterViewDlg *ui;
   db_filter *filter;
   QString descr;
   QString iQuery, eQuery;
   QString AppName, Message;
};

#endif // FILTERVIEWDLG_H
