﻿#include <QString>
#include <QFontDialog>
#include <QApplication>
#include "configuredlg.h"
#include "selectworkdirdlg.h"
#include "ui_configuredlg.h"


// ************************
// Constructor function.
// ************************
ConfigureDlg::ConfigureDlg(se_config *Config, QWidget *parent) : QDialog(parent), ui(new Ui::ConfigureDlg)
{
    // Save a pointer to configuration structure,
    // and the contents of the config structure.
    this->Config = Config;

    // Set up the user interface.
    ui->setupUi(this);

    // Initialize all widgets in the dialog box.
    ui->spinBox1->setValue(Config->TimeInterval);
    ui->UsePrevTimeInterval->setChecked(Config->UsePrevTimeInterval);
    ui->OpenLast->setChecked(Config->AutoLoad);
}




// ************************
// Destructor function.
// ************************
ConfigureDlg::~ConfigureDlg()
{
    delete ui;
}




// **********************************
// User has pressed the 'OK' button.
// **********************************
void ConfigureDlg::accept(void)
{
   // Get values from the dialog box.
   Config->TimeInterval = ui->spinBox1->value();
   Config->UsePrevTimeInterval = ui->UsePrevTimeInterval->isChecked();
   Config->AutoLoad = ui->OpenLast->isChecked();

   // Close the dialog and return 'Accepted' signal.
   QDialog::accept();
}
