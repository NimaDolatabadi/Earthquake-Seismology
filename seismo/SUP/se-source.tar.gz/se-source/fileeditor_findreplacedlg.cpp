#include <QMessageBox>
#include "fileeditor_findreplacedlg.h"
#include "ui_fileeditor_findreplacedlg.h"

fileeditor_findreplacedlg::fileeditor_findreplacedlg(QWidget *parent, frdata *data) :
                            QDialog(parent), ui(new Ui::fileeditor_findreplacedlg)
{
    ui->setupUi(this);

    // Save incoming parameters.
    pdata = data;
    dlgdata = *data;

    // Initialize the dialog box.
    ui->SearchLine->setText(data->SearchText);
    ui->ReplaceLine->setText(data->ReplaceText);
    ui->CaseSensitiveSearch->setChecked(data->CaseSensitive);
}

fileeditor_findreplacedlg::~fileeditor_findreplacedlg()
{
    delete ui;
}




void fileeditor_findreplacedlg::accept()
{
   // Get info from dialog box.
   dlgdata.SearchText = ui->SearchLine->text();
   dlgdata.ReplaceText = ui->ReplaceLine->text();
   dlgdata.CaseSensitive = ui->CaseSensitiveSearch->isChecked();

   // Check that a search string has been entered.
   if (!dlgdata.SearchText.size()) {
      QMessageBox::critical(NULL, "Find and Replace", "Please enter a search string.");
      return;
   }

   // Return data.
   *pdata = dlgdata;

   // Close dialog.
   QDialog::accept();
}




void fileeditor_findreplacedlg::reject()
{
   QDialog::reject();
}
