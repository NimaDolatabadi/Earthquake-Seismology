#ifndef OPERATORID_H
#define OPERATORID_H

#include <QString>
#include "logmodel.h"
#include "operatordlg.h"

class OperatorId : public QObject
{
   Q_OBJECT

public:
   explicit OperatorId(QObject *parent = 0);
   void SetUnconfirmedId(QString); // Sets unconfirmed operator identity.
   QString GetCurrentId();         // Returns current ID, confirmed or not.
   QString GetConfirmedId(void);   // Returns a confimed operator identity.
                                   // We will ask user for ID if needed.
   bool IsSet();                   // Returns 'true' if ID has been set.

signals:
   void SetStatusBarOperator();
   void WriteLog(logmodel::msg_type, QString);

private:
   OperatorDlg *Dialog;            // Pointer to dialog object.
   QString Identity;               // Current operator identity.
   QString Message;
   bool Confirmed;                 // True if current operator identity is confirmed.
};

#endif // OPERATORID_H
