#ifndef SETCWD_H
#define SETCWD_H

#include <QObject>
#include "types.h"
#include "logmodel.h"

class SetCWD : public QObject
{
   Q_OBJECT

signals:
   // Signals for the log view.
   void WriteLog(logmodel::msg_type, QString);

public:
   SetCWD();
   int Set(se_config*);
   int SetEx(se_config*);
   int SetByPath(QString);
   int TryByPath(QString);
   QString Get(se_config*);
   void DeleteLockFile();
   void DeleteOldLockFile(se_config*);

private:
   QString Message;
   QString WorkDir;
   QString LockFile;
   bool LockFileCreated;
   int TryConfigDir(se_config*);
   void CreateLockFile();
};

#endif // SETCWD_H
