#include "addarclinedlg.h"
#include "ui_addarclinedlg.h"

// *****************************************
// Contructor function the class/dialog box.
// *****************************************
AddArcLineDlg::AddArcLineDlg(db *DB, int Index, QStringList Networks, QWidget *parent) : QDialog(parent), ui(new Ui::AddArcLineDlg)
{
   // Set up the user interface.
   ui->setupUi(this);

   // Save pointer to database and event index.
   this->DB = DB;
   this->Index = Index;

   // Get pointer to the node.
   Node = DB->EventByIndex(Index);

   // Initialize the Network combo box.
   if (Networks.size()) {
      // Insert all networks into the combo box list.
      // A line number will be added to the front of each line.
      for (int index=0; index<Networks.size(); index++) {
         QString Line = Networks.at(index);
         Line.insert(0, " - ");
         Line.insert(0, QString::number(index+1));
         ui->NetworkBox->insertItem(index, Line);
      }
   }

   // Get date and time from first hypocenter.
   NodeGetPriHypocenterDateTime(Node, &Date, &Time);

   // Initialize the Start Date and Start Time.
   ui->StartDateEdit->insert(Date);
   ui->StartTimeEdit->insert(Time);

   // Initialize the Data length.
   ui->DataLengthEdit->insert("300");
}


// *****************************************
// Destructor function the class/dialog box.
// *****************************************
AddArcLineDlg::~AddArcLineDlg()
{
    delete ui;
}




// ******************************************
// User has pressed OK.
// ******************************************
void AddArcLineDlg::accept()
{
   char Status;
   QDate StartDate;
   QTime StartTime;
   QString Network, Length, Line;

   // Get the network name.
   Network = ui->NetworkBox->currentText();
   Network = Network.remove(0,  Network.indexOf(" - ") + 3);

   // Get and check the start date.
   StartDate = QDate::fromString(ui->StartDateEdit->text(), "yyyyMMdd");
   if (!StartDate.isValid()) {
      StartDate = QDate::fromString(ui->StartDateEdit->text(), "yyyy.MM.dd");
      if (!StartDate.isValid()) {
         QMessageBox::critical(NULL, "Add ARC line.", "An invalid start date has been entered.");
         ui->StartDateEdit->selectAll();
         ui->StartDateEdit->setFocus(Qt::OtherFocusReason);
         return;
      }
   }

   // Get and check the start time.
   StartTime = QTime::fromString(ui->StartTimeEdit->text(), "hhmmss");
   if (!StartTime.isValid()) {
      StartTime = QTime::fromString(ui->StartTimeEdit->text(), "hh:mm:ss");
      if (!StartTime.isValid()) {
         QMessageBox::critical(NULL, "Add ARC line.", "An invalid start time has been entered.");
         ui->StartTimeEdit->selectAll();
         ui->StartTimeEdit->setFocus(Qt::OtherFocusReason);
         return;
      }
   }

   // Get data length from dialog.
   Length = ui->DataLengthEdit->text();
   if (Length.toInt() < 1) {
      QMessageBox::critical(NULL, "Add ARC line.", "An invalid data length has been entered.");
      ui->StartDateEdit->selectAll();
      ui->StartDateEdit->setFocus(Qt::OtherFocusReason);
      return;
   }

   // Create an ARC line (type 6 line).
   Date = ui->StartDateEdit->text().trimmed();
   Time = ui->StartTimeEdit->text().trimmed();
   Line = "ARC"; Line.insert(4, Network);
   Line.insert(20, Date); Line.insert(24, " ");
   Line.insert(30, Time); Line.insert(34, " ");
   Length = Length.rightJustified(5, ' ');
   Line.insert(38, Length);

   // Add line to node.
   AddTextLine(&Node->wavefiles, Line, QChar('6'));

   // Update the S-file.
   if (!DB->UpdateSfile(Index, &Status)) {
      // Handle error.
      QString Message = "Failed to update event file. Check file/directory permissions.";
      QMessageBox::critical(0, "Add ARC line.", Message);
   }

   // Close the dialog and return 'accepted' signal.
   QDialog::accept();
}




// ******************************************
// User has pressed Cancel.
// ******************************************
void AddArcLineDlg::reject()
{
    // Close the dialog and return 'rejected' signal.
    QDialog::reject();
}
