#include <QApplication>
#include <QEvent>
#include <QKeyEvent>
#include "eventlistviewfilter.h"


// ********************************************************************
// Constructor function for the class.
// ********************************************************************
eventlistviewfilter::eventlistviewfilter(QObject *parent) : QObject(parent)
{

}




// ********************************************************************
// Event filter for the Event List View. Handles keyboard inputs.
// ********************************************************************
bool eventlistviewfilter::eventFilter(QObject* object, QEvent* event)
{
   Q_UNUSED(object)

   if (event->type()==QEvent::KeyPress) {
      // Transform QEvent into QKeyEvent.
      QKeyEvent* pKeyEvent=static_cast<QKeyEvent*>(event);

      // Handle pressed key.
      switch(pKeyEvent->key()) {
         case Qt::Key_F3:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Load_Event();
         return true;

         case Qt::Key_F4:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Unload_Event();
         return true;

         case Qt::Key_F5:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Refresh_View();
         return true;

         case Qt::Key_Delete:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Delete_Events();
         return true;

         case Qt::Key_0:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_GoToRowNr();
         return true;

         case Qt::Key_1:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ActivateSpeedSearch('1');
         return true;

         case Qt::Key_2:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ActivateSpeedSearch('2');
         return true;

         case Qt::Key_A:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Add_ARC_Line_To_Sfile();
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ELV_Associate_Events();
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit ELV_Select_All();
         return true;

         case Qt::Key_C:
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ELV_Copy_Events();
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Edit_Comment_Lines();
         return true;

         case Qt::Key_D:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Delete_Events();
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ELV_Duplicate_Event();
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit ELV_Set_Distance_Indicator();
         return true;

         case Qt::Key_E:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Edit_With_Text_Editor();
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit ELV_Set_Event_Indicator();
         return true;

         case Qt::Key_F:
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit ELV_Set_Filter();
         return true;

         case Qt::Key_G:
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ELV_Show_Events_With_GE();
         return true;

         case Qt::Key_H:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Add_Type1_Line_To_Sfile();
         return true;

         case Qt::Key_L:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Locate_Event();
         return true;

         case Qt::Key_M:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Merge_Events();
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit ELV_Set_Model_Indicator();
         return true;

         case Qt::Key_N:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ScrollToNextSelection();
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ScrollToPrevSelection();
         return true;

         case Qt::Key_P:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Plot_With_Mulplot();
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ELV_Plot_With_Mulplot_Menu();
         return true;

         case Qt::Key_R:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Register_Event();
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit ELV_Reload_Event();
         return true;

         case Qt::Key_S:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_GoToNextNewEvent();
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ELV_Edit_StationHyp();
         return true;

         case Qt::Key_T:
         if (pKeyEvent->modifiers() == Qt::NoModifier) {
            if (QApplication::keyboardModifiers() && Qt::ControlModifier) emit ELV_Set_Time_Interval();
         }
         return true;

         case Qt::Key_V:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Show_Events_With_SV();
         return true;

         case Qt::Key_X:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ScrollToNextMarkedEvent();
         if (pKeyEvent->modifiers() == Qt::ShiftModifier) emit ScrollToPrevMarkedEvent();
         if (pKeyEvent->modifiers() == Qt::ControlModifier) emit MarkUnmarkSelectedRows();
         if (pKeyEvent->modifiers() == Qt::AltModifier) emit UnmarkAllRows();
         return true;

         case Qt::Key_Less:
         if (pKeyEvent->modifiers() == Qt::NoModifier) emit ELV_Launch_EEV();
         return true;
      }

      if (event->type()==QEvent::MouseButtonDblClick) {
         emit ELV_Edit_With_Text_Editor();
      }
   }

   return false;
}
