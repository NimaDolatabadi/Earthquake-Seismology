#include <QFile>
#include <QDebug>
#include "debug.h"



void PhasesToConsole(event_node_ *Node, QString Label)
{
   QString Line;
   phase_ *Phase;

   qDebug() << Label;
   qDebug() << "Number of phases: " << Node->phases.nphase;
   Phase = Node->phases.first;
   while (Phase) {
      Line = QString(Phase->agency) + " ";
      Line.append(QString(Phase->phase) + " ");
      qDebug() << Line;
      Phase = Phase->next;
   }
}


void QStringToDebugFile(QString String, bool Truncate)
{
   QFile DebugFile; bool Status;
   DebugFile.setFileName(QString("debug.txt"));
   if ( Truncate) Status = DebugFile.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text);
   if (!Truncate) Status = DebugFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
   if (Status) {
      DebugFile.write(String.toLocal8Bit());
      DebugFile.close();
   }
}
