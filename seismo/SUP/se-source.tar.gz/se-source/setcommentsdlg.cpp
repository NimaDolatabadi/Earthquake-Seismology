#include <QStyle>
#include <QDebug>
#include <QDialog>
#include <QMessageBox>
#include "library.h"
#include "setcommentsdlg.h"
#include "numberedtxtlistdlg.h"
#include "ui_setcommentsdlg.h"


// ************************************
// Constructor function for this class.
// ************************************
SetCommentsDlg::SetCommentsDlg(QWidget *parent, QStringList *Comments, QStringList PredefComments) : QDialog(parent), ui(new Ui::SetCommentsDlg)
{
    // Set up the user interface.
    ui->setupUi(this);

    // Copy incoming variables to local storage.
    TextLines = *Comments;
    this->Comments = Comments;
    this->PredefComments = PredefComments;

    // Get application name.
    AppName = QCoreApplication::applicationName();

    // Set dialog box title.
    this->setWindowTitle("Edit comments");

    // Set up an event filter for the dialog. See the 'eventFilter' function.
    installEventFilter(this);

    // Use monospaced font in editor.
    QFont font("Monospace");
    font.setStyleHint(QFont::TypeWriter);
    ui->TextEdit->setFont(font);

    // Set a defualt minimun width of the dialog box so that 80 characters will fit.
    // This code is only effective if no previous geometry has been saved.
    int TextEditWidth = ui->TextEdit->fontMetrics().width(QChar('H'))*85;
    int ScrollBarWidth = qApp->style()->pixelMetric(QStyle::PM_ScrollBarExtent);
    setMinimumWidth(TextEditWidth + ScrollBarWidth + 20);

    // Copy text lines into edit box.
    EditorText = TextLines.join("\n");
    ui->TextEdit->setPlainText(EditorText);

    // Activate the TextEdit widget.
    ui->TextEdit->setFocus();
    ui->TextEdit->setTabChangesFocus(true);
}




// ************************************
// Destructor function for this class.
// ************************************
SetCommentsDlg::~SetCommentsDlg()
{
    delete ui;
}



// *****************************************************
// User has pressed the 'Add pre-deined comment' button.
// *****************************************************
void SetCommentsDlg::AddPreDefinedComment()
{
    // Check if any pre-defined comments have been loaded.
    if (!PredefComments.size()) {
        Message = "No pre-defined comments where found in SEISAN.DEF when SE was started.";
        QMessageBox::information(0, "Add pre-defined comment.", Message);
        return;
    }

    // Open a new dialog box and let user choose from the list of pre-defined
    // comments. These cmments are defined in file SEISAN_TOP\DAT\SEIASN.DEF.
    QString Comment; bool Checked;
    NumberedTxtListDlg *Dialog = new NumberedTxtListDlg();
    Dialog->setAttribute(Qt::WA_DeleteOnClose, true);
    Dialog->Init("Select a pre-defined comment.", PredefComments, QString(), &Comment, &Checked);
    if (Dialog->exec() == QDialog::Accepted) ui->TextEdit->appendPlainText(Comment);

    // Set keyboard focus to the 'Save' button.
    ui->SaveButton->setFocus();
}




// ***************************************************
// This function is signaled from QPlainTextEdit
// when the cursor moves to a different position.
// ***************************************************
void SetCommentsDlg::CursorPositionChanged()
{
    // Cursor position has changed. Update column label.
    QTextCursor cursor = ui->TextEdit->textCursor();
    QString string = "Column: ";
    string.append(QString::number(cursor.columnNumber()+1));
    ui->ColumnLabel->setText(string);
    // Warn user with beeps if he's working past maximum line length.
    if (cursor.columnNumber() > 80) QApplication::beep();
}




// ************************************
// User has pressed the 'Save' button.
// ************************************
void SetCommentsDlg::accept()
{
   // Copy file contents from edit box into TextLines.
   EditorText = ui->TextEdit->toPlainText();
   TextLines = EditorText.split("\n", QString::SkipEmptyParts, Qt::CaseInsensitive);

   // Remove all lines containing only spaces.
   for (int i=0;i<TextLines.size();i++) {
      if (IsQStrAllSpace(TextLines.at(i))) TextLines.removeAt(i);
   }

   // Check the length of all comment lines.
   for (int i=0;i<TextLines.size();i++) {
      QString line = TextLines.at(i);
      if (line.size() > 80) {
         Message = "The maximum allowed line length (80 characters) has been exceeded.";
         QMessageBox::critical(NULL, AppName, Message);
         return;
      }
   }

   // Return lines to caller.
   *Comments = TextLines;

   // Close the dialog and return 'Accepted' signal.
   QDialog::done(QDialog::Accepted);
}




// **************************************
// User has pressed the 'Cancel' button.
// **************************************
void SetCommentsDlg::reject()
{
   // Close the dialog and return 'Rejected' signal.
   QDialog::done(QDialog::Rejected);
}




// ********************************************************
// This is the event filter for the dialog.
// ********************************************************
bool SetCommentsDlg::eventFilter(QObject* object, QEvent* event)
{
   Q_UNUSED(object)

   if (event->type()==QEvent::KeyPress) {
      // Transform QEvent into QKeyEvent.
      QKeyEvent* pKeyEvent=static_cast<QKeyEvent*>(event);

      // Handle pressed key.
      switch(pKeyEvent->key()) {
         case Qt::Key_P:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { AddPreDefinedComment(); return true; }
            return false;

         case Qt::Key_S:
            if (pKeyEvent->modifiers() == Qt::ControlModifier) { accept(); return true; }
            return false;
      }
   }
   return false;
}
