#include <QDir>
#include <QDebug>
#include <QFileInfo>
#include <QDateTime>
#include "seisandb.h"
#include "fortran.h"
#include "library.h"
#include <QMessageBox>


// ***********************************************************
// Returns information about an event file
// in a 'sfile_nameinfo' structure.
// ***********************************************************
void GetSfileNameInfo(QString EventFile, sfile_nameinfo *Info)
{
    QFileInfo FileInfo;

    // Use the QFileInfo class.
    FileInfo.setFile(EventFile);

    // Get the file name without the path.
    Info->Name = FileInfo.fileName();

    // Get the path without the file name.
    Info->Path = FileInfo.path();
    Info->Path = QDir::toNativeSeparators(Info->Path);

    // Get year and month from the file name.
    Info->Year = Info->Name.mid(13, 4);
    Info->Month = Info->Name.mid(17, 2);

    // Get the date from the file name.
    int year = Info->Year.toInt();
    int month = Info->Month.toInt();
    int day = Info->Name.mid(0, 2).toInt();
    Info->Date.setDate(year, month, day);

    // Get the time from the file name.
    int hour = Info->Name.mid(3, 2).toInt();
    int minute = Info->Name.mid(5, 2).toInt();
    int second = Info->Name.mid(8, 2).toInt();
    Info->Time.setHMS(hour, minute, second, 0);

    // Get the distance ID from the file name.
    Info->DistId = Info->Name.at(10);

    // Create a QDateTime structure.
    Info->DateTime.setDate(Info->Date);
    Info->DateTime.setTime(Info->Time);

    // Get the date and time in the file name as text.
    Info->DateStr.append(Info->Date.toString("yyyyMMdd"));
    Info->TimeStr.append(Info->Time.toString("hhmmss"));

    // Get type of database (NORMAL or LOCAL). A database of
    // type NORMAL has a ../DBNAM/YYYY/MM directory structure.
    Info->DatabaseType = "LOCAL";
    int Size = Info->Path.size();
    if (Info->Path.at(Size-1).isDigit() &&
        Info->Path.at(Size-2).isDigit() &&
        Info->Path.at(Size-4).isDigit() &&
        Info->Path.at(Size-5).isDigit() &&
        Info->Path.at(Size-6).isDigit() &&
        Info->Path.at(Size-7).isDigit()) Info->DatabaseType = "NORMAL";

    // Get the database name.
    if (Info->DatabaseType == "NORMAL") Info->Database = Info->Path.mid(Info->Path.size()-13, 5);

}




// ********************************************************
// Adds one second to the name of an S-file. 'Name' must
// be given with full path. Returns the new file path.
// ********************************************************
void AddOneSecToSfileName(QString *File)
{
    sfile_nameinfo Info;

    // Get total length of path/filename.
    int psize = File->size();

    // Get the time/date from the old file name.
    GetSfileNameInfo(*File, &Info);

    // Create the new file name.
    QDateTime NewTime = Info.DateTime; NewTime = NewTime.addSecs(1);
    File->replace(psize-6, 4, QString("%1").arg(NewTime.date().year(), 4, 10, QChar('0')));
    File->replace(psize-2, 2, QString("%1").arg(NewTime.date().month(), 2, 10, QChar('0')));
    File->replace(psize-19, 2, QString("%1").arg(NewTime.date().day(), 2, 10, QChar('0')));
    File->replace(psize-16, 2, QString("%1").arg(NewTime.time().hour(), 2, 10, QChar('0')));
    File->replace(psize-14, 2, QString("%1").arg(NewTime.time().minute(), 2, 10, QChar('0')));
    File->replace(psize-11, 2, QString("%1").arg(NewTime.time().second(), 2, 10, QChar('0')));
}




// ****************************************************
// Delete an S-file from the seisan database. Returns
// errorcode if something went wrong. Error codes are:
// 1 - Event file was not found.
// 2 - Unable to delete event file.
// 3 - Destination folder in DELET base do not exist.
// 4 - Unable to copy event file to DELET base.
// ****************************************************
int DeleteSfileFromDisk(QString EventFile, db_info DbInfo)
{
    QFile Sfile;
    sfile_nameinfo NameInfo;
    QString DeletPath, DeletFile;

   // Index file database is not supported.
   if (DbInfo.Type == index_file) return 0;

   // Check that the event file exists.
   if (!QFile::exists(EventFile)) return 1;

   // If database type is 'local database'
   // then the DELET database is not used.
   // Just delete the file and exit.
   if (DbInfo.Type == local_database) {
      if (!QFile::remove(EventFile)) return 2;
      return 0;
   }

   // We are deleting from a normal Seisan database.
   // Get info about the name of the event file.
   GetSfileNameInfo(EventFile, &NameInfo);

   // Create path to the destination
   // directory in the DELET database.
   DeletPath = DbInfo.Path;
   PathCdUp(&DeletPath);
   DeletPath.append("/DELET");
   DeletPath.append("/" + NameInfo.Year);
   DeletPath.append("/" + NameInfo.Month);

   // If destination directory in the DELET
   // database do not exist, try to create it.
   if (!QFile::exists(DeletPath)) {
      QDir DeletDir("/");
      DeletDir.mkpath(DeletPath);
      if (!QFile::exists(DeletPath)) return 3;
   }

   // Create the file name for the deleted file. The
   // filename will change if a file with an identical
   // name already exists in DELET database.
   DeletFile = DeletPath + "/" + NameInfo.Name;
   while (QFile::exists(DeletFile)) {
      AddOneSecToSfileName(&DeletFile);
   }

   // Copy event file to DELET database folder and delete from database.
   Sfile.setFileName(EventFile);
   if (!Sfile.copy(DeletFile)) return 4;
   if (!Sfile.remove()) return 2;

   return 0;
}




// ****************************************************
// Duplicate an S-file in the seisan database. Returns
// 'true' if duplication succeeded. Also returns the
// name of the duplicated file.
// ****************************************************
bool DuplicateSfileOnDisk(QString EventFile, QString *DupFile, QString OperID)
{
   QFile Sfile;
   QString IdLine;
   sfile_nameinfo NameInfo;

   // Check that the event file exists.
   if (!QFile::exists(EventFile)) return false;

   // Create the file name for the duplicated file.
   // The filename will have one second added to it.
   *DupFile = EventFile;
   while (QFile::exists(*DupFile)) AddOneSecToSfileName(DupFile);

   // Copy event file to the new duplicated file.
   Sfile.setFileName(EventFile);
   if (!Sfile.copy(*DupFile)) return false;

   // Get name information for the duplicated file.
   GetSfileNameInfo(*DupFile, &NameInfo);

   // Get ID line from duplicated file.
   if (!GetSfileIdLine(*DupFile, &IdLine)) {
       // Cannot get ID line. Delete file and exit.
       QFile::remove(*DupFile); return false;
   }

   // Update the ID line in the duplicated file.
   // Update the 'Last action' field.
   IdLine.replace(8, 3, "DUP");
   IdLine.replace(12, 14, QDateTime::currentDateTime().toString("yy-MM-dd hh:mm"));
   // Update the 'Operator code' field.
   IdLine.replace(30, 4, OperID.leftJustified(4, ' '));
   // Update the 'ID' field.
   IdLine.replace(60, 15, NameInfo.DateStr + NameInfo.TimeStr + "D");

   // Replace the ID line in S-file.
   if (!SetSfileIdLine(*DupFile, IdLine)) {
      // Cannot update ID line. Delete file and exit.
      QFile::remove(*DupFile); return false;
   }

   return true;
}




// *********************************************************
// Merges two S-files in the Seisan database using the
// fortran function 'merge_f'.
//
// Return status is:
// 1=File not found, 2=Unable to open file,
// 3=More than 24 hours apart, 4=Previous day,
// 5=Can not open destination file for writing.
// *********************************************************
int MergeSfilesOnDisk(QString MasterFile, QString MergeFile)
{
   QString line;
   QTextStream ts;
   char merge_data[MAX_SFILE_LINES][80];
   char master_data[MAX_SFILE_LINES][80];
   int nhmaster, nrmaster, nhmerge, nrmerge, status;

   // Let QFile handle the files.
   QFile qfMasterFile(MasterFile);
   QFile qfMergeFile(MergeFile);

   // Check that files exists.
   if (!qfMasterFile.exists()) return 1;
   if (!qfMergeFile.exists()) return 1;

   // Open files.
   if (!qfMasterFile.open(QIODevice::ReadOnly|QIODevice::Text)) return 2;
   if (!qfMergeFile.open(QIODevice::ReadOnly|QIODevice::Text)) {
      qfMasterFile.close(); return 2;
   }

   // Read master file into memory.
   nhmaster = nrmaster = 0;
   ts.setDevice(&qfMasterFile);
   while (!ts.atEnd()) {
      line = ts.readLine().leftJustified(80, ' ');
      if (!IsQStrAllSpace(line)) {
         memcpy((void*)master_data[nrmaster], line.toLocal8Bit().data(), 80);
         if (line.at(79) != 32 && line.at(79) != '4') nhmaster++;
         nrmaster++;
      }
   }

   // Read merge file into memory.
   nhmerge = nrmerge = 0;
   ts.setDevice(&qfMergeFile);
   while (!ts.atEnd()) {
      line = ts.readLine().leftJustified(80, ' ');
      if (!IsQStrAllSpace(line)) {
         memcpy((void*)merge_data[nrmerge], line.toLocal8Bit().data(), 80);
         if (line.at(79) != 32 && line.at(79) != '4') nhmerge++;
         nrmerge++;
      }
   }

   // Close files.
   qfMasterFile.close(); qfMergeFile.close();

   // Merge 'MergeFile' into 'MasterFile'.
   merge_f_((char*)master_data, (char*)merge_data, &nhmaster, &nhmerge, &nrmaster,
             &nrmerge, &status, sizeof(master_data), sizeof(merge_data));

   // Check status of merge operation.
   if (status) return status+2;

   // Rewrite the merged master file.
   if (!qfMasterFile.open(QIODevice::WriteOnly|QIODevice::Truncate|QIODevice::Text)) return 5;
   ts.setDevice(&qfMasterFile);
   for (int i=0;i<nrmaster;i++) ts << QString::fromLocal8Bit(master_data[i], 80) << "\n";
   qfMasterFile.close();

   return 0;
}




// ****************************************************
// Returns the ID line for the given S-file.
// ****************************************************
bool GetSfileIdLine(QString SFile, QString *IdLine)
{
   QFile file;
   QString line;

   // Check that file exists.
   if (!QFile::exists(SFile)) return false;

   // Open file.
   file.setFileName(SFile);
   if (!file.open(QIODevice::ReadOnly|QIODevice::Text)) return false;

   // File was opened successfully. Read lines until
   // the ID line are found or we reach end of file.
   QTextStream ts(&file);
   while (!ts.atEnd()) {
      line = ts.readLine();
      if (line.size() >= 80) {
         if (line.at(79) == 'I') {
            *IdLine = line;
            file.close();
            return true;
         }
      }
   }

   // The ID line was not found.
   file.close();
   return false;
}




// ****************************************************
// Replaces the ID line in the given S-file.
// ****************************************************
bool SetSfileIdLine(QString SFile, QString IdLine)
{
   QString line;
   QFile sfile, tfile;

   // Check that file exists.
   if (!QFile::exists(SFile)) return false;

   // Check size of ID line. Must be min. 80 chars.
   if (IdLine.size() < 80) return false;

   // Open event file.
   sfile.setFileName(SFile);
   if (!sfile.open(QIODevice::ReadWrite|QIODevice::Text)) return false;

   // Open temporary file.
   tfile.setFileName("se-duplicate.tmp");
   if (!tfile.open(QIODevice::ReadWrite|QIODevice::Text|QIODevice::Truncate)) {
      sfile.close();
      return false;
   }

   // Copy S-file to a temporary file. The ID
   // line will be replaced in temporary file.
   QTextStream stream_sfile(&sfile);
   QTextStream stream_tfile(&tfile);
   while (!stream_sfile.atEnd()) {
      line = stream_sfile.readLine();
      if (line.size()) {
         if (line.size() >= 80 ) {
            if (line.at(79) == 'I') {
               stream_tfile << IdLine << "\n";
            } else {
               stream_tfile << line << "\n";
            }
         } else {
            stream_tfile << line << "\n";
         }
      }
   }

   // Close files;
   sfile.close(); tfile.close();

   // Overwrite the S-file with the temporary file.
   if (!sfile.remove()) { tfile.remove(); return false; }
   if (!tfile.copy(SFile)) { tfile.remove(); return false; }
   tfile.remove();

   return true;
}
