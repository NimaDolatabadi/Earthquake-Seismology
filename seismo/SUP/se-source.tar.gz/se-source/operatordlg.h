#ifndef OPERATORDLG_H
#define OPERATORDLG_H

#include <QDialog>

namespace Ui {
    class OperatorDlg;
}

class OperatorDlg : public QDialog
{
   Q_OBJECT

public:
   explicit OperatorDlg(QWidget *parent = 0);
   ~OperatorDlg();
   void InitDialog(QString *Id);

public slots:
   void accept(void);
   void reject(void);

private:
   Ui::OperatorDlg *ui;
   QString *operatorid;
};

#endif // OPERATORDLG_H
