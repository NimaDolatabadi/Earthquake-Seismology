#ifndef FILEEDITORDLG_H
#define FILEEDITORDLG_H

#include <QFile>
#include <QDialog>
#include <QTextEdit>
#include <QShortcut>
#include <QByteArray>
#include <QTextBlock>
#include <QTextCharFormat>

#include "fileeditor_findreplacedlg.h"

namespace Ui {
   class FileEditorDlg;
}

class FileEditorDlg : public QDialog
{
   Q_OBJECT

signals:
   void file_saved(QString);     // This signal is emitted when the file is saved.

public:
   explicit FileEditorDlg(QWidget *parent = 0);
   ~FileEditorDlg();
   bool LoadFile(QString);
   bool SavePos;

public slots:
   void Save();
   void Close();
   void SaveAs();
   void FindReplace();
   void CursorPositionChanged();
   bool eventFilter(QObject*, QEvent*);

private:
   Ui::FileEditorDlg *ui;
   QFile file;
   QByteArray buffer;
   QString filepath, AppName, string, message;
   frdata SearchData;
   bool OverwriteMode;
   void DeleteCurrentLine();
   void ToggleOverwriteMode();
};

#endif // FILEEDITORDLG_H
