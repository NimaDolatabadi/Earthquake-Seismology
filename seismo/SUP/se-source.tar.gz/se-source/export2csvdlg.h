#ifndef EXPORT2CSVDLG_H
#define EXPORT2CSVDLG_H

#include <QDialog>
#include "database.h"

namespace Ui {
   class Export2CsvDlg;
}

class Export2CsvDlg : public QDialog
{
   Q_OBJECT

public:
   explicit Export2CsvDlg(db *database, QWidget *parent = 0);
   ~Export2CsvDlg();

private slots:
   void Exit();
   void OutputChoice();
   void AddChoice(QTextStream&, int, int);

private:
   Ui::Export2CsvDlg *ui;
   db *DataBase;
};

#endif
