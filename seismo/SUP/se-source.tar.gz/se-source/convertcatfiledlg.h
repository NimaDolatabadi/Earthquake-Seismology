﻿#ifndef CONVERTCATFILEDLG_H
#define CONVERTCATFILEDLG_H

#include <QDialog>
#include "types.h"

namespace Ui {
   class ConvertCatFileDlg;
}

class ConvertCatFileDlg : public QDialog
{
   Q_OBJECT

public:
   explicit ConvertCatFileDlg(QWidget* parent = 0, QString* = NULL, QString* = NULL);
   ~ConvertCatFileDlg();

public slots:
   void Cancel();
   void Extract();
   void SelectFile();
   void SelectFolder();

private:
   bool ConvertDone;
   Ui::ConvertCatFileDlg *ui;
   QString *dbPath, *catFile, AppName;
   QString WorkDir, DestFolder, Message;
};

#endif // CONVERTCATFILEDLG_H
