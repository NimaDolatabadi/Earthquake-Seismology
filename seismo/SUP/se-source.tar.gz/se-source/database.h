#ifndef DATABASE_H
#define DATABASE_H

#include <QDate>
#include <QDebug>
#include <QMutex>
#include <QString>
#include <QTableView>
#include <QMainWindow>
#include <QStringList>
#include <QMessageBox>
#include <QtAlgorithms>
#include <QtConcurrent/QtConcurrentRun>
#include <QFileSystemWatcher>

#include "types.h"
#include "logmodel.h"
#include "eventnode.h"
#include "enumsfiles.h"
#include "readsfiles.h"

struct db_filter_pf {
   QString Description;
   QStringList InclQuery;
   QStringList ExclQuery;
};


class db : public QObject
{
         Q_OBJECT

public:
   enum dbStatus { closed, enum_sfiles, read_sfiles, open };
   enum dbError { no_error, already_open, no_files_found, out_of_memory, cancelled, corrpupt_files };

   db(logmodel*);                                     // Constructor function.
   void Open(db_info DbInfo, QDate, QDate);           // Load Seisan database from disk.
   void Close(void);                                  // Close the database.
   void SetSortCol(sortCol);                          // Sets the current sort column and sort database.
   void SetSortOrd(Qt::SortOrder);                    // Sets the current sort order.
   void Resort(bool);                                 // Resort the presentation index list. Optionally resorts master index as well.
   void SortCriteria(sortCol*, Qt::SortOrder*);       // Return current sort criteria.
   event_node_* EventByIndex(int);                    // Return pointer to single event by index.
   int  NumEvents(void);                              // Return number of events in database.
   bool FileByIndex(int, QString*);                   // Return file name to single event by index.
   bool FileById(int, QString*);                      // Return file name to single event by event id.
   int  IdByIndex(int);                               // Return the event's unique identity number by index.
   int  IndexById(int);                               // Return database index to an event by event's identity number.
   int  IndexByFile(QString);                         // Return database index to an event by event's file aname.
   void MarkedEvents(QListInt*);                      // Return list of indexes for all marked events.
   void UnmarkAllEvents();                            // Unmarks all events in the database.
   int  LoadEventAndResort(QString);                  // Load a new S-file into the database and resort the database.
   int LoadEvent(QString);                            // Load a new S-file into the database. DAtabase will not be resorted.
   int  ReloadEventAndResort(int);                    // Reload an already loaded S-file into the database. Database will be resorted.
   bool RemoveEvent(int);                             // Removes an event from database. S-file is NOT deleted.
   dbStatus Status();                                 // Return operational status of database.
   bool UpdateSfile(int, char*, QString = QString()); // Rewrites the S-file for the node pointed to by index.
   void AssociateEvents(int, int, QList<int>*);       // Find events that are close to each other in time.
   int  ApplyFilter(db_filter);                       // Apply filter to presentation index.
   void RemoveFilter();                               // Remove filter from presentation index.
   bool isFilterApplied();                            // Returns true if a filter is applied.
   enumsfiles EnumSfiles;                             // Thread class. Creates a list of S-files in Seisan database.
   readsfiles ReadSfiles;                             // Thread class. Reads S-files from Seisan database into memory.
   QString DatabasePath;                              // Holds the path to the database.

public slots:
   void EnumSfilesProgress(int);                      // Signaled from 'EnumSfiles' to report enumeration progress.
   void EnumSfilesDone(char);                         // Signaled from 'EnumSfiles' when S-file enumeration is done.
   void ReadSfilesDone(char);                         // Signaled from 'ReadSfiles' when reading is done.
   void AddDbEvent(event_node_*);                     // Signaled from 'ReadSfiles'. Adds one event to Explorer database.
   void FileProblem(QString, QStringList, int);       // Signaled from 'ReadSfiles' each timet here is a problem reading an S-file.
   void SpeedSearch(QString, bool);                   // Signaled from the Speed Search dialog.
                                                      // Database must reply with signal SpeedSearchReply() to mainwindow.

signals:
   void db_event_added(int);
   void db_event_removed(int);
   void db_event_updated(int);
   void db_filter_progress(char);                     // Inform about pregress of a db filter operation.
   void db_open_progress(db::dbStatus, int);          // Inform about pregress of a db open operation.
   void db_open_result(db::dbStatus, db::dbError);    // Inform about result of db open operation.
   void db_speedsearch_reply(int);

private:
   // Objects related to the database status.
   dbStatus db_status;                                // Current database status.
   QMutex mtx_db_status;                              // Controls access to 'db_status' vaiable.
   QMutex mtx_db_cblock;                              // Controls access to the fortran common blocks.
   dbError db_error;                                  // Current database error;
   sortCol sort_col;                                  // Currently selected sort column.
   Qt::SortOrder sort_ord;                            // Currently selected sort order (ascending or descending).
   bool filter_applied;                               // Indicates if database has been filtered.
   void Init();                                       // Used to initialize the database.
   void set_db_status(dbStatus);                      // Safely sets the value of 'db_status'.
   dbStatus get_db_status();                          // Safely returns the value of 'db_status'.
   db_filter_pf DbFilter;                             // Last applied filter. Postfix format.

   // Objects related to the database indexes.
   QList<event_node_*> mIndex;                        // Master index. List of pointers to event nodes. Always sorted by 'DateTime'.
   QList<event_node_*> pIndex;                        // Presentation index. Pointers to all events in the event list view. Sorted in the order of presentation.
   void SortMasterIndex();                            // Function for sorting the mIndex list.
   void SortPresenIndex();                            // Function for sorting the pIndex list.
   void RebuildPresenIndex();                         // Rebuild the presentation index from the master index.
   void MoveUnsortablesDown();                        // Moves all unsortable nodes to the bottom of the pIndex list. Sort order is not changed.
   void UpdateNodePositions(bool);
   void CopyMasterToPresentation();
   int GetLastUnsortable();                           // Returns offset into secondary index list for the last unsortable event.

   // Other objects.
   logmodel *Log;
   QString Message;
   QMutex mtx_pindex;                                 // Controls access to the pIndex list.
   int num_pi_events();                               // Returns number of event in pIndex (thread-safe).
   int node_id_counter;                               // Used to make uniqe node ID's.
   int ss_last_found_index;                           // Used by the speed search function to save the last hit.
   QStringList sfilelist;                             // All S-files in the Seisan database found by findevin().
   int last_progress;                                 // Used to track database read progress.
   void AddEvent(event_node_*);                       // Add a single event. To be called from ReadSfiles only.
   void FreeDatabaseNodes();                          // Frees all memory used by the database nodes.
   void FilterNode(event_node_*);
};

#endif // DATABASE_H
