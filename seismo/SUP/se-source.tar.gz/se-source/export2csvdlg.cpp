#include "export2csvdlg.h"
#include "ui_export2csvdlg.h"
#include "mainwindow.h"
#include <QString>

#define CSVFILE (const char *)("se-csv.out")

Export2CsvDlg::Export2CsvDlg(db *database, QWidget *parent) :
                             QDialog(parent), ui(new Ui::Export2CsvDlg)
{
    ui->setupUi(this);

    QStringList separator;
    separator.append(";");
    separator.append(":");
    separator.append("-");
    separator.append(" ");

    QStringList type;
    type.append("Latitude");                // 0
    type.append("Longitude");               // 1
    type.append("Depth");                   // 2
    type.append("Main magnitude");          // 3
    type.append("Date");                    // 4
    type.append("Time");                    // 5
    type.append("Number of stations");      // 6
    type.append("Agency");                  // 7
    type.append("Main magnitude type");     // 8
    type.append("Main magnitude agency");   // 9


    ui->checkBox_0->setChecked(true);
    ui->comboBox_type_0->addItems(type);
    ui->comboBox_type_0->setCurrentIndex(0);
    ui->comboBox_separator_0->addItems(separator);

    ui->checkBox_1->setChecked(true);
    ui->comboBox_type_1->addItems(type);
    ui->comboBox_type_1->setCurrentIndex(1);
    ui->comboBox_separator_1->addItems(separator);

    ui->checkBox_2->setChecked(true);
    ui->comboBox_type_2->addItems(type);
    ui->comboBox_type_2->setCurrentIndex(2);
    ui->comboBox_separator_2->addItems(separator);

    ui->checkBox_3->setChecked(true);
    ui->comboBox_type_3->addItems(type);
    ui->comboBox_type_3->setCurrentIndex(3);
    ui->comboBox_separator_3->addItems(separator);

    ui->checkBox_4->setChecked(true);
    ui->comboBox_type_4->addItems(type);
    ui->comboBox_type_4->setCurrentIndex(4);
    ui->comboBox_separator_4->addItems(separator);

    ui->checkBox_5->setChecked(true);
    ui->comboBox_type_5->addItems(type);
    ui->comboBox_type_5->setCurrentIndex(5);
    ui->comboBox_separator_5->addItems(separator);

    ui->checkBox_6->setChecked(true);
    ui->comboBox_type_6->addItems(type);
    ui->comboBox_type_6->setCurrentIndex(6);
    ui->comboBox_separator_6->addItems(separator);

    ui->checkBox_7->setChecked(false);
    ui->comboBox_type_7->addItems(type);
    ui->comboBox_type_7->setCurrentIndex(7);
    ui->comboBox_separator_7->addItems(separator);

    DataBase=database;

    // Hi there,
    // if you want your function added to SE, please send us the source code
    // Good luck

    OutputChoice();
    connect(ui->pushButton_Save, SIGNAL(clicked()), this, SLOT(OutputChoice()));
    connect(ui->pushButton_Exit, SIGNAL(clicked()), this, SLOT(Exit()));

}

Export2CsvDlg::~Export2CsvDlg()
{
    delete ui;
}


void Export2CsvDlg::OutputChoice()
{
   int NumEvents = DataBase->NumEvents();

   // Save intervals and completeness years that was entered
   QFile *outFile = new QFile(CSVFILE);
   if (outFile->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
      QTextStream out(outFile);
      out << "# Output file from SEISAN Explorer\n";
      out << "# \n";
      out << "# The values between the separators are:\n";

      if ( ui->checkBox_0->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_0->currentText();
         out << "\n";
      }
      if ( ui->checkBox_1->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_1->currentText();
         out << "\n";
      }
      if ( ui->checkBox_2->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_2->currentText();
         out << "\n";
      }
      if ( ui->checkBox_3->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_3->currentText();
         out << "\n";
      }
      if ( ui->checkBox_4->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_4->currentText();
         out << "\n";
      }
      if ( ui->checkBox_5->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_5->currentText();
         out << "\n";
      }
      if ( ui->checkBox_6->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_6->currentText();
         out << "\n";
      }
      if ( ui->checkBox_7->checkState() == Qt::Checked ) {
         out << "# ";
         out << ui->comboBox_type_7->currentText();
         out << "\n";
      }

      out << "#\n";



      // go through event list and write selected output values:
      for (int i=0; i<NumEvents; ++i) {
         if ( ui->checkBox_0->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_0->currentIndex(), i);
            out << ui->comboBox_separator_0->currentText();
         }
         if ( ui->checkBox_1->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_1->currentIndex(), i);
            out << ui->comboBox_separator_1->currentText();
         }
         if ( ui->checkBox_2->checkState() == Qt::Checked ) {
             AddChoice(out, ui->comboBox_type_2->currentIndex(), i);
             out << ui->comboBox_separator_2->currentText();
         }
         if ( ui->checkBox_3->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_3->currentIndex(), i);
            out << ui->comboBox_separator_3->currentText();
         }
         if ( ui->checkBox_4->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_4->currentIndex(), i);
            out << ui->comboBox_separator_4->currentText();
         }
         if ( ui->checkBox_5->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_5->currentIndex(), i);
            out << ui->comboBox_separator_5->currentText();
         }
         if ( ui->checkBox_6->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_6->currentIndex(), i);
            out << ui->comboBox_separator_6->currentText();
         }
         if ( ui->checkBox_7->checkState() == Qt::Checked ) {
            AddChoice(out, ui->comboBox_type_7->currentIndex(), i);
            out << ui->comboBox_separator_7->currentText();
         }

         out << "\n";
      }

      outFile->close();
   }
}




void Export2CsvDlg::AddChoice( QTextStream &stream, int choice, int event )
{
   event_node_ *Node;

   Node = DataBase->EventByIndex(event);

   if ( choice == 0 )
      if ( Node->hypocenters.first->lat > -999 )
         stream << Node->hypocenters.first->lat;
      else
         stream << "";
   else if ( choice == 1 )
      if ( Node->hypocenters.first->lon > -999 )
         stream << Node->hypocenters.first->lon;
      else
          stream << "";
   else if ( choice == 2 )
      if ( Node->hypocenters.first->depth > -999 )
         stream << Node->hypocenters.first->depth;
      else
          stream << "";
   else if ( choice == 3 )
      if ( Node->hypocenters.nmag > 0 )
         stream << Node->hypocenters.mag_all[0].mag;
      else
          stream << "";
   else if ( choice == 4 ) {
      stream << Node->hypocenters.first->time.year;
      stream << "-";
      if (Node->hypocenters.first->time.month<10) stream << "0";
      stream << Node->hypocenters.first->time.month;
      stream << "-";
      if (Node->hypocenters.first->time.day<10) stream << "0";
      stream << Node->hypocenters.first->time.day;
   }
   else if ( choice == 5 ) {
      if (Node->hypocenters.first->time.hour<10) stream << "0";
      stream << Node->hypocenters.first->time.hour;
      stream << ":";
      if (Node->hypocenters.first->time.minute<10) stream << "0";
      stream << Node->hypocenters.first->time.minute;
      stream << ":";
      if(Node->hypocenters.first->time.second<10) stream << "0";
      stream << Node->hypocenters.first->time.second;
   }
   else if ( choice == 6 )
      if ( Node->hypocenters.first->nstat > -999 )
         stream << Node->hypocenters.first->nstat;
      else
         stream << "";
   else if ( choice == 7 ) stream << Node->hypocenters.first->agency;
   else if ( choice == 8 ) stream << Node->hypocenters.mag_all[0].type;
   else if ( choice == 9 ) stream << Node->hypocenters.mag_all[0].agency;
}


void Export2CsvDlg::Exit()
{
   close();
}
