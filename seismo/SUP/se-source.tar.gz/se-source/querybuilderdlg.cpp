#include <QDebug>
#include <QColor>
#include <QPalette>
#include <QTextCursor>
#include "querybuilderdlg.h"
#include "ui_querybuilderdlg.h"
#include "filter.h"
#include "library.h"


// ************************************
// Constructor function for this class.
// ************************************
QueryBuilderDlg::QueryBuilderDlg(QWidget *parent) : QDialog(parent), ui(new Ui::QueryBuilderDlg)
{
   ui->setupUi(this);

   // Change the 'Inactive' text selection colors for the editor.
   QPalette p = ui->ExprTextEdit->palette();
   QColor color = p.color(QPalette::Active, QPalette::Highlight);
   p.setColor(QPalette::Inactive, QPalette::Highlight, color);
   color = p.color(QPalette::Active, QPalette::HighlightedText);
   p.setColor(QPalette::Inactive, QPalette::HighlightedText, color);
   ui->ExprTextEdit->setPalette(p);
}




// ************************************
// Destructor function for this class.
// ************************************
QueryBuilderDlg::~QueryBuilderDlg()
{
   delete ui;
}




// *************************************************************
// This function is used to save pointer to returned expression.
// *************************************************************
void QueryBuilderDlg::InitDialog(QString *QueryExpression, char ExprType)
{
   // Save pointer to returned expression.
   QExpr = QueryExpression;

   // Save expression type.
   eType = ExprType;

   // Set text format for error label.
   ui->MsgLabel->setTextFormat(Qt::PlainText);

   // Use error label to explain about the IncludeAll staement.
   if (ExprType == 0) {
      ui->MsgLabel->setText("To include all events, use statement 'IncludeAll'.");
   }

   // Copy query expression to edit box.
   ui->ExprTextEdit->setPlainText(*QExpr);

   // Activate the text editor window.
   ui->ExprTextEdit->setFocus(Qt::ActiveWindowFocusReason);
}




// **********************************************
// Operator button functions. Operator will be
// inserted into the edit box at cursor position.
// **********************************************
void QueryBuilderDlg::EqButton()
{
   ui->ExprTextEdit->textCursor().insertText(" = ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::SmallerButton()
{
   ui->ExprTextEdit->textCursor().insertText(" < ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::SmallerEqButton()
{
   ui->ExprTextEdit->textCursor().insertText(" <= ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LargerButton()
{
   ui->ExprTextEdit->textCursor().insertText(" > ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LargerEqButton()
{
   ui->ExprTextEdit->textCursor().insertText(" >= ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::AndButton()
{
   ui->ExprTextEdit->textCursor().insertText(" AND ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::OrButton()
{
   ui->ExprTextEdit->textCursor().insertText(" OR ");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LeftParButton()
{
   ui->ExprTextEdit->textCursor().insertText("(");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::RightParButton()
{
   ui->ExprTextEdit->textCursor().insertText(")");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}




// ***********************************************
// Property button functions. Properties will be
// inserted into the edit box at cursor position.
// ***********************************************
void QueryBuilderDlg::ActionButton() {
   ui->ExprTextEdit->textCursor().insertText("$Action");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::AgencyButton() {
   ui->ExprTextEdit->textCursor().insertText("$Agency");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::AmplButton() {
   ui->ExprTextEdit->textCursor().insertText("$Ampl");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::AmplPeriodButton() {
   ui->ExprTextEdit->textCursor().insertText("$AmplPeriod");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::BackAzimutButton() {
   ui->ExprTextEdit->textCursor().insertText("$BackAzimut");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::CommentsButton() {
   ui->ExprTextEdit->textCursor().insertText("$Comments");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::CompButton() {
   ui->ExprTextEdit->textCursor().insertText("$Comp");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::CornFreqButton() {
   ui->ExprTextEdit->textCursor().insertText("$CornFreq");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::DateButton() {
   ui->ExprTextEdit->textCursor().insertText("$Date");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::DepthButton() {
   ui->ExprTextEdit->textCursor().insertText("$Depth");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::DepthErrButton() {
   ui->ExprTextEdit->textCursor().insertText("$DepthErr");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::DistIndButton() {
   ui->ExprTextEdit->textCursor().insertText("$DistInd");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::EpiDistButton() {
   ui->ExprTextEdit->textCursor().insertText("$EpiDist");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::EventIndButton() {
   ui->ExprTextEdit->textCursor().insertText("$EventInd");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::GapButton() {
   ui->ExprTextEdit->textCursor().insertText("$Gap");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::HourButton() {
   ui->ExprTextEdit->textCursor().insertText("$Hour");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LatButton() {
   ui->ExprTextEdit->textCursor().insertText("$Lat");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LatErrButton() {
   ui->ExprTextEdit->textCursor().insertText("$LatErr");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LocalityButton() {
   ui->ExprTextEdit->textCursor().insertText("$Locality");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LonButton() {
   ui->ExprTextEdit->textCursor().insertText("$Lon");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::LonErrButton() {
   ui->ExprTextEdit->textCursor().insertText("$LonErr");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagbButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag_B");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagBButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag-B");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagCButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag-C");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagLButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag-L");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagsButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag_S");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagSButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag-S");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::MagWButton() {
   ui->ExprTextEdit->textCursor().insertText("$Mag-W");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::ModelButton() {
   ui->ExprTextEdit->textCursor().insertText("$Model");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::NumFpsButton() {
   ui->ExprTextEdit->textCursor().insertText("$NumFPS");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::NumPolarButton() {
   ui->ExprTextEdit->textCursor().insertText("$NumPol");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::NumStatButton() {
   ui->ExprTextEdit->textCursor().insertText("$NumStat");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::PhaseNameButton() {
   ui->ExprTextEdit->textCursor().insertText("$PhaseName");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::QualityButton() {
   ui->ExprTextEdit->textCursor().insertText("$Quality");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::RmsButton() {
   ui->ExprTextEdit->textCursor().insertText("$RMS");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::StaCodeButton() {
   ui->ExprTextEdit->textCursor().insertText("$StaCode");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::StrDropButton() {
   ui->ExprTextEdit->textCursor().insertText("$StrDrop");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::TrvlTmeResButton() {
   ui->ExprTextEdit->textCursor().insertText("$TrvlTmeRes");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}




// ***********************************************
// Function button functions. Function will be
// inserted into the edit box at cursor position.
// ***********************************************
void QueryBuilderDlg::ContainsButton() {
   ui->ExprTextEdit->textCursor().insertText("Contains[,\"\"]");
   cursor = ui->ExprTextEdit->textCursor();
   cursor.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, 4);
   ui->ExprTextEdit->setTextCursor(cursor);
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::HasFpsButton() {
    ui->ExprTextEdit->textCursor().insertText("HasFPS[]");
   cursor = ui->ExprTextEdit->textCursor();
   cursor.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, 1);
   ui->ExprTextEdit->setTextCursor(cursor);
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::HasMagnitudeButton() {
    ui->ExprTextEdit->textCursor().insertText("HasMagnitude[$Agency = \"\",PRIMARY]");
   cursor = ui->ExprTextEdit->textCursor();
   cursor.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, 10);
   ui->ExprTextEdit->setTextCursor(cursor);
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::HasStationButton() {
   ui->ExprTextEdit->textCursor().insertText("HasStation[]");
   cursor = ui->ExprTextEdit->textCursor();
   cursor.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, 1);
   ui->ExprTextEdit->setTextCursor(cursor);
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::InRangeButton() {
   ui->ExprTextEdit->textCursor().insertText("InRange[,,]");
   cursor = ui->ExprTextEdit->textCursor();
   cursor.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, 3);
   ui->ExprTextEdit->setTextCursor(cursor);
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::IsFeltButton() {
   ui->ExprTextEdit->textCursor().insertText("IsFelt[]");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::DistanceButton() {
   ui->ExprTextEdit->textCursor().insertText("Distance[,]");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::InPolygonButton() {
   ui->ExprTextEdit->textCursor().insertText("InPolygon[,,,,,]");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}
void QueryBuilderDlg::WeekDayButton() {
   ui->ExprTextEdit->textCursor().insertText("WeekDay[]");
   ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
}




// ***********************************
// User has pressed the 'OK' button.
// ***********************************
void QueryBuilderDlg::accept()
{
   QString Expr, ErrMsg;

   // Copy expression from edit box.
   Expr = ui->ExprTextEdit->toPlainText();

   // Check the expression for errors.
   if (!TrimAndCheckInfix(&Expr, &ErrMsg, eType)) {
      // Return expression to edit box.
      ui->ExprTextEdit->setPlainText(Expr);

      // Expression check failed. Show error message in red text.
      ui->MsgLabel->setStyleSheet("QLabel { color : red; }");
      ui->MsgLabel->setText(ErrMsg);
      ui->ExprTextEdit->setFocus(Qt::OtherFocusReason);
      QApplication::beep();
      return;
   }

   // Return expression.
   *QExpr = Expr;

   // Close the dialog and return 'Accepted' signal.
   done(QDialog::Accepted);
}




// *************************************
// User has pressed the 'Cancel' button.
// *************************************
void QueryBuilderDlg::reject()
{
   // Close the dialog and return 'Rejected' signal.
   done(QDialog::Rejected);
}
