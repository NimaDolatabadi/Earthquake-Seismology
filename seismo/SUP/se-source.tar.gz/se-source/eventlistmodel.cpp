#include "types.h"
#include "library.h"
#include "database.h"
#include "eventlistmodel.h"
#include "mainwindow.h"
#include <QDebug>
#include <QTableWidgetItem>
#include <QModelIndexList>
#include <QItemSelection>
#include <QStringListModel>


// *************************************************************************
// Constructor function.
// *************************************************************************
eventlistmodel::eventlistmodel(db *database, QObject *parent) : QAbstractTableModel(parent)
{
   // Save some pointers and init variables.
   SelModel = 0;
   TaggedRow = -1;
   NumSelectedRows = 0;
   SetNumModelEvents(0);
   DataBase = database;
   SelectedRows.clear();
   SelectedRows.resize(MAX_EVENTS);
}




// *****************************************************
// This fuction resets the model/view.
// *****************************************************
void eventlistmodel::Reset()
{
   ModelView->scrollToTop();
   beginResetModel();
   NumSelectedRows = 0;
   SetNumModelEvents(0);
   DelayedSelections.clear();
   SelectedRows.clear();
   SelectedRows.resize(MAX_EVENTS);
   endResetModel();
}




// *************************************************************
// This function is used to set pointer to the Event List View.
// *************************************************************
void eventlistmodel::SetView(QTableView *View)
{
   // Save pointers to the view, and it's selection model.
   ModelView = View;
   SelModel = ModelView->selectionModel();

   // Connect the selectionChanged() signal from the selection model.
   connect(SelModel, SIGNAL(selectionChanged(const QItemSelection&, const QItemSelection&)),
                this, SLOT(selectionChanged(const QItemSelection&, const QItemSelection&)));

   // Connect the currentRowChanged() signal from the selection model.
   connect(SelModel, SIGNAL(currentRowChanged(const QModelIndex&, const QModelIndex&)),
                this, SLOT(currentRowChanged(const QModelIndex&, const QModelIndex&)));
}




// *****************************************************
// This fuction is called from event list view
// to get header information for the view.
// *****************************************************
QVariant eventlistmodel::headerData(int section, Qt::Orientation orientation, int role) const
{
   if (role == Qt::DisplayRole) {
      // Return labels for the horizontal headers.
      if (orientation == Qt::Horizontal) {
         switch (section) {
            case ColRowNumber: return QVariant("Row");
            case ColAction: return QVariant("Ac");
            case ColDateTime: return QVariant("Date and Time");
            case ColLatitude: return QVariant("Lat");
            case ColLongitude: return QVariant("Lon");
            case ColDepth: return QVariant("Dep");
            case ColModel: return QVariant("Mod");
            case ColAgency: return QVariant("Ag");
            case ColRMS: return QVariant("RMS");
            case ColGap: return QVariant("Gap");
            case ColErrLat: return QVariant("ELat");
            case ColErrLon: return QVariant("ELon");
            case ColErrDep: return QVariant("EDep");
            case ColDist: return QVariant("DI");
            case ColType: return QVariant("EI");
            case ColMInt: return QVariant("MInt");
            case ColNrSta: return QVariant("NSt");
            case ColM: return QVariant("M");
            case ColMW: return QVariant("MW");
            case ColML: return QVariant("ML");
            case ColMN: return QVariant("MN");
            case ColMC: return QVariant("MC");
            case ColMb: return QVariant("Mb");
            case ColMB: return QVariant("MB");
            case ColMs: return QVariant("Ms");
            case ColMS: return QVariant("MS");
            case ColLocality: return QVariant("Locality");
            case ColSFile: return QVariant("Event file");
         }
      }
   }

   if (role == Qt::ToolTipRole) {
      // Return tool tips for the horizontal headers.
      if (orientation == Qt::Horizontal) {
         switch (section) {
            case ColRowNumber: return QVariant("Row Number");
            case ColAction: return QVariant("Action");
            case ColDateTime: return QVariant("Date and Time");
            case ColLatitude: return QVariant("Latitude");
            case ColLongitude: return QVariant("Longitude");
            case ColDepth: return QVariant("Depth");
            case ColModel: return QVariant("Model");
            case ColAgency: return QVariant("Agency");
            case ColRMS: return QVariant("RMS");
            case ColGap: return QVariant("Gap");
            case ColErrLat: return QVariant("Latitude Error");
            case ColErrLon: return QVariant("Longitude Error");
            case ColErrDep: return QVariant("Depth Error");
            case ColDist: return QVariant("Distance Indicator");
            case ColType: return QVariant("Event Indicator");
            case ColMInt: return QVariant("If earthquake is felt, shows maximum intensity");
            case ColNrSta: return QVariant("Number of Stations");
            case ColM: return QVariant("Main Magnitude");
            case ColMW: return QVariant("Magnitude MW");
            case ColML: return QVariant("Magnitude ML");
            case ColMN: return QVariant("Magnitude MN");
            case ColMC: return QVariant("Magnitude MC");
            case ColMb: return QVariant("Magnitude Mb");
            case ColMB: return QVariant("Magnitude MB");
            case ColMs: return QVariant("Magnitude Ms");
            case ColMS: return QVariant("Magnitude MS");
            case ColLocality: return QVariant("Locality");
            case ColSFile: return QVariant("Full path to S-File");
         }
      }
   }

   if (role == Qt::SizeHintRole) {
      // Return size hints for the horizontal headers.
      switch (section) {
         case ColRowNumber: return QSize(40, 23);
         case ColLatitude: return QSize(40, 23);
         case ColLongitude: return QSize(40, 23);
         case ColDepth: return QSize(40, 23);
         case ColModel: return QSize(40, 23);
         case ColRMS: return QSize(41, 23);
         case ColGap: return QSize(40, 23);
         case ColErrLat: return QSize(44, 23);
         case ColErrLon: return QSize(44, 23);
         case ColErrDep: return QSize(45, 23);
         case ColMInt: return QSize(39, 23);
         case ColNrSta: return QSize(39, 23);
         case ColMW: return QSize(33, 23);
         case ColLocality: return QSize(60, 23);
         case ColSFile: return QSize(50, 23);
         default: return QSize(33, 23);
      }
   }

   return QVariant();
}




// *****************************************************
// This fuction is called from event list view to get
// the number of rows to present in the view.
// *****************************************************
int eventlistmodel::rowCount(const QModelIndex &parent) const
{
   // Return zero if parent is valid.
   if (parent.isValid()) return 0;

   // Return current number of events in model.
   return GetNumModelEvents();
}




// *****************************************************
// This fuction is called from event list view to get
// the number of columns to show in the view.
// *****************************************************
int eventlistmodel::columnCount(const QModelIndex &parent) const
{
   // Return zero if parent is valid.
   if (parent.isValid()) return 0;

   // Return number of columns.
   return NumElvColumns;
}




// *******************************************************************
// This function tells the view if there are any more rows to display.
// This function is called by the event list view.
// *******************************************************************
bool eventlistmodel::canFetchMore(const QModelIndex &parent) const
{
   Q_UNUSED(parent)

   // If database is closed, return 'false'.
   if (DataBase->Status() == db::closed) return false;

   // Return 'true' if there are new events in database.
   if (GetNumModelEvents() < DataBase->NumEvents()) return true;

   return false;
}




// *******************************************************************
// This function inserts more rows to display.
// *******************************************************************
void eventlistmodel::fetchMore(const QModelIndex &parent)
{
   Q_UNUSED(parent)

   selection Selection;
   QModelIndex FirstItem;
   int NumDbEvents, NumSel, Index;

   // Get current number of events in database.
   NumDbEvents = DataBase->NumEvents();

   // Update model with new events.
   beginInsertRows(QModelIndex(), GetNumModelEvents(), NumDbEvents-1);
   SetNumModelEvents(NumDbEvents);
   endInsertRows();

   // Do delayed row selections if needed.
   NumSel = DelayedSelections.size(); Index = 0;
   for (int i=0;i<NumSel;i++) {
      Selection = DelayedSelections.at(Index);
      if (Selection.row < NumDbEvents) {
         // Do this selection.
         FirstItem = index(Selection.row, 2);
         if (Selection.clearselection) {
            SelModel->select(FirstItem, QItemSelectionModel::ClearAndSelect | QItemSelectionModel::Rows);
         } else {
            SelModel->select(FirstItem, QItemSelectionModel::Select | QItemSelectionModel::Rows);
         }
         if (Selection.setascurrent) SelModel->setCurrentIndex(FirstItem, QItemSelectionModel::NoUpdate);
         if (Selection.ensurevisible) ModelView->scrollTo(FirstItem, QAbstractItemView::PositionAtCenter);
         // Remove selection from list of delayed selections.
         DelayedSelections.removeAt(Index);
      } else {
         Index++;
      }
   }
}




// ***************************************************************************
// This function selects a row in the view.
// Existing selections may optionally be cleared first.
// The first item in selected row may optionally be set as the current item.
// The selected row may optionally be scrolled into center of the view.
// ***************************************************************************
void eventlistmodel::SelectRow(int Row, bool Clear, bool Current, bool Scroll)
{
   selection Selection;

   // Check if Row is in model.
   if (Row < GetNumModelEvents()) {
      // Row is in model. Select row.
      QModelIndex FirstItem = index(Row, 2);
      if (Clear) SelModel->select(FirstItem, QItemSelectionModel::ClearAndSelect | QItemSelectionModel::Rows);
      if (!Clear) SelModel->select(FirstItem, QItemSelectionModel::Select | QItemSelectionModel::Rows);
      if (Current) SelModel->setCurrentIndex(FirstItem, QItemSelectionModel::NoUpdate);
      if (Scroll) ModelView->scrollTo(FirstItem, QAbstractItemView::PositionAtCenter);
   } else {
      // Row is not in model yet. Select this row later.
      Selection.row = Row;
      Selection.setascurrent = Current;
      Selection.ensurevisible = Scroll;
      Selection.clearselection = Clear;
      DelayedSelections.append(Selection);
   }
}




// ***************************************************************************
// This function unselects a row in the view.
// ***************************************************************************
void eventlistmodel::UnselectRow(int Row)
{
   // Check if Row is in model.
   if (Row < GetNumModelEvents()) {
      // Row is in model. Unselect row.
      QModelIndex FirstItem = index(Row, 2);
      SelModel->select(FirstItem, QItemSelectionModel::Deselect | QItemSelectionModel::Rows);
   }
}




// ***************************************************************************
// This function clears all selections in the view.
// ***************************************************************************
void eventlistmodel::ClearSelection()
{
   SelModel->clearSelection();
}




// ***************************************************************************
// This function marks or unmarks selected rows in the view.
// ***************************************************************************
void eventlistmodel::MarkUnmarkSelectedRows()
{
   event_node_ *Node;
   QListEventID Selection;

   // Get the list of selected rows.
   GetSelection(&Selection);

   // Get number of selected rows.
   int NumRows = Selection.size();

   // Exit if no rows are selected.
   if (!NumRows) return;

   // Toggle marking for all selected rows.
   for (int i=0;i<NumRows;i++) {
      // Togge the mark flag in the database.
      Node = DataBase->EventByIndex(Selection.at(i).index);
      Node->metadata.marked = !Node->metadata.marked;
      // Update the event list view.
      RefreshRow(Selection.at(i).index);
   }

   // If only one row where marked, move selection down to the next row.
   // This will speed up the process of marking several consecutive rows.
   if (NumRows == 1) SelectRow(Selection.at(0).index + 1, true, true, false);
}




// ***************************************************************************
// This function unmarks all marked rows in the view.
// ***************************************************************************
void eventlistmodel::UnmarkAllRows()
{
   int index;
   QListInt EventList;

   // Get a list of indexes for all marked events.
   DataBase->MarkedEvents(&EventList);

   // Exit if no events are marked.
   if (!EventList.size()) return;

   // Unmark all events in database.
   DataBase->UnmarkAllEvents();

   // Update the view.
   foreach (index, EventList) RefreshRow(index);
}




// ********************************************************************
// Start searching from the row below the row with the 'current index'.
// Stop when the first marked row has been found, and scroll this row
// into view. If there is no current index, search from start instead.
// Current index will be moved to the start of the found row.
// ********************************************************************
void eventlistmodel::ScrollToNextMarkedEvent()
{
   bool done, found;
   int StartRow, Row;
   event_node_ *Node;

   // Find number of events in model.
   int NumEvents = rowCount();

   // Find the row number from where the search starts.
   Row = SelModel->currentIndex().row() + 1;
   if (Row == NumEvents) Row = 0;
   StartRow = Row;

   // Find next marked row.
   done = found = false;
   while (!done) {
      Node = DataBase->EventByIndex(Row);
      if (Node->metadata.marked) { done = found = true; }
      if (!done) {
         Row++;
         if (Row == NumEvents) Row = 0;
         if (Row == StartRow) done = true;
      }
   }

   // Scroll row into view.
   if (found) ScrollRowIntoView(Row, true);
}




// ********************************************************************
// Start searching from the row abow the row with the 'current index'.
// Stop when the first marked row has been found, and scroll this row
// into view. If there is no current index, search from end instead.
// Current index will be moved to the start of the found row.
// ********************************************************************
void eventlistmodel::ScrollToPrevMarkedEvent()
{
   bool done, found;
   int StartRow, Row;
   event_node_ *Node;

   // Find number of events in model.
   int NumEvents = rowCount();

   // Find the row number from where the search starts.
   Row = SelModel->currentIndex().row() - 1;
   if (Row == -1) Row = NumEvents -1;
   StartRow = Row;

   // Find next marked row.
   done = found = false;
   while (!done) {
      Node = DataBase->EventByIndex(Row);
      if (Node->metadata.marked) { done = found = true; }
      if (!done) {
         Row--;
         if (Row == -1) Row = NumEvents -1;
         if (Row == StartRow) done = true;
      }
   }

   // Scroll row into view.
   if (found) ScrollRowIntoView(Row, true);
}




// ***************************************************************************
// This function tagges a row in the view with a '+' sign.
// Only one row can be tagged at the same time.
// ***************************************************************************
void eventlistmodel::TagRow(int RowNr)
{
   TaggedRow = RowNr;
   RefreshRow(RowNr);
}




// ***************************************************************************
// This function unmarks a row in the view.
// ***************************************************************************
void eventlistmodel::UntagRow()
{
   int RowNr = TaggedRow;
   TaggedRow = -1;
   RefreshRow(RowNr);
}




// ********************************************************
// Return a list of event ID's for currently selected rows.
// ********************************************************
void eventlistmodel::GetSelection(QListEventID *RowList)
{
   event_id EventId;
   QModelIndexList ModelIndexes;

   // Clear the row list.
   RowList->clear();

   // Get the list of selected rows.
   ModelIndexes = ModelView->selectionModel()->selectedRows();

   // Exit if no rows are selected.
   if (!ModelIndexes.count()) return;

   // Return the selected rows.
   for (int i=0;i<ModelIndexes.count();i++) {
      EventId.index = ModelIndexes.at(i).row();
      EventId.id = DataBase->IdByIndex(EventId.index);
      RowList->append(EventId);
   }
}




// ****************************************************************************
// This function selects several rows in the view, and makes the first column
// in the first row the current index. Any existing selections will be cleared.
// The first row can optionally be scrolled into view.
// ****************************************************************************
void eventlistmodel::SelectRows(QList<int> *RowList, bool EnsureVisible)
{
   // Select all rows in 'RowList'.
   for (int i=0;i<RowList->size();i++) {
      if (i == 0) {
         SelectRow(RowList->at(i), true, true, EnsureVisible);
      } else {
         SelectRow(RowList->at(i), false, false, false);
      }
   }
}




// *********************************************************************
// This function refreshes a row in the view.
// *********************************************************************
void eventlistmodel::RefreshRow(int row)
{
   QModelIndex TopLeft, BottomRight;
   TopLeft = this->index(row, 0, QModelIndex());
   BottomRight = this->index(row, NumElvColumns-1, QModelIndex());
   emit dataChanged(TopLeft, BottomRight);
}




// ******************************************************************
// This function removes a row from the view.
// ******************************************************************
void eventlistmodel::RemoveRow(int Row)
{
   removeRow(Row);
   SetNumModelEvents(GetNumModelEvents() - 1);

   // Inform the view of a change in the data.
   emit layoutChanged();

   // If database is empty, signal with index -1.
   if (!GetNumModelEvents()) emit RowChanged(-1);
}




// ******************************************************************
// This function inserts rows into the model and view.
// ******************************************************************
bool eventlistmodel::insertRows(int position, int rows, const QModelIndex &parent)
{
   Q_UNUSED(parent)

   beginInsertRows(QModelIndex(), position, position + rows - 1);
   SetNumModelEvents(GetNumModelEvents() + rows);
   endInsertRows();
   return true;
}




// ******************************************************************
// This function inserts a row into the model and view.
// ******************************************************************
void eventlistmodel::InsertRow(int position)
{
   insertRows(position, 1);
}




// ******************************************************************
// This function is used to add more data to the model.
// ******************************************************************
void eventlistmodel::FetchMoreData()
{
   while (canFetchMore(QModelIndex())) fetchMore(QModelIndex());
}




// *****************************************************
// This fuction is called from event list view to get
// the item texts in the view. One call for each item.
// *****************************************************
QVariant eventlistmodel::data(const QModelIndex &index, int role) const
{
   int row, column;
   static event_node_ *EventPtr;

   // Get row and column numbers from index.
   row = index.row(); column = index.column();

   // Get pointer to row data.
   EventPtr = DataBase->EventByIndex(row);

   // Underline date and time if event is marked.
   if (role == Qt::FontRole && column == ColDateTime && EventPtr->metadata.marked) {
      QFont font; font.setUnderline(true);
      return font;
   }

   // Return text to be displayed for current index.
   if (role == Qt::DisplayRole) {
      // Return row number for the row number column.
      if (column == ColRowNumber) return QVariant(row+1);
      // Return event data for this index.
      return GetItemData(EventPtr, row, column);
   }

   // Return tooltip text for current index.
   if (role == Qt::ToolTipRole) {
      // No tool tip for column 0.
      if (column == ColRowNumber) return QString();
      // Return tool tip for magnitude columns.
      return GetItemToolTip(EventPtr, column);
   }

   // Set background color as needed.
   if (role == Qt::BackgroundRole) {
      // Use light gray background color in magnitue columns for events with more then one magnitude.
      bool UseToolTipBackgr = false;
      if (column == ColMW && EventPtr->hypocenters.first->magnitudes.MW.nmag > 1) UseToolTipBackgr = true;
      if (column == ColML && EventPtr->hypocenters.first->magnitudes.ML.nmag > 1) UseToolTipBackgr = true;
      if (column == ColMN && EventPtr->hypocenters.first->magnitudes.MN.nmag > 1) UseToolTipBackgr = true;
      if (column == ColMC && EventPtr->hypocenters.first->magnitudes.MC.nmag > 1) UseToolTipBackgr = true;
      if (column == ColMb && EventPtr->hypocenters.first->magnitudes.Mb.nmag > 1) UseToolTipBackgr = true;
      if (column == ColMB && EventPtr->hypocenters.first->magnitudes.MB.nmag > 1) UseToolTipBackgr = true;
      if (column == ColMs && EventPtr->hypocenters.first->magnitudes.Ms.nmag > 1) UseToolTipBackgr = true;
      if (column == ColMS && EventPtr->hypocenters.first->magnitudes.MS.nmag > 1) UseToolTipBackgr = true;
      if (column == ColLocality && strlen(EventPtr->locality)) UseToolTipBackgr = true;
      if (UseToolTipBackgr) {
         QColor color = QColor(0xf0, 0xf0, 0xf0);
         QBrush bgBrush(color);
         return bgBrush;
      }
      // If this event is marked, use Use light blue background color for the ColDateTime column.
      if (column == ColDateTime && EventPtr->metadata.marked) {
          QColor color = QColor(0xcc, 0xee, 0xff);
          QBrush bgBrush(color);
          return bgBrush;
      }
   }

   // Set alignment for the columns.
   if (role == Qt::TextAlignmentRole) {
      if (column == ColDateTime) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColRowNumber) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColModel) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColAgency) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColAction) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColDist) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColType) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColMInt) return Qt::AlignVCenter + Qt::AlignHCenter;
      if (column == ColLocality) return Qt::AlignVCenter + Qt::AlignLeft;
      if (column == ColSFile) return Qt::AlignVCenter + Qt::AlignLeft;
      return Qt::AlignVCenter + Qt::AlignRight;
   }

   // Return an invalid QVariant for empty cells.
   return QVariant();
}




// *****************************************************
// This fuction is called from event list view to get
// the item texts in the view. One call for each item.
// *****************************************************
QVariant eventlistmodel::GetItemData(event_node_* EventPtr, int row, int column) const
{
   QString String;
   hypocenter_ *hyp;

   // Get pointer to first hypocenter.
   hyp = EventPtr->hypocenters.first;

   switch (column) {
      case ColAction:
      return QVariant(EventPtr->action);

      case ColDateTime:
      CreateElvTimeStr(&hyp->time, &String);
      if (hyp->fix_org != 32) String.append(hyp->fix_org);
      if (row == TaggedRow) String.prepend("+");
      return QVariant(String);

      case ColLatitude:
      if (hyp->lat == -999.0) return QVariant();
      String = QString().number(hyp->lat, 'f', 4);
      String.append(hyp->epi_flag);
      return QVariant(String);

      case ColLongitude:
      if (hyp->lon == -999.0) return QVariant();
      String = QString().number(hyp->lon, 'f', 4);
      String.append(hyp->epi_flag);
      return QVariant(String);

      case ColDepth:
      if (hyp->depth == -999.0) return QVariant();
      String = QString().number(hyp->depth, 'f', 1);
      String.append(hyp->depth_flag);
      return QVariant(String);

      case ColModel:
      return QVariant(QString(hyp->modl_id));

      case ColAgency:
      return QVariant(QString(hyp->agency));

      case ColRMS:
      if (hyp->rms == -999.0) return QVariant();
      String = QString().number(hyp->rms, 'f', 2);
      return QVariant(String);

      case ColGap:
      if (hyp->gap == -999.0) return QVariant();
      return QVariant(hyp->gap);

      case ColErrLat:
      if (hyp->lat_err == -999.0) return QVariant();
      String = QString().number(hyp->lat_err, 'f', 1);
      return QVariant(String);

      case ColErrLon:
      if (hyp->lon_err == -999.0) return QVariant();
      String = QString().number(hyp->lon_err, 'f', 1);
      return QVariant(String);

      case ColErrDep:
      if (hyp->depth_err == -999.0) return QVariant();
      String = QString().number(hyp->depth_err, 'f', 1);
      return QVariant(String);

      case ColDist:
      return QVariant(QString(hyp->dist_id));

      case ColType:
      return QVariant(QString(hyp->evnt_id));

      case ColMInt:
      if (!EventPtr->macros.numlines) return QVariant();
      String = EventPtr->macros.lines;
      return QVariant(String.mid(27,2).simplified());

      case ColNrSta:
      if (EventPtr->nstat == -999) return QVariant();
      return QVariant(EventPtr->nstat);

      case ColM:
      if (!EventPtr->hypocenters.nmag) return QVariant();
      String = QString().number(EventPtr->hypocenters.mag_all[0].mag, 'f', 1);
      return QVariant(String);

      case ColMW:
      if (!hyp->magnitudes.MW.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.MW.mag[0], 'f', 1);
      return QVariant(String);

      case ColML:
      if (!hyp->magnitudes.ML.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.ML.mag[0], 'f', 1);
      return QVariant(String);

      case ColMN:
      if (!hyp->magnitudes.MN.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.MN.mag[0], 'f', 1);
      return QVariant(String);

      case ColMC:
      if (!hyp->magnitudes.MC.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.MC.mag[0], 'f', 1);
      return QVariant(String);

      case ColMb:
      if (!hyp->magnitudes.Mb.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.Mb.mag[0], 'f', 1);
      return QVariant(String);

      case ColMB:
      if (!hyp->magnitudes.MB.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.MB.mag[0], 'f', 1);
      return QVariant(String);

      case ColMs:
      if (!hyp->magnitudes.Ms.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.Ms.mag[0], 'f', 1);
      return QVariant(String);

      case ColMS:
      if (!hyp->magnitudes.MS.nmag) return QVariant();
      String = QString().number(hyp->magnitudes.MS.mag[0], 'f', 1);
      return QVariant(String);

      case ColLocality:
      if (!strlen(EventPtr->locality)) return QVariant();
      return QVariant(QString(EventPtr->locality));

      case ColSFile:
      return QVariant(EventPtr->metadata.sfile);
   }

   return QVariant();
}




// ************************************************************
// This fuction returns the ToolTips for the magnitude columns.
// ************************************************************
QVariant eventlistmodel::GetItemToolTip(event_node_* EventPtr, int column) const
{
   hypocenter_ *hyp;
   int index, NumMag;
   QString ToolTip, String;

   // Clear the ToolTip string.
   ToolTip.clear();

   // Get pointer to first hypocenter.
   hyp = EventPtr->hypocenters.first;

   // Create and return tooltips.
   switch (column) {
      case ColM:
      if (EventPtr->hypocenters.nmag) {
         ToolTip.append("M" + QString(EventPtr->hypocenters.mag_all[0].type));
         ToolTip.append(" " + QString(EventPtr->hypocenters.mag_all[0].agency));
      }
      return QVariant(ToolTip);

      case ColMW:
      NumMag = hyp->magnitudes.MW.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.MW.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.MW.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColML:
      NumMag = hyp->magnitudes.ML.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.ML.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.ML.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColMN:
      NumMag = hyp->magnitudes.MN.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.MN.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.MN.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColMC:
      NumMag = hyp->magnitudes.MC.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.MC.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.MC.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColMb:
      NumMag = hyp->magnitudes.Mb.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.Mb.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.Mb.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColMB:
      NumMag = hyp->magnitudes.MB.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.MB.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.MB.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColMs:
      NumMag = hyp->magnitudes.Ms.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.Ms.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.Ms.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColMS:
      NumMag = hyp->magnitudes.MS.nmag;
      for (index=1;index<=NumMag;index++) {
         ToolTip.append(hyp->magnitudes.MS.mag_agency[index-1]);
         String = QString().number(hyp->magnitudes.MS.mag[index-1], 'f', 1);
         ToolTip.append(String);
         if (index < NumMag) ToolTip.append("\n");
      }
      return QVariant(ToolTip);

      case ColLocality:
      if (!strlen(EventPtr->locality)) return QVariant();
      return QVariant(EventPtr->locality);

      case ColSFile:
      if (!strlen(EventPtr->metadata.sfile)) return QVariant();
      return QVariant(EventPtr->metadata.sfile);

   }

   // Return an invalid QVariant for columns with no tooltip.
   return QVariant();
}




// ***********************************************************
// This function is signaled from the selection model to
// inform about changes in the Event List View's selection.
// ***********************************************************
void eventlistmodel::selectionChanged(const QItemSelection &selected,
                                      const QItemSelection &deselected)
{
   int NumSelections, item;
   QModelIndexList IdxLst;

   // Handle new deselections.
   IdxLst = deselected.indexes();
   NumSelections = IdxLst.count();
   for(item=0;item<NumSelections;item++) {
      if (IdxLst.at(item).column() == ColDateTime) {
         SelectedRows.setBit(IdxLst.at(item).row(), false);
         NumSelectedRows--;
      }
   }

   // Handle new selections.
   IdxLst = selected.indexes();
   NumSelections = IdxLst.count();
   for(item=0;item<NumSelections;item++) {
      if (IdxLst.at(item).column() == ColDateTime) {
         SelectedRows.setBit(IdxLst.at(item).row(), true);
         NumSelectedRows++;
      }
   }
}




// ****************************************************************
// This function is signaled from the selection model about changes
// in the Event List View's current row. Function will emit a
// RowChanged() signal when the current row changes.
// ****************************************************************
void eventlistmodel::currentRowChanged(const QModelIndex &current, const QModelIndex &previous)
{
   Q_UNUSED(previous)

   emit RowChanged(current.row());
}




// ********************************************************************
// Brings up the speed search dialog box. This function is signaled
// from the ELV keyboard filter class. Value of 'Key' is 1 or 2.
// ********************************************************************
void eventlistmodel::ActivateSpeedSearch(char Key)
{
   db::dbStatus status = DataBase->Status();
   if (status == db::open || status == db::read_sfiles) {
      // Open and close the dialog box.
      SpeedSearchDlg *Dialog = new SpeedSearchDlg();  // Create the dialog.
      Dialog->InitDialog(DataBase, Key);              // Initialize the dialog.
      Dialog->exec();                                 // Open the dialog box.
      delete Dialog;                                  // Destroy the dialog.
   }
}




// ********************************************************************
// This function is signaled from the database.
// Handles reply from the SpeedSearch() signal.
// ********************************************************************
void eventlistmodel::SpeedSearchReply(int Row)
{
   SelectRow(Row, true, true, true);
}




// *********************************************************************
// This function scrolls a row into the visible part of event list view.
// Function optinally set first item in row as the current index.
// *********************************************************************
void eventlistmodel::ScrollRowIntoView(int Row, bool SetCurr)
{
   // Scroll row into view.
   QModelIndex FirstItem = index(Row, 0, QModelIndex());
   ModelView->scrollTo(FirstItem, QAbstractItemView::EnsureVisible);

   // Set first item in row as current index.
   if (SetCurr) SelModel->setCurrentIndex(FirstItem, QItemSelectionModel::NoUpdate);
}




// ********************************************************************
// Start searching from the row below the row with the 'current index'.
// Stop when the first selected row has been found, and scroll this row
// into view. If there is no current index, search from start instead.
// Current index will be moved to the start of the found row.
// ********************************************************************
void eventlistmodel::ScrollToNextSelection()
{
   // Return if no rows are currrently selected.
   if (!NumSelectedRows) return;

   // Find number of events in model.
   int NumEvents = rowCount();

   // Find the row number from where the search starts.
   int Row = SelModel->currentIndex().row() + 1;
   if (Row == NumEvents) Row = 0;

   // Search 'SelectedRows' for the row.
   bool done = false;
   while (!done) {
      if (SelectedRows.at(Row)) done = true;
      if (!done) {
         if (Row == NumEvents) Row = -1;
         Row++;
      }
   }

   // Scroll row into view.
   ScrollRowIntoView(Row, true);
}




// ********************************************************************
// Start searching from the row above the row with the 'current index'.
// Stop when the first selected row has been found, and scroll this row
// into view. If there is no current index, search from end instead.
// Current index will be moved to the start of the found row.
// ********************************************************************
void eventlistmodel::ScrollToPrevSelection()
{
   // Return if no rows are currrently selected.
   if (!NumSelectedRows) return;

   // Find number of events in model.
   int NumEvents = rowCount();

   // Find the row number from where the search starts.
   int Row = SelModel->currentIndex().row() - 1;
   if (Row == -1) Row = NumEvents - 1;

   // Search 'SelectedRows' for the row.
   bool done = false;
   while (!done) {
      if (SelectedRows.at(Row)) done = true;
      if (!done) {
         if (Row == 0) Row = NumEvents;
         Row--;
      }
   }

   // Scroll row into view.
   ScrollRowIntoView(Row, true);
}




// *****************************************************************
// This function safely sets the value of 'NumEventsInModel'.
// ******************************************************************
void eventlistmodel::SetNumModelEvents(int count)
{
   mtx_num_events.lock();
   NumEventsInModel = count;
   mtx_num_events.unlock();
}




// *****************************************************************
// This function safely returns the value of 'NumEventsInModel'.
// ******************************************************************
int eventlistmodel::GetNumModelEvents() const
{
   mtx_num_events.lock();
   int count = NumEventsInModel;
   mtx_num_events.unlock();
   return count;
}




// *****************************************************************
// This function returns the current selected row.
// If no rows are selected this function returns '-1'.
// ******************************************************************
int eventlistmodel::CurrentRow()
{
   if (GetNumModelEvents()) {
      return ModelView->currentIndex().row();
   } else {
      return -1;
   }
}




// *****************************************************************
// This function declares the MIME type used to export information
// when dragging from the view.
// ******************************************************************
QStringList eventlistmodel::mimeTypes() const
{
   QStringList types;
   types << "application/se.dragdrop";
   return types;
}




// *****************************************************************
// This function encodes the MIME data in the advertised format when
// dragging from the view.
// ******************************************************************
QMimeData* eventlistmodel::mimeData(const QModelIndexList &indexes) const
{
   event_node_* EventPtr;
   QMimeData *mimeData = new QMimeData();
   QByteArray encodedData;
   QModelIndex index;

   QDataStream stream(&encodedData, QIODevice::WriteOnly);
   // First item is path to database.
   stream << DataBase->DatabasePath;
   // Then add all event files.
   foreach(index, indexes) {
      if (index.column() == 1) {
         EventPtr = DataBase->EventByIndex(index.row());
         stream << QString(EventPtr->metadata.sfile);
      }
   }
   mimeData->setData("application/se.dragdrop", encodedData);
   return mimeData;
}




// ******************************************************************
// This function receives dropped MIME data in the advertised format.
// ******************************************************************
bool eventlistmodel::dropMimeData(const QMimeData *data, Qt::DropAction action,
                                  int row, int column, const QModelIndex &parent)
{
   Q_UNUSED(action); Q_UNUSED(row); Q_UNUSED(column); Q_UNUSED(parent);

   // Handle the Qt::IgnoreAction action.
   if (action == Qt::IgnoreAction) return true;

   // Receive MIME data (event list).
   if (data->hasFormat("application/se.dragdrop")) {
      // Data has correct MIME type.
      QByteArray encodedData = data->data("application/se.dragdrop");
      QDataStream stream(&encodedData, QIODevice::ReadOnly);
      QStringList EventList;
      while (!stream.atEnd()) {
         QString text;
         stream >> text;
         EventList << text;
      }
      // Notify mainwindow about the dropped events.
      emit EventsDropped(EventList);
      // Signal that we can handle this mime format.
      return true;
   }

   // Signal that we cannot handle this mime format.
   return false;
}




// ******************************************************************
// This function indicates to the event list view which items can be
// dragged, and which item will accept drops.
// ******************************************************************
Qt::ItemFlags eventlistmodel::flags(const QModelIndex &index) const
{
   Qt::ItemFlags defaultFlags = QAbstractTableModel::flags(index);
   if (index.isValid()) {
      return Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled | defaultFlags;
   } else {
      return Qt::ItemIsDropEnabled | defaultFlags;
   }
 }
