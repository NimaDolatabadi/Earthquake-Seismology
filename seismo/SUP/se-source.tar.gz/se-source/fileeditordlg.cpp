#include <QStyle>
#include <QSettings>
#include <QMessageBox>
#include <QFileDialog>

#include "types.h"
#include "fileeditordlg.h"
#include "ui_fileeditordlg.h"


// ************************************
// Constructor function for this class.
// ************************************
FileEditorDlg::FileEditorDlg(QWidget *parent) : QDialog(parent), ui(new Ui::FileEditorDlg)
{
   // Set up the user interface.
   ui->setupUi(this);

   // Initialize variables.
   SavePos = true;
   AppName = QCoreApplication::applicationName();

   // Use monospaced font.
   QFont font("Monospace");
   font.setStyleHint(QFont::TypeWriter);
   ui->TextEdit->setFont(font);

   // Set a defualt minimun width of the dialog box so that 80 characters will fit.
   // This code is only effective if no previous geometry has been saved.
   int TextEditWidth = ui->TextEdit->fontMetrics().width(QChar('H'))*85;
   int ScrollBarWidth = qApp->style()->pixelMetric(QStyle::PM_ScrollBarExtent);
   setMinimumWidth(TextEditWidth + ScrollBarWidth + 20);

   // Restore/set the last used geometry of the dialog.
   QSettings settings;
   restoreGeometry(settings.value("Geometry/FileEditor").toByteArray());

   // Set up an event filter for the TextEdit widget.
   // Filter is used to pick up some keyoard shortcuts.
   // See member function 'eventFilter'.
   ui->TextEdit->installEventFilter(this);

   // Set the TextEdit widget to overwrite mode.
   ui->TextEdit->setOverwriteMode(OverwriteMode = true);

   // Configure Tab key to move input focus away from TextEdit widget.
   ui->TextEdit->setTabChangesFocus(true);
}




// ***********************************
// Destructor function for this class.
// ***********************************
FileEditorDlg::~FileEditorDlg()
{
   // Save the geometry of the dialog.
   if (SavePos) {
      QSettings settings;
      settings.setValue(QString("Geometry/FileEditor"), saveGeometry());
   }

   // Delete the user interface.
   delete ui;
}




// *******************************************************
// This function is used to load the file.
// This function should be called before window is shown.
// *******************************************************
bool FileEditorDlg::LoadFile(QString FilePath)
{
   // Save file name/path.
   filepath = FilePath;

   // Set name of file in dialog box.
   string = "File: "; string.append(filepath);

   // Set label text.
   ui->labelFile->setText(string);

   // Open file.
   file.setFileName(filepath);
   if (!file.open(QIODevice::ReadOnly|QIODevice::Text)) return false;

   // Read and close file.
   buffer = file.readAll();
   file.close();

   // Copy file contents to edit box.
   ui->TextEdit->setPlainText((QString)buffer);

   return true;
}




// ***********************************
// User has pressed the 'Save' button.
// ***********************************
void FileEditorDlg::Save()
{
   // Change mouse pointer to wait pointer.
   setCursor(Qt::WaitCursor);

   // Copy file contents from edit box.
   string = ui->TextEdit->toPlainText();

   // Save the file. File will be overwritten.
   file.setFileName(filepath);
   if (!file.open(QIODevice::ReadWrite|QIODevice::Text)) {
      setCursor(Qt::ArrowCursor);
      message = "Unable to open file for writing!";
      QMessageBox::critical(this, AppName, message);
      return;
   }

   // Write and close file.
   buffer.clear(); buffer.append(string);
   file.resize(0); file.write(buffer); file.close();

   // Emit FileSaved() signal to SEDB class.
   // SEDB class will then reload the event.
   emit file_saved(filepath);

   // Restore mouse pointer.
   setCursor(Qt::ArrowCursor);

   // Close the dialog.
   close();
}




// ************************************
// User has pressed the 'Close' button.
// ************************************
void FileEditorDlg::Close()
{
   // Close the dialog.
   close();
}




// *******************************************
// User has pressed the 'Find/Replace' button.
// *******************************************
void FileEditorDlg::FindReplace()
{
   int AbsCurPos;
   QTextCursor cursor;
   QTextEdit::ExtraSelection ExSelection;
   QList<QTextEdit::ExtraSelection> ExSelections;

   // Open the 'Find and Replace' dialog.
   // Settings are returned in 'SearchData'.
   fileeditor_findreplacedlg *dialog = new fileeditor_findreplacedlg(this, &SearchData);
   int status = dialog->exec(); delete dialog;
   if (!status) {
      ui->TextEdit->setFocus();
      return;
   }

   // Remove any existing extra selections.
   ExSelections = ui->TextEdit->extraSelections();
   if (ExSelections.size()) {
      ExSelections.clear();
      ui->TextEdit->setExtraSelections(ExSelections);
   }

   // Set correct case sensitivity for search.
   QFlags<QTextDocument::FindFlag> flags;
   if (SearchData.CaseSensitive) flags = QTextDocument::FindCaseSensitively;

   // Set focus to the TextEdit widget.
   ui->TextEdit->setFocus(Qt::ActiveWindowFocusReason);

   // Save cursor position and move cursor to start.
   AbsCurPos = ui->TextEdit->textCursor().position();
   ui->TextEdit->moveCursor(QTextCursor::Start);

   // Find all occurences of the search string. These
   // are saved as extra selections (one per occurence).
   while (ui->TextEdit->find(SearchData.SearchText, flags)) {
      ExSelection.cursor = ui->TextEdit->textCursor();
      ExSelection.format.setBackground(QBrush(QColor(154,218,253)));
      ExSelections.append(ExSelection);
   }

   // Search has failed. Inform user and return.
   if (!ExSelections.size()) {
      // Inform user that search failed.
      QMessageBox::information(NULL, "Find/Replace", "Search string was not found.");
      // Restore cursor position and return.
      cursor = ui->TextEdit->textCursor();
      cursor.setPosition(AbsCurPos);
      ui->TextEdit->setTextCursor(cursor);
      return;
   }

   // Mark all extra selections with a blue color.
   ui->TextEdit->setExtraSelections(ExSelections);
   cursor = ui->TextEdit->textCursor();
   cursor.setPosition(ExSelections[0].cursor.position());
   ui->TextEdit->setTextCursor(cursor);

   // Replace the search strings if a replace string was been given.
   if (SearchData.ReplaceText.size()) {
      for (int i=0;i<ExSelections.size();i++) {
         // Replace all occurences in the TextEdit widget.
         cursor = ExSelections[i].cursor;
         cursor.removeSelectedText();
         cursor.insertText(SearchData.ReplaceText);
      }
      // Move cursor to end of last replaced string.
      ui->TextEdit->setTextCursor(cursor);
   }
}




// *******************************************
// User has pressed the 'Find/Replace' button.
// *******************************************
void FileEditorDlg::ToggleOverwriteMode()
{
   OverwriteMode = !OverwriteMode;
   ui->TextEdit->setOverwriteMode(OverwriteMode);
}




// **********************************************
// User has pressed Ctrl-D (Delete current line).
// **********************************************
void FileEditorDlg::DeleteCurrentLine()
{
   QTextCursor cursor = ui->TextEdit->textCursor();
   cursor.select(QTextCursor::LineUnderCursor);
   cursor.removeSelectedText(); cursor.deleteChar();
   ui->TextEdit->setTextCursor(cursor);
}




// **************************************
// User has pressed the 'Save As' button.
// **************************************
void FileEditorDlg::SaveAs()
{
   QStringList FileNames;

   // Bring up file selection dialog box. Return if user cancels the
   // operation. User must enter the name of a new or existing file.
   QFileDialog dialog(this);
   dialog.setFileMode(QFileDialog::AnyFile);
   message = "Please select a destination folder and a file name:";
   dialog.setWindowTitle(message);
   if (dialog.exec()) {
      // User have selected a file.
      FileNames = dialog.selectedFiles();
      // If file already exist then ask for permission to overvrite it.
      if (QFile(FileNames.at(0)).exists()) {
         QMessageBox::StandardButton Answer;
         message = "File already exists. Do you want to overwrite the file?";
         Answer = QMessageBox::question(this, AppName, message, QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
         if (Answer == QMessageBox::No) return;
      }
   } else {
      // Abort. User have pressed 'Cancel'.
      return;
   }

   // Change mouse pointer to wait pointer.
   setCursor(Qt::WaitCursor);

   // Save the file. File will be overwritten.
   file.setFileName(FileNames.at(0));
   if (!file.open(QIODevice::ReadWrite|QIODevice::Text))
   {
      setCursor(Qt::ArrowCursor);
      message = "Unable to open selected file for writing!";
      QMessageBox::critical(this, AppName, message);
      return;
   }

   // Copy file contents from edit box.
   buffer.clear(); buffer.append(ui->TextEdit->toPlainText());

   // Write and close file.
   file.resize(0); file.write(buffer); file.close();

   // Restore mouse pointer.
   setCursor(Qt::ArrowCursor);
}




// ***********************************************
// This function is signaled from QPlainTextEdit
// when user moves the cursor to a different line.
// ***********************************************
void FileEditorDlg::CursorPositionChanged()
{
   // Show the current column number.
   QTextCursor cursor = ui->TextEdit->textCursor();
   string = "Column: ";
   string.append(QString::number(cursor.columnNumber()+1));
   ui->labelColumn->setText(string);

   // Find and show the current line number.
   int CursorPos = ui->TextEdit->textCursor().position();
   QTextBlock blk = ui->TextEdit->document()->findBlock(CursorPos);
   QTextBlock blk2 = ui->TextEdit->document()->begin();
   int LineNr = 1;
   while (blk != blk2) { blk2 = blk2.next(); LineNr++; }
   string = "Line: " + QString::number(LineNr);
   ui->labelLine->setText(string);
}




// *****************************************************
// This is the event filter for the ui->TextEdit widget.
// *****************************************************
bool FileEditorDlg::eventFilter(QObject* object, QEvent* event)
{
   Q_UNUSED(object)

   if (event->type()==QEvent::KeyPress) {
      // Transform QEvent into QKeyEvent.
      QKeyEvent* pKeyEvent=static_cast<QKeyEvent*>(event);

      // Handle pressed key.
      switch(pKeyEvent->key()) {
         case Qt::Key_D:
         if (pKeyEvent->modifiers() == Qt::ControlModifier) { DeleteCurrentLine(); return true; }
         return false;

         case Qt::Key_F:
         if (pKeyEvent->modifiers() == Qt::ControlModifier) { FindReplace(); return true; }
         return false;

         case Qt::Key_I:
         if (pKeyEvent->modifiers() == Qt::ControlModifier) { ToggleOverwriteMode(); return true; }
         return false;

         case Qt::Key_S:
         if (pKeyEvent->modifiers() == Qt::ControlModifier) { Save(); return true; }
         return false;

         case Qt::Key_Insert:
         if (pKeyEvent->modifiers() == Qt::NoModifier) { ToggleOverwriteMode(); return true; }
         return false;
      }
   }
   return false;
}
