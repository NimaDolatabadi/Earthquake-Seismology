#include <stdio.h>
#include <stdlib.h>

void wsac1_( char *filename, float *seismogram, int *nlen, 
            float *toffset, float *deltat, int *nerr ) {
    fprintf(stderr, "Non-functional dummy function wsac1() called. Exiting...\n");
    exit(1);
}

void rsac1_( char *filename, float *scratch, int *nlen, 
            float *toffset, float *deltat, int *maxlen, int *nerr) {
    fprintf(stderr, "Non-functional dummy function rsac1() called. Exiting...\n");
    exit(1);
}
